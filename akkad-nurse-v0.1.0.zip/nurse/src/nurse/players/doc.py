"""Independent entrypoint for doc player."""
from ..worker import main
if __name__=="__main__":raise SystemExit(main("doc"))
