"""Independent evaluator entrypoint: tinygyal."""
from ..evaluator import main
if __name__=="__main__":raise SystemExit(main("tinygyal"))
