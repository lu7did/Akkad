"""Independent evaluator entrypoint: znpz."""
from ..evaluator import main
if __name__=="__main__":raise SystemExit(main("znpz"))
