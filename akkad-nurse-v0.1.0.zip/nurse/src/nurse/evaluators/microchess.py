"""Independent evaluator entrypoint: microchess."""
from ..evaluator import main
if __name__=="__main__":raise SystemExit(main("microchess"))
