"""Independent evaluator entrypoint: cerebrum."""
from ..evaluator import main
if __name__=="__main__":raise SystemExit(main("cerebrum"))
