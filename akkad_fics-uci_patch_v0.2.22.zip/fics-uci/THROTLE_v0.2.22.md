# fics-uci v0.2.22 — `throtle` post-partida

`throtle` es una clave YAML **escrita exactamente así** (una sola `t` después de `thro`).

```yaml
throtle: -1     # predeterminado: desactivado
# throtle: 30000  # bloquear nuevas partidas durante 30 segundos
```

- `-1`: sin restricción; incluso cuando se omite la clave.
- `0`: sin espera después de la partida.
- `N > 0`: tiempo mínimo en **milisegundos** desde que llega la notificación de fin de la última partida hasta poder solicitar o aceptar otra.
- Se rechazan desafíos entrantes con `decline <jugador>` y telemetría con `throtle` y milisegundos restantes.
- Las ofertas de `seek` pueden seguir anunciándose o consultándose (`sought`), pero no se envía `play <numero>` durante la espera. Se registra el motivo de la omisión.
- Si el motor termina su handshake UCI (`readyok`) durante la espera, las aceptaciones y los `play` diferidos también quedan bloqueados.
- Se usa `time.monotonic()` y el contador no se guarda entre reinicios del proceso.
- El reloj inicia cuando la finalización es reconocida para la **partida activa**, no al arrancar fics-uci. En caso de respuesta terminal de FICS sin resultado, también se inicia.
- Durante una partida ya activa no se interrumpe la partida por `throtle`.

La telemetría de inicio muestra el valor configurado o que la función está desactivada. La versión pasa de `0.2.21` a `0.2.22`.

Validación local: 15 pruebas automatizadas superadas usando un módulo simulado de `chess` para cubrir pruebas que sólo necesitan importar el puente. No se efectuó conexión real a FICS.
