"""Evolution of Sargon-III-inspired *proposed* evaluation weights against Stockfish CP.

--resume takes a complete generation JSON (population + RNG state); an exact
continuation requires the same dataset, seed, population and schema.
"""
import argparse
import hashlib
import json
import sys
from pathlib import Path
import numpy as np
from gen_common import open_source, load_labeled, validate_board, require_chess, target_cp
from gen_checkpoints import json_atomic
from gen_progress import TrainingProgress
from gen_sargon_core import SPECS, NAMES, BITS, DEFAULTS, encode, decode, evaluate

FORMAT='picogenus-sargon3-pst-v2'

def signature(rows):
    digest=hashlib.sha256()
    for row in rows:
        fen,cp=row[:2]
        digest.update(f'{fen}\0{cp:.12g}\n'.encode())
    return digest.hexdigest()

def data_load(source,seed,max_positions):
    chess=require_chess()
    with open_source(source) as db:rows=load_labeled(db,seed=seed,max_rows=max_positions)
    samples=[]
    for _,fen,teacher_uci,cp,mate,value in rows:
        board=validate_board(fen,chess)
        if board is None:continue
        target=target_cp((cp,mate,value),board.turn)
        if target is None:continue
        samples.append((fen,float(target),teacher_uci))
    if not samples:raise ValueError('No hay posiciones válidas con evaluación Stockfish')
    return samples

def unpack_rng(data):
    state=data['rng_state']
    return ('MT19937',np.array(state['keys'],dtype=np.uint32),int(state['pos']),int(state['has_gauss']),float(state['cached_gaussian']))

def pack_rng(rng):
    st=rng.get_state()
    return {'keys':st[1].tolist(),'pos':int(st[2]),'has_gauss':int(st[3]),'cached_gaussian':float(st[4])}

def offspring(pop,mse,rng):
    # Fitness-proportionate roulette retained; minimize RMSE, not move mismatches.
    rmse=np.sqrt(np.maximum(mse,0))
    fitness=1.0/(1.0+rmse)**2
    probs=fitness/fitness.sum()
    elite=pop[int(np.argmin(mse))].copy()
    next_pop=[elite]
    while len(next_pop)<len(pop):
        i,j=rng.choice(len(pop),size=2,p=probs)
        if rng.rand()<0.75:
            child=np.where(rng.rand(BITS)<0.5,pop[i],pop[j]).astype(np.uint8)
        else:child=pop[i].copy()
        child=np.bitwise_xor(child,(rng.rand(BITS)<0.005).astype(np.uint8))
        next_pop.append(child)
    return np.asarray(next_pop,dtype=np.uint8)

def model_record(bits,mse,generation,positions):
    p=decode(bits)
    return {'format':FORMAT,'version':'0.1.20','reference':'Sargon III experimental technical note 2026-11-14',
        'parameters':p,'chromosome_bits':''.join(map(str,bits.tolist())),
        'rmse_cp':float(np.sqrt(mse)),'mse_cp2':float(mse),
        'generation':int(generation),'positions':int(positions), 'pawn_value':100}

def initial(rng,population):
    base=np.asarray(encode(DEFAULTS),dtype=np.uint8)
    pop=[base.copy()]
    # Local variations about documented starting coefficients increase useful
    # signal without altering bit-flip mutation or crossover operators.
    for i in range(1,population):
        if i%5==0:
            pop.append(rng.randint(0,2,size=BITS).astype(np.uint8))
        else:
            pop.append(np.bitwise_xor(base,(rng.rand(BITS)<0.04).astype(np.uint8)))
    return np.asarray(pop,dtype=np.uint8)

def move_agreement(boards, teacher_moves, params, chess):
    """Diagnostic ONLY: 1-ply agreement with teacher_uci already in SQLite.

    The local heuristic evaluates successor positions; no Stockfish calls.
    The metric does not influence selection or checkpoint best status.
    """
    correct=0
    eligible=0
    skipped=0
    for board,teacher in zip(boards,teacher_moves):
        if not teacher:
            skipped+=1
            continue
        try:
            expected=chess.Move.from_uci(teacher)
            legal_moves=list(board.legal_moves)
        except (ValueError,AttributeError,TypeError):
            skipped+=1
            continue
        if expected not in legal_moves or not legal_moves:
            skipped+=1
            continue
        eligible+=1
        white_to_move=board.turn==chess.WHITE
        chosen=None
        best_value=None
        for move in legal_moves:
            board.push(move)
            try:
                score=evaluate(board,params)
            finally:
                board.pop()
            if best_value is None or (score>best_value if white_to_move else score<best_value):
                best_value=score
                chosen=move
        if chosen==expected:
            correct+=1
    return {'move_agreement_correct':correct,
            'move_agreement_total':eligible,
            'move_agreement_skipped':skipped,
            'move_agreement_pct':round(100.0*correct/eligible,2) if eligible else None}


def train(samples,out,population,generations,seed,resume=None):
    chess=require_chess()
    boards=[chess.Board(row[0]) for row in samples]
    targets=np.asarray([row[1] for row in samples],dtype=np.float64)
    teacher_moves=[row[2] if len(row)>2 else None for row in samples]
    digest=signature(samples)
    rng=np.random.RandomState(seed)
    best_mse=float('inf');best_bits=None
    start=1
    if resume:
        snap=json.loads(Path(resume).read_text(encoding='utf-8-sig'))
        if snap.get('format')!=FORMAT or snap.get('dataset_sha256')!=digest or snap.get('bits')!=BITS:
            raise ValueError('Checkpoint PST incompatible: esquema o conjunto de posiciones diferentes')
        if snap.get('population')!=population or snap.get('seed')!=seed:
            raise ValueError('Checkpoint PST incompatible: población o seed diferentes')
        previous=int(snap['generation']);start=previous+1
        pop=np.asarray([[int(c) for c in entry['chromosome_bits']] for entry in snap['individuals']],dtype=np.uint8)
        if pop.shape!=(population,BITS):raise ValueError('Población PST incorrecta en checkpoint')
        prev_mse=np.asarray([float(entry['mse_cp2']) for entry in snap['individuals']])
        if not np.isfinite(prev_mse).all():raise ValueError('Checkpoint contiene errores inválidos')
        rng.set_state(unpack_rng(snap))
        global_best=snap['global_best']
        best_mse=float(global_best['mse_cp2'])
        best_bits=np.asarray([int(v) for v in global_best['chromosome_bits']],dtype=np.uint8)
        pop=offspring(pop,prev_mse,rng)
        if generations<start:raise ValueError('--generaciones debe ser mayor que la generación del checkpoint')
        # Restore best only when needed, never worsen a previously saved best.
        if not Path(out).is_file():json_atomic(out,model_record(best_bits,best_mse,previous,len(samples)))
        if not (Path(out).parent/'PST_best.json').is_file():
            json_atomic(Path(out).parent/'PST_best.json',decode(best_bits))
    else:pop=initial(rng,population)
    progress=TrainingProgress('PST S3',len(samples),population,generations)
    for gen in range(start,generations+1):
        results=[];progress.reset_errors()
        try:
            for i,bits in enumerate(pop):
                params=decode(bits)
                prediction=np.asarray([evaluate(board,params) for board in boards])
                mse=float(np.mean((prediction-targets)**2))
                results.append(mse)
                errors=np.sqrt(results)
                progress.set_errors(float(np.min(errors)),float(np.mean(errors)))
                progress.update((gen-1)*population*len(samples)+(i+1)*len(samples),auto_end=False)
                if mse<best_mse:
                    best_mse=mse;best_bits=bits.copy()
                    record=model_record(bits,mse,gen,len(samples))
                    json_atomic(out,record)
                    json_atomic(Path(out).parent/'PST_best.json',record['parameters'])
        except KeyboardInterrupt:
            progress.abort()
            print('\nPST interrumpido; el mejor modelo ya evaluado queda en PST_best.json.',flush=True)
            raise
        mse_arr=np.asarray(results,dtype=np.float64)
        best_idx=int(np.argmin(mse_arr))
        # Observational diagnostic, never part of genetic fitness.
        diagnostic=move_agreement(boards,teacher_moves,decode(pop[best_idx]),chess)
        snapshot={'format':FORMAT,'version':'0.1.20','generation':gen,
            'population':population,'seed':seed,'bits':BITS,'dataset_sha256':digest,
            'model':'SargonIII-inspired','metrics':'Stockfish white-perspective centipawn MSE',
            'diagnostics':diagnostic,
            'rng_state':pack_rng(rng),'best_index':best_idx,'global_best':model_record(best_bits,best_mse,gen,len(samples)),
            'error_min_rmse_cp':float(np.sqrt(mse_arr.min())),
            'error_mean_rmse_cp':float(np.sqrt(mse_arr).mean()),
            'individuals':[{'index':i,'best':i==best_idx,
                            'chromosome_bits':''.join(map(str,bits.tolist())),
                            'parameters':decode(bits),
                            'mse_cp2':float(mse_arr[i]),'rmse_cp':float(np.sqrt(mse_arr[i]))}
                           for i,bits in enumerate(pop)]}
        json_atomic(Path(out).with_name(f'{Path(out).stem}.gen{gen:05d}.json'),snapshot)
        progress.finish_generation(gen*population*len(samples))
        agreement=(f" agreement={diagnostic['move_agreement_correct']:d}/"
                   f"{diagnostic['move_agreement_total']:d}"
                   f" ({diagnostic['move_agreement_pct']:.2f}%)"
                   if diagnostic['move_agreement_total'] else ' agreement=N/A')
        print(f'G{gen:05d}: best={np.sqrt(mse_arr.min()):.2f}cp '
              f'mean={np.sqrt(mse_arr).mean():.2f}cp global={np.sqrt(best_mse):.2f}cp'
              f'{agreement}',flush=True)
        if gen<generations:pop=offspring(pop,mse_arr,rng)
    progress.finish()
    return best_mse

def main():
    parser=argparse.ArgumentParser(description='Sargon III aproximado: calibración PST vs Stockfish (MSE cp)')
    parser.add_argument('--in',dest='source',required=True);parser.add_argument('--out',required=True)
    parser.add_argument('--población','--poblacion',dest='population',type=int,default=100)
    parser.add_argument('--generaciones',type=int,default=500)
    parser.add_argument('--seed',type=int,default=42)
    parser.add_argument('--max-positions',type=int,default=0)
    parser.add_argument('--resume',help='Archivo JSON de generación completa (*.genNNNNN.json)')
    a=parser.parse_args()
    if a.population<2 or a.generaciones<1 or a.max_positions<0:parser.error('argumentos fuera de rango')
    try:
        samples=data_load(a.source,a.seed,a.max_positions)
        best=train(samples,a.out,a.population,a.generaciones,a.seed,a.resume)
        print(f'✅ PST output={a.out} best={Path(a.out).parent / "PST_best.json"} rmse={best**0.5:.2f}cp')
    except KeyboardInterrupt:raise SystemExit(130)
    except (OSError,ValueError,RuntimeError,KeyError) as e:parser.error(str(e))
if __name__=='__main__':main()
