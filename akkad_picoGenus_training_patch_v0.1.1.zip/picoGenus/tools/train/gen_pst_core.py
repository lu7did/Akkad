"""picoGenus David-inspired 224-bit Gray-coded PST genotype and feature extractor.

The feature definitions are *our* bounded heuristic implementation. They are NOT an
exact reproduction of the original paper's chess evaluation function.
"""
import numpy as np

PARAM_SPECS = [
 ('KNIGHT_VALUE',11),('BISHOP_VALUE',11),('ROOK_VALUE',11),('QUEEN_VALUE',11),
 ('PAWN_ADVANCE_A',6),('PAWN_ADVANCE_B',6),('PASSED_PAWN_MULT',6),
 ('DOUBLED_PAWN_PENALTY',6),('ISOLATED_PAWN_PENALTY',6),('BACKWARD_PAWN_PENALTY',6),
 ('WEAK_SQUARE_PENALTY',6),('PASSED_PAWN_ENEMY_KING_DIST',6),
 ('KNIGHT_SQ_MULT',6),('KNIGHT_OUTPOST_MULT',6),('BISHOP_MOBILITY',6),('BISHOP_PAIR',6),
 ('ROOK_ATTACK_KING_FILE',6),('ROOK_ATTACK_KING_ADJ_FILE',6),
 ('ROOK_ATTACK_KING_ADJ_FILE_ABGH',6),('ROOK_7TH_RANK',6),
 ('ROOK_CONNECTED',6),('ROOK_MOBILITY',6),('ROOK_BEHIND_PASSED_PAWN',6),
 ('ROOK_OPEN_FILE',6),('ROOK_SEMI_OPEN_FILE',6),
 ('ROOK_ATCK_WEAK_PAWN_OPEN_COLUMN',6),('ROOK_COLUMN_MULT',6),
 ('QUEEN_MOBILITY',6),('KING_NO_FRIENDLY_PAWN',6),('KING_NO_FRIENDLY_PAWN_ADJ',6),
 ('KING_FRIENDLY_PAWN_ADVANCED1',6),('KING_NO_ENEMY_PAWN',6),
 ('KING_NO_ENEMY_PAWN_ADJ',6),('KING_PRESSURE_MULT',6)
]
BITS = 224
NAMES = [name for name, _ in PARAM_SPECS]
assert len(PARAM_SPECS) == 34 and sum(x[1] for x in PARAM_SPECS) == BITS


def decode(chromosomes):
    bits = np.asarray(chromosomes, dtype=np.uint8)
    if bits.ndim == 1: bits = bits[None, :]
    if bits.shape[1] != BITS or np.any(bits > 1):
        raise ValueError('Se requieren 224 bits binarios por cromosoma')
    result = np.zeros((bits.shape[0], len(PARAM_SPECS)), dtype=np.float64)
    start = 0
    for j, (_, width) in enumerate(PARAM_SPECS):
        gray = bits[:, start:start+width]
        binary = np.bitwise_xor.accumulate(gray, axis=1)
        result[:, j] = binary @ (2 ** np.arange(width-1, -1, -1))
        start += width
    return result


def encode_values(values):
    """For tests and roundtrip reproducibility."""
    bits = []
    for value, (_, n) in zip(values, PARAM_SPECS):
        if not 0 <= int(value) < 2**n: raise ValueError('Parámetro fuera de rango')
        gray = int(value) ^ (int(value) >> 1)
        bits.extend([(gray >> k) & 1 for k in range(n-1, -1, -1)])
    return np.array(bits, dtype=np.uint8)


def features(board):
    """White-minus-black features; pawn fixed 100cp, 34 evolved coefficients."""
    import chess
    vec = np.zeros(len(NAMES), dtype=np.float64)
    fixed = 0.0
    for color in (chess.WHITE, chess.BLACK):
        s = 1 if color else -1
        rival = not color
        pawns = list(board.pieces(chess.PAWN, color))
        enemy_pawns = list(board.pieces(chess.PAWN, rival))
        knights = list(board.pieces(chess.KNIGHT, color))
        bishops = list(board.pieces(chess.BISHOP, color))
        rooks = list(board.pieces(chess.ROOK, color))
        queens = list(board.pieces(chess.QUEEN, color))
        king = board.king(color)
        enemy_king = board.king(rival)
        if king is None or enemy_king is None:
            raise ValueError('Posición sin rey')
        fk, rk = chess.square_file(king), chess.square_rank(king)
        efk = chess.square_file(enemy_king)
        pawn_files = [chess.square_file(p) for p in pawns]
        enemy_files = [chess.square_file(p) for p in enemy_pawns]
        fixed += s * len(pawns) * 100
        for i, count in enumerate([len(knights), len(bishops), len(rooks), len(queens)]):
            vec[i] += s * count
        vec[15] += s * (len(bishops) >= 2)
        for sq in pawns:
            f, r = chess.square_file(sq), chess.square_rank(sq)
            advance = r if color else 7-r
            vec[4] += s * advance
            vec[5] += s * (advance // 2)
            if pawn_files.count(f) > 1: vec[7] -= s
            if not any(abs(pf-f) == 1 for pf in pawn_files): vec[8] -= s
            passed_pawn = not any(abs(chess.square_file(x)-f) <= 1 and
                                  (chess.square_rank(x) > r if color else chess.square_rank(x) < r)
                                  for x in enemy_pawns)
            if passed_pawn:
                vec[6] += s * advance
                vec[11] += s * chess.square_distance(sq, enemy_king)
            # Light approximation: backward pawn lacks adjacent defender and is attacked by enemy pawn.
            if not any(abs(chess.square_file(x)-f) == 1 and
                       (chess.square_rank(x) <= r if color else chess.square_rank(x) >= r)
                       for x in pawns) and board.is_attacked_by(rival, sq):
                vec[9] -= s
        # Rough weak squares: attacked by opponent but not defended by us on central squares.
        for sq in (chess.D4,chess.E4,chess.D5,chess.E5):
            if board.is_attacked_by(rival,sq) and not board.is_attacked_by(color,sq):
                vec[10] -= s
        for sq in knights:
            f,r=chess.square_file(sq),chess.square_rank(sq)
            central=(3.5-abs(3.5-f))+(3.5-abs(3.5-r))
            vec[12] += s*central
            if (r>=4 if color else r<=3) and not board.is_attacked_by(rival,sq):
                vec[13] += s
        for sq in bishops:
            vec[14] += s*len(board.attacks(sq))
        for sq in rooks:
            f,r=chess.square_file(sq),chess.square_rank(sq)
            vec[21] += s*len(board.attacks(sq))
            if (r==6 if color else r==1): vec[19] += s
            if f == efk: vec[16] += s
            if abs(f-efk)==1: vec[17] += s
            if abs(f-efk)==1 and f in (0,1,6,7): vec[18] += s
            if any(other != sq and other in board.attacks(sq) for other in rooks):
                vec[20] += s
            if not any(pf==f for pf in pawn_files):
                vec[24] += s
                if not any(pf==f for pf in enemy_files): vec[23] += s
            if any(chess.square_file(p)==f and (r < chess.square_rank(p) if color else r > chess.square_rank(p))
                   for p in pawns): vec[22] += s
            vec[26] += s*int(f in (2,3,4,5))
            if any(chess.square_file(p)==f and board.is_attacked_by(color,p) for p in enemy_pawns):
                vec[25] += s
        for sq in queens:
            vec[27] += s*len(board.attacks(sq))
        shield_rank = rk+1 if color else rk-1
        for delta in (-1,0,1):
            file = fk+delta
            if not (0<=file<8 and 0<=shield_rank<8): continue
            shield_sq = chess.square(file,shield_rank)
            piece = board.piece_at(shield_sq)
            has_friend = piece is not None and piece.piece_type==chess.PAWN and piece.color==color
            if not has_friend: vec[28 if delta==0 else 29] -= s
            else:
                r=chess.square_rank(shield_sq)
                vec[30] += s * int((r>=3 if color else r<=4))
            if not any(chess.square_file(p)==file for p in enemy_pawns):
                vec[31 if delta==0 else 32] += s
        vec[33] += s * sum(board.is_attacked_by(color, sq) for sq in board.attacks(enemy_king))
    return fixed, vec


def evaluate(board, params):
    fixed, feats = features(board)
    return float(fixed + feats @ np.asarray(params, dtype=float))


def choose_move(board, params):
    import chess
    moves = list(board.legal_moves)
    if not moves: return None
    best = None; score_best = -float('inf')
    for move in moves:
        board.push(move)
        if board.is_checkmate(): value=1e6
        else:
            value = (1 if not board.turn else -1) * evaluate(board, params)
        board.pop()
        if value > score_best:
            score_best=value;best=move
    return best
