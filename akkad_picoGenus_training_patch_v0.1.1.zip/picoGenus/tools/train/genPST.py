"""Evolve Gray-coded 224-bit heuristic coefficients from Stockfish-labeled chess positions."""
import argparse
import json
import os
from pathlib import Path

import numpy as np
from gen_common import atomic_path, load_labeled, open_source, require_chess, target_cp, validate_board
from gen_pst_core import BITS, NAMES, decode, features, PARAM_SPECS


def build_dataset(rows):
    chess = require_chess()
    main_x, fixed, labels, candidate_x, candidate_fixed, offsets, correct, side = [], [], [], [], [], [0], [], []
    ignored = 0
    for _, fen, teacher, cp, mate, value in rows:
        board = validate_board(fen, chess)
        if board is None or not teacher:
            ignored += 1; continue
        tgt = target_cp((cp,mate,value), board.turn)
        if tgt is None:
            ignored += 1; continue
        try:
            move_target = chess.Move.from_uci(teacher)
        except ValueError:
            ignored += 1; continue
        moves = list(board.legal_moves)
        if move_target not in moves or not moves:
            ignored += 1; continue
        f, x = features(board)
        main_x.append(x);fixed.append(f);labels.append(tgt)
        side.append(1 if board.turn else -1)
        correct.append(moves.index(move_target))
        for m in moves:
            board.push(m)
            if board.is_checkmate():
                cf,cx=(1000000.0 * (1 if not board.turn else -1)), np.zeros(len(NAMES))
            else:
                cf,cx=features(board)
            board.pop()
            candidate_x.append(cx);candidate_fixed.append(cf)
        offsets.append(len(candidate_x))
    if not main_x:
        raise ValueError('No hay posiciones válidas con teacher_uci y evaluación de Stockfish')
    print(f'🧬 PST posiciones={len(main_x)} candidates={len(candidate_x)} ignored={ignored}', flush=True)
    return (np.asarray(main_x), np.asarray(fixed), np.asarray(labels),
            np.asarray(candidate_x), np.asarray(candidate_fixed),
            np.asarray(offsets), np.asarray(correct), np.asarray(side))


def metrics(params, dataset):
    x, fixed, target, cx, cf, offsets, correct, sides = dataset
    # N samples x population, all vectorized.
    estimate = fixed[:,None] + x @ params.T
    rmse = np.sqrt(np.mean((estimate - target[:,None])**2, axis=0))
    after = cf[:,None] + cx @ params.T
    hits = np.zeros(params.shape[0], dtype=np.int32)
    for j in range(len(correct)):
        a,b = offsets[j:j+2]
        predicted = np.argmax(sides[j]*after[a:b,:], axis=0)
        hits += (predicted == correct[j])
    # Article's squared correct guesses, moderated by teacher value error.
    fitness = (hits.astype(np.float64)+1)**2 / (1 + rmse / 400.0)
    return fitness, hits, rmse


def evolve(dataset, population=100, generations=500, seed=42, on_progress=print):
    rng=np.random.default_rng(seed)
    pop = rng.integers(0,2,size=(population,BITS),dtype=np.uint8)
    best_chrom = None
    best_fitness = -1.
    n = len(dataset[0]); interval=max(1,generations//10)
    for g in range(generations):
        params = decode(pop)
        fitness,hits,rmse=metrics(params,dataset)
        best=int(np.argmax(fitness))
        if fitness[best] > best_fitness:
            best_fitness=float(fitness[best]); best_chrom=pop[best].copy()
        if g==0 or (g+1)%interval==0 or g==generations-1:
            on_progress(f'🧬 Generation {g+1:>5}/{generations:<5} population={population:>5} '
                        f'correct={int(hits[best]):>6}/{n:<6} '
                        f'error_min={float(rmse.min()):>9.2f}cp '
                        f'error_mean={float(rmse.mean()):>9.2f}cp')
        if g == generations - 1: break
        probs = fitness / fitness.sum() if fitness.sum() > 0 else None
        next_pop=[pop[best].copy()]
        while len(next_pop) < population:
            parents=rng.choice(population,size=2,p=probs)
            a,b=pop[parents]
            if rng.random()<.75:
                child=np.where(rng.random(BITS)<.5,a,b).astype(np.uint8)
            else: child=a.copy()
            mutation=rng.random(BITS)<.005
            child ^= mutation.astype(np.uint8)
            next_pop.append(child)
        pop=np.asarray(next_pop,dtype=np.uint8)
    values=decode(best_chrom)[0]
    return {'format':'picogenus-pst-v1', 'encoding':'gray-224', 'pawn_value':100,
            'parameters':{name:int(v) for name,v in zip(NAMES,values)},
            'chromosome_bits':''.join(map(str,best_chrom.tolist())),
            'fitness':best_fitness,'positions':n,'population':population,
            'generations':generations,'seed':seed,'version':'0.1.1'}


def main():
    p=argparse.ArgumentParser(description='Evolución genética PST (David-inspired), aprendizaje desde .pb Stockfish')
    p.add_argument('--in',dest='source',required=True)
    p.add_argument('--out',required=True)
    p.add_argument('--población','--poblacion',type=int,default=100,dest='population')
    p.add_argument('--generaciones',type=int,default=500)
    p.add_argument('--seed',type=int,default=42)
    p.add_argument('--max-positions',type=int,default=0,help='0 = utilizar TODAS; N = reservorio aleatorio de N')
    a=p.parse_args()
    if a.population<2 or a.generaciones<1 or a.max_positions<0:
        p.error('población >=2, generaciones >=1, max-positions >=0')
    try:
        with open_source(a.source) as db:
            rows=load_labeled(db,seed=a.seed,max_rows=a.max_positions,require_move=True)
        data=build_dataset(rows)
        result=evolve(data,a.population,a.generaciones,a.seed)
        dst,tmp=atomic_path(a.out,'.json')
        try:
            tmp.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
            os.replace(tmp,dst)
        finally:
            if tmp.exists():tmp.unlink()
        print(f'✅ PST output={dst} best_fitness={result["fitness"]:.3f}')
    except (ValueError,OSError) as e:
        p.error(str(e))

if __name__=='__main__': main()
