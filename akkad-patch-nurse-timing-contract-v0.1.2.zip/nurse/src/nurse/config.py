"""Declarative configuration, platform selection and deterministic path resolution."""
import json,os,sys,shutil
from pathlib import Path

NATIVE = {"sargon", "sargon-plus", "random", "doc", "microchess", "cerebrum", "keras", "alphazero", "bellman"}
EVALUATORS = {"null","classic","npz","cerebrum","cerebrum-1.1","cerebrum-2","stockfish","lc0","tinygyal","znpz","zclassic","grumpy","keras","microchess","bellmanr"}

def platform_name():
    return "windows" if os.name=="nt" else "macOS" if sys.platform=="darwin" else "debian"

def platform_value(value):
    if isinstance(value,dict):
        p=platform_name()
        names=(p,p.lower(),"macos" if p=="macOS" else p)
        for k in names:
            if k in value:return value[k]
        raise ValueError(f"falta configuración de plataforma {p}")
    return value

def resolve_path(value,brains_path, *, executable=False):
    value=platform_value(value)
    if not isinstance(value,str) or not value.strip():raise ValueError("ruta inválida")
    path=Path(value).expanduser()
    if path.is_absolute():return str(path)
    # The first base is the source configuration; additionally accept the
    # historical Akkad layout (Sargon-NNUE/scripts) for legacy paths.
    bases=[Path(brains_path).resolve().parent,Path(brains_path).resolve().parent.parent.parent,
           Path(brains_path).resolve().parent.parent.parent/'scripts',Path.cwd()]
    # If `brains` sits under nurse/etc/brains, allow Akkad/Sargon-NNUE/scripts.
    for base in [Path(brains_path).resolve().parents[3]/'Sargon-NNUE'/'scripts'] if len(Path(brains_path).resolve().parents)>3 else []:
        bases.append(base)
    candidates=[(base/path).resolve() for base in bases]
    for candidate in candidates:
        if candidate.exists():return str(candidate)
    if executable and len(path.parts)==1 and shutil.which(value):return shutil.which(value)
    raise ValueError(f"ruta inexistente {value!r}; probadas: {', '.join(map(str,candidates))}")

def read_brains(path):
    with open(path,encoding="utf-8-sig") as f:data=json.load(f)
    if not isinstance(data,dict) or not isinstance(data.get("brains"),dict):raise ValueError("se requiere objeto brains")
    return data["brains"]

def read_brain(path,ident):
    brains=read_brains(path)
    if ident not in brains:raise ValueError(f"brain desconocido: {ident}")
    cfg=dict(brains[ident])
    # Shared timing contract, milliseconds, for ALL brain types.
    # tmax is the maximum thinking budget; timeout is communication tolerance.
    for key, default in (("tmax", 15000), ("timeout", 30000)):
        value = cfg.get(key, default)
        if isinstance(value, bool):
            raise ValueError(f"{key} debe ser entero positivo en milisegundos")
        try:
            value = int(value)
        except (TypeError, ValueError) as exc:
            raise ValueError(f"{key} debe ser entero positivo en milisegundos") from exc
        if value < 1:
            raise ValueError(f"{key} debe ser mayor que cero")
        cfg[key] = value
    # Warmup is intentionally as expensive as an ordinary move, by contract.
    # Do not admit a divergent warmup budget in brains.json.
    if "warmup_movetime" in cfg and int(cfg["warmup_movetime"]) != cfg["tmax"]:
        raise ValueError("warmup_movetime debe ser igual a tmax")
    cfg["warmup_movetime"] = cfg["tmax"]
    typ=str(cfg.get("type","")).lower()
    if typ not in {"nurse","uci","external"}:raise ValueError(f"type inválido: {typ}")
    if "ELO" in cfg and (isinstance(cfg["ELO"],bool) or not isinstance(cfg["ELO"],(int,float))):raise ValueError("ELO inválido")
    if typ=="nurse":
        name=str(cfg.get("player","")).replace(".py","").replace("_","-").lower()
        if name not in NATIVE:raise ValueError(f"player no portado: {name}")
        ev=cfg.get("evaluator","null")
        if ev is None:ev="null"
        evname=str(ev).replace(".py","").lower() if not isinstance(ev,dict) else ""
        if evname not in EVALUATORS:
            if not isinstance(ev,str):raise ValueError(f"evaluador no soportado: {ev}")
            cfg["_evaluator_path"]=resolve_path(ev,path,executable=True)
            evname='external-evaluator'
        cfg["_player"]=name;cfg["_evaluator"]=evname
        if cfg.get("network"):cfg["_network"]=resolve_path(cfg["network"],path)
        args=cfg.get("arguments",{})
        if not isinstance(args,dict):raise ValueError("arguments requiere objeto")
        if "Depth" in cfg and int(cfg["Depth"])<1:raise ValueError("Depth debe ser >=1")
    elif typ=="uci":
        if str(cfg.get("evaluator","null")).lower()!="null":raise ValueError("type=uci requiere evaluator=null")
        cfg["_engine"]=resolve_path(cfg.get("player"),path,executable=True)
        args=cfg.get("args",[])
        if not isinstance(args,list) or not all(isinstance(a,str) for a in args):raise ValueError("args debe ser lista de strings")
    else:
        if not isinstance(cfg.get("ipaddress"),str) or not (1<=int(cfg.get("port",0))<=65535):raise ValueError("endpoint TCP inválido")
        if float(cfg.get("retry",5))<=0:raise ValueError("retry debe ser positivo")
    cfg["_type"]=typ
    return cfg
