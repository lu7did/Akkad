# picoAlpha MCTS Genesis — Rust/Bullet v0.1.0 (experimental)

**Architecture source:** Akkad `main` at commit `2b5b0735a121abbf5361673a9bca25f0514a951f` (`picoAlpha/src/nnue.cpp`, `picoAlpha/ARM/src/nnue_int8.cpp`, `nurse/src/nurse/mcts_nnue.py`).
**Bullet API source:** `jw1912/bullet` at commit `5d70177680437b7c0ddf958bd4722d95afa78b0c`.

This is not the previous SQLite/PyTorch trainer. It builds a **new Rust Bullet graph** using `ModelDefinition`, `ModelInputsMapper`, `ReadMapLoader`, `AdamW` and Metal. There is no PyTorch dependency in the training or export chain. It does not touch Bashful/Grumpy/BNN weights or checkpoints.

## Installation and run

Extract this ZIP **inside the root of the existing Bullet checkout** (`~/github/Bobby/bullet`), replacing the earlier Python `run_genesis_mcts.sh` if installed. The earlier MCTS run directory is left untouched because this script uses `runs/mcts-bullet-rust-001/` by default.

```bash
cd ~/github/Bobby/bullet
bash run_genesis_mcts.sh --mon 1
# After interruption, simply:
bash run_genesis_mcts.sh
# Show current state:
bash run_genesis_mcts.sh --status
```

Defaults are the same T79 training and T77 validation `.binpack` files previously used for Bashful/BNN, with override environment variables `TRAIN_DATA`, `VALID_DATA` and `BULLET_DIR`.

| MON | Implementation | Output |
|---|---|---|
| 1 | Verify sources, Cargo, dataset; record configuration and Bullet commit | `config.lock` |
| 2 | Install isolated Rust files in `examples/`, append 2 Cargo example records, build both with Metal; execute Rust unit tests | `target/release/examples/mcts_picoalpha_bullet_{train,validate}` |
| 3 | Train Rust dual-head graph jointly on T79; checkpoint optimizers+FP32 weights | `checkpoints/<runid>-<SB>/raw.bin` and `optimiser_state/` |
| 4 | Compute post-INT8 validation value MSE, FROM/TO CE and accuracies on T77; select using validation objective | `validation.csv` |
| 5 | Quantize best checkpoint and generate exact C++/ARM PANNI8 contract | `export/best_int8.bin`, `picoalpha_nnue_weights.hpp`, `best_int8.json`, `report.json` |
| 6 | Audit binary header, byte count, tensor dimensions and numerical serialization parity | `export/audit.json` |

The script **stops on failure**, preserves MON and refuses changed parameters for the same RUN_ID. To start a genuinely new run use a different `RUN_ID`. Checkpoints are reusable including AdamW optimizer state.

## Model architecture: exactly picoAlpha (no architectural change)

- One shared feature-transform layer `W_INPUT`: `780 x 16`, sparse sum, ReLU; no bias.
- Value `W_VALUE`: `1 x 16`, `tanh`; output is normalized in `[-1,1]` from the side to move.
- Policy `W_FROM`: `64 x 16`, and `W_TO`: `64 x 16`; the logit for each legal move is `F[from] + T[to]`, using side-oriented square indices. picoAlpha applies the softmax **only over legal moves** at inference.
- Features: 768 piece/square (`12x64`), own K/Q + opponent K/Q castling (4), en passant file (8). The player-to-move's pieces are first; orientation is white a8-based, black 180° rotated.

There are 14,544 INT8 parameters. The portable C++ `.bin` file uses **`PANNI8\r\n`** magic, version 1, `780`, `16`, four float32 scales and four row-major signed INT8 matrices, for **14,580 bytes**, the exact ABI read by `picoAlpha/src/nnue.cpp`. Its generated `.hpp` has the names expected by `picoAlpha/ARM/src/nnue_int8.cpp` and can be copied into `picoAlpha/ARM/assets` only after successful auditing.

**Important**: `nurse.mcts_nnue.TinyEvaluator` currently requires an INT8 PyTorch `.pt` dictionary. This project does **not** invent such a file: for Nurse, an additional PANNI8 `.bin` reader or converter will be needed. The `.bin` and `.hpp` are intended for the existing C++ and ARM implementations.

## Data provenance and loss

- The reader directly consumes Stockfish's original `sfbinpack` records and preserves `pos`, `score`, `result`, and **recorded move** `mv`. No SQLite, no PGN, no on-the-fly Stockfish labeling.
- The original Bullet `SfBinpackLoader` throws away the move. `mcts_data.rs` is the separate loader that retains this information.
- The value target is `0.5*(1 + [CP_BLEND*tanh(score/400) + (1-CP_BLEND)*result])`. The training output is `sigmoid(2*raw_value)` and C++ inference is `tanh(raw_value)`, exactly consistent. `score` and `result` are stored from the side-to-move viewpoint by sfbinpack.
- Policy target is a one-hot **recorded move** (FROM + TO); the model minimizes cross-entropy for both square distributions, alongside value MSE. Default `POLICY_WEIGHT=0.01` is intentionally conservative because policy labels are weaker than CP targets.
- The recorded move is **not** an MCTS visit distribution or necessarily the best move of Stockfish. This first implementation measures whether both heads learn; it is **supervised move prediction**, not AlphaZero policy improvement. A stronger policy would require additional MultiPV/MCTS visit labels and potentially a legal-move-masked loss.
- Binpack castling is commonly encoded king-captures-rook: `mcts_data.rs` converts such targets to the king's actual destination square.
- Like picoAlpha's current contract, promotions with identical from/to squares are not distinguished by policy.
- T79 is train, T77 is held-out validation. A deterministic in-memory block shuffle is used by the reader. No SQLite split or label leakage.

### Configurable settings

```bash
SUPERBATCHES=50 SAVE_EVERY=10 BATCH_SIZE=4096 BATCHES_PER_SB=128 \
POLICY_WEIGHT=0.01 CP_BLEND=1.0 VALID_COUNT=200000 \
RUN_ID=mcts-pilot-001 bash run_genesis_mcts.sh --mon 1
```

`POLICY_WEIGHT` changes the loss balance; `CP_BLEND=1` uses CP teacher only, `CP_BLEND=0` uses final game outcome only. Default value checkpoint selection: `value_mse/4 + POLICY_WEIGHT * (CE_from + CE_to)` on quantized weights. The `/4` converts tanh-space MSE to the same scale as sigmoid-space training MSE.

## Verification status and limitations

- Audited the API sources, data contract and C++/ARM file layout at the commits above.
- Verified shell syntax with `bash -n` and Python syntax; Python export unit tests cover the matrices' column-major -> row-major layout, exact 14,580-byte file, corruption rejection and 256 synthetic inference checks.
- **Not yet compiled with Rust/Metal**: the execution environment used to assemble this artifact has no `cargo`/`rustc`, T79/T77 datasets or Apple Metal GPU. The first real compile on your Mac at MON=2 is required. No claim of training convergence, Metal compatibility, or C++/ARM runtime parity is made until run-time tests pass.
- No changes have been made to your GitHub repository. The package includes files for your local Bullet checkout.

## File list

- `run_genesis_mcts.sh`
- `mcts_genesis/mcts_data.rs` (SF binpack data loader + exact picoAlpha 780 mapping + unit tests)
- `mcts_genesis/mcts_train.rs` (real Rust graph and multihead loss/optimizer)
- `mcts_genesis/mcts_validate.rs` (held-out T77 quantized metrics)
- `mcts_genesis/mcts_export.py` (PANNI8 + header + neutral JSON)
- `mcts_genesis/mcts_audit.py` (contract & numerical checks)
- `mcts_genesis/test_export.py` (unit tests)

No `picoAlpha` files, previous Bullet examples, or original models are overwritten. MON=2 does append two uniquely named records to Bullet's `crates/bullet_lib/Cargo.toml` and add three uniquely named Rust files under `examples/`.
