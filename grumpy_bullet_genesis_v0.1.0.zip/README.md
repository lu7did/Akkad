# Bullet → Grumpy GRMP0001 — Genesis

**Ubicación:** colocar `run_genesis.sh` y la carpeta `grumpy_genesis/` en `~/github/Bobby/bullet/` (o ejecutar desde otro directorio especificando `BULLET_DIR`).

```bash
cd ~/github/Bobby/bullet
bash run_genesis.sh --mon 1
```

Reanudar luego de una interrupción:

```bash
bash run_genesis.sh
```

Consultar estado:

```bash
bash run_genesis.sh --status
```

Opcionalmente, comparar con el binario original de Grumpy:

```bash
REFERENCE="$HOME/github/Bobby/akkad/picoSargon/assets/grumpy.bin" bash run_genesis.sh --mon 1
```

`REFERENCE` forma parte del bloqueo de configuración: debe permanecer igual durante toda la ejecución. Si falta, el entrenamiento funciona pero el informe no compara contra la referencia.

## Etapas y salidas

1. **MON 1**: verifica binpack y bloquea configuración en `runs/<RUN_ID>/config.lock`.
2. **MON 2**: copia dos ejemplos Rust independientes a `examples/`, añade sus entradas a `crates/bullet_lib/Cargo.toml` si faltan y compila con `--features metal`.
3. **MON 3**: entrena FP32 con T79, `GRMP192 → 8×2 → 8 buckets`, objetivo **residuo contra material fijo**. Recupera el último checkpoint con estado completo de optimizador.
4. **MON 4**: valida FP32 y versión redondeada de 6 bits sobre **las mismas** dos millones de posiciones T77; opcionalmente también `grumpy.bin` original. Guarda `validation.csv`.
5. **MON 5**: selecciona checkpoint con mínimo MSE cuantizado, genera `grumpy_new.bin` de 1304 bytes y `report.json`.
6. **MON 6**: verifica firma, tamaño, SHA256 y equivalencia de inferencia entre el modelo cuantizado y el binario exportado. Guarda `final_validation.csv`.

### Especificación

- Entradas: 192 características factorizadas (12 grupos de pieza/color × (8 filas + 8 columnas)). Cada pieza activa dos entradas por perspectiva.
- Primera capa: 192×8, sesgo 8; perspectivas compartidas STM/NTM.
- Activación: CReLU `[0,1]` para pesos FP32 reescalados; en GRMP es `clamp(round(32*a),0,32)`.
- Salida: 8 buckets de material, 16 pesos + 1 sesgo cada uno.
- Material fijo: mismo factor `0x3847D12C4B064` que el evaluador picoSargon.
- Parámetros: 1.680 FP32; empaquetados a 1.680×6 bits con cabecera `GRMP0001` de 44 bytes.
- El entrenamiento de la red FP32 utiliza MSE(sigmoid(logit),sigmoid((score_STM-material_STM)/400)), AdamW, WDL=0. **No es el entrenamiento WDL=0,75 del modelo de 128 neuronas previo**.
- Exportación: primera capa y sesgos `round(32*x)`, pesos salida `round(32*x)`, sesgos salida `round(128*x)`, límites −31..32, reordenando pesos salida de `16×8` a `8×16`.

**Limitaciones:**
- No incorpora entrenamiento consciente de cuantización (QAT). El archivo final es compatible con el *formato* Grumpy, pero la cuantización podría disminuir su calidad. El informe incluye el número de coeficientes saturados.
- No se ha compilado ni ejecutado contra la instalación Metal de macOS del usuario; la compilación MON 2 es la primera prueba de integración real. No declarar éxito de aprendizaje o equivalencia numérica sin los resultados.
- T77 se usa para elegir el checkpoint, de modo que no es un conjunto de test independiente para estimar su generalización definitiva. La fuerza debe establecerse por benchmark con Nurse y partida real.
- `MON.state` asegura reenganche **entre etapas**. Durante MON=3, se reanuda desde el último checkpoint completo registrado cada `SAVE_EVERY` superbatches, no desde cada batch.
- Usar un RUN_ID distinto para nuevas configuraciones, sin sobrescribir modelos anteriores.
