# Bullet BNN genesis v0.1.0 — independiente de Grumpy/Bashful

**Objetivo:** entrenar con Bullet Metal una red híbrida BNN de valor ajedrecístico (Chess768 → dos perspectivas de 32 unidades → una salida), entrenando pesos maestros FP32 con forward binario y gradiente STE. Se utiliza T79 para aprendizaje y T77 para selección/validación. **No produce `GRMP0001` ni modifica `grumpy.bin` o `bashful.bin`.**

## Instalación

Copiar **`run_genesis_bnn.sh` y `bnn_genesis/`** al directorio raíz de la instalación Bullet (`~/github/Bobby/bullet/`), sin sobrescribir la cadena de Bashful.

```bash
cd ~/github/Bobby/bullet
bash run_genesis_bnn.sh --mon 1
```

Retomar donde se interrumpió:

```bash
bash run_genesis_bnn.sh
bash run_genesis_bnn.sh --status
```

Configuración opcional desde variables de entorno (se bloquea al MON=1): `BULLET_DIR`, `RUN_ID` (por defecto `bnn-bullet-001`), `TRAIN_DATA`, `VALID_DATA`, `SUPERBATCHES` (100), `SAVE_EVERY` (10), `BATCH_SIZE` (4096), `BATCHES_PER_SB` (256), `LR_START` (0.001), `LR_FINAL` (0.0001), `VALID_COUNT` (2000000). Para otro entrenamiento o configuración, usar un nuevo `RUN_ID`; nunca modificar el `config.lock` existente.

MON 1 verifica archivos y crea el bloqueo de configuración. MON 2 copia exclusivamente ejemplos con prefijo `bnn_`, añade entradas `[[example]]` si faltan en `crates/bullet_lib/Cargo.toml` y compila ambos con `--features metal`. MON 3 entrena con checkpoint completo de optimizador cada `SAVE_EVERY` superbatches; reanuda desde el más reciente. MON 4 valida cada checkpoint sobre la misma pasada por T77, con los pesos de primera capa en ±1. MON 5 elige el menor MSE validado y exporta `.bnn`. MON 6 verifica la exportación y la equivalencia numérica entre el checkpoint y el `.bnn` en la misma pasada de validación. MON 7 es finalizado.

## Arquitectura y matemática

- Entrada `Chess768` dispersa original de Bullet (sin otras características).
- Primera capa compartida: `l0w`: 768×32 pesos maestros FP32; `l0b`: 32 sesgos FP32.
- Forward **binario**, no una cuantización posterior:
  `binary(w) = 2 * faux_quantise((clip_pass_through_grad(w,-1,1)+1)/2,1,round=true) - 1`, y peso aplicado `binary(w)/16`.
- La operación `faux_quantise` de Bullet deja pasar el gradiente en backward; la expresión resultante tiene derivada STE distinta de cero. Los pesos maestros siguen siendo FP32 para AdamW y checkpoints.
- Activación CReLU: clamp(x,0,1) en ambas perspectivas.
- Segunda capa: `l1w`: 64 parámetros FP32 y `l1b`: 1 sesgo FP32.
- Pérdida: `MSE(sigmoid(raw_output), blend)` de Bullet, `eval_scale=400`, WDL=0.75, scheduler coseno, AdamW. El valor es desde el lado que mueve.

**BNN híbrida**: solo los 24.576 pesos de la primera capa son binarios. Las activaciones, los sesgos y la salida son FP32. Esto es intencional. No se afirma XNOR/POPCOUNT ni aceleración ARM. No es una BNN totalmente binaria.

## Binario BULBNN01

- Ruta: `runs/bnn-bullet-001/bnn-bullet-001.bnn`.
- Cabecera: 64 bytes; magic ASCII `BULBNN01` (8), input count (u32 LE=768), hidden units (u32 LE=32), escala (f32 LE=16), parámetros FP32 de cola (u32 LE=97), SHA256 del payload (32), reservado (8).
- Payload: 3.072 bytes para los 24.576 pesos binarios, LSB-first, bit `1` = +1 y bit `0` = -1; luego 97 valores FP32 LE (`l0b` 32, `l1w` 64, `l1b` 1).
- **Longitud total: 3.524 bytes.**
- La primera capa se interpreta en orden `feature*32 + unit`, igual que el checkpoint de Bullet. Dos perspectivas comparten dicha matriz.

Evaluar una posición desde la raíz de Bullet, sin librerías externas:

```bash
python3 bnn_genesis/bnn_export.py \
  --verify runs/bnn-bullet-001/bnn-bullet-001.bnn \
  --fen 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1'
```

`score_white_cp` es el puntaje desde perspectiva blanca. Este evaluador Python es independiente y solo verifica inferencia; **Nurse y picoSargon actualmente NO pueden cargar `.bnn`**. Para medir fuerza en Nurse habrá que desarrollar después su evaluador BNN, sin tocar Grumpy.

## Condiciones de verificación y límites

- Se proporciona `bnn_genesis/test_bnn_export.py` con pruebas de codec, hash, rechazo de NaN y FEN.
- No se garantiza que el grafo de Bullet con `faux_quantise` y matmul disperso compile en Metal sin probar en tu copia local. El MON=2 falla explícitamente si no compila; no sustituye silenciosamente el entrenamiento por FP32 ordinario.
- El MSE de validación no demuestra fuerza Elo. Seleccionar checkpoints usando T77 convierte T77 en conjunto de selección, no un test estadísticamente independiente.
- En MON 6 el `.bnn` y su checkpoint se evalúan en la **misma** pasada de T77, evitando discrepancias por muestreo aleatorio entre validaciones distintas.
- La función `score_fen` implementa la misma normalización por perspectiva de Bullet. La equivalencia de inferencia con Rust debe verificarse con la salida real una vez compilado el ejemplo.
- Nunca colocar este paquete encima de `run_genesis.sh`, `grumpy_genesis/`, `grumpy.bin` ni `bashful.bin`.
