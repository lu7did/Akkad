"""picoBit v0.1.27: entrenamiento BNN residual Sargon + Stockfish.

Requisitos: Python 3.10+, torch, numpy, python-chess. Base .pb = SQLite de picoAlpha.
No utiliza TensorFlow ni altera modelos productivos.
Formato: 12x64 piece-square + turno + 4 derechos enroque + 8 en-passant = 781.
POV de Sargon, Stockfish y salida final: blancas. Sargon sin convertir a cp antes de calibrar.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import math
import random
import sqlite3
import sys
from datetime import datetime
from pathlib import Path

import chess
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from sargon import evaluate_sargon

VERSION = '0.1.27'
INPUT_DIM = 781
FIRST = 64
SECOND = 64
PIECE_DIM = 768
DEFAULT_CLIP = 1500.0


class SignSTE(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x):
        ctx.save_for_backward(x)
        return torch.where(x >= 0, torch.ones_like(x), -torch.ones_like(x))

    @staticmethod
    def backward(ctx, gradient):
        (x,) = ctx.saved_tensors
        return gradient * (x.abs() <= 1).to(gradient.dtype)


def sign_ste(x):
    return SignSTE.apply(x)


def fake_int8_rowwise(weights):
    """QAT INT8 simétrica por neurona: pesos maestros FP32, STE de redondeo.

    La escala de cada fila se calcula sobre los pesos latentes y no recibe
    gradiente. La inferencia exportada reproduce exactamente la discretización.
    """
    scale = weights.detach().abs().amax(dim=1, keepdim=True).clamp(min=1e-8) / 127.0
    q = torch.clamp(torch.round(weights / scale), -127, 127)
    dequant = q * scale
    return weights + (dequant - weights).detach()


class ResidualBNN(nn.Module):
    def __init__(self, input_dim=INPUT_DIM, hidden=FIRST):
        super().__init__()
        if hidden != 64:
            raise ValueError('Arquitectura aprobada: ocultas de 64 bits para XNOR uint64')
        self.input_dim = input_dim
        self.hidden = hidden
        self.fc1 = nn.Linear(input_dim, 64, bias=False)
        self.bn1 = nn.BatchNorm1d(64)
        self.fc2 = nn.Linear(64, 64, bias=False)
        self.bn2 = nn.BatchNorm1d(64)
        self.fc_out = nn.Linear(64, 1)
        nn.init.kaiming_normal_(self.fc1.weight, nonlinearity='linear')
        nn.init.kaiming_normal_(self.fc2.weight, nonlinearity='linear')

    def forward(self, x):
        h1 = F.linear(x, fake_int8_rowwise(self.fc1.weight))
        a1 = sign_ste(self.bn1(h1))
        w2 = self.fc2.weight
        alpha = w2.detach().abs().mean(dim=1, keepdim=True).clamp(min=1e-8)
        h2 = F.linear(a1, sign_ste(w2) * alpha)
        a2 = sign_ste(self.bn2(h2))
        return self.fc_out(a2).squeeze(-1)


def fen_to_features(board):
    x = np.zeros(INPUT_DIM, dtype=np.float32)
    for square, piece in board.piece_map().items():
        plane = (0 if piece.color == chess.WHITE else 6) + piece.piece_type - 1
        x[plane * 64 + square] = 1
    x[768] = float(board.turn == chess.WHITE)
    for idx, (color, side) in enumerate(((chess.WHITE, True), (chess.WHITE, False),
                                         (chess.BLACK, True), (chess.BLACK, False))):
        x[769 + idx] = float(board.has_kingside_castling_rights(color) if side else
                              board.has_queenside_castling_rights(color))
    if board.ep_square is not None:
        x[773 + chess.square_file(board.ep_square)] = 1
    return x


def position_key(fen):
    return ' '.join(fen.split()[:4])


def is_quiet(board):
    """Definición operativa conservadora: no jaque, no capturas legales ni promociones.

    NO equivale a quiescence search ni garantiza ausencia de tácticas a futuro.
    """
    if board.is_check() or board.is_game_over(claim_draw=True):
        return False
    for move in board.legal_moves:
        if board.is_capture(move) or move.promotion is not None:
            return False
    return True


def load_rows(database, scan_limit=0, quiet_only=True):
    path = Path(database).resolve()
    if not path.is_file():
        raise FileNotFoundError(path)
    conn = sqlite3.connect(f'file:{path.as_posix()}?mode=ro', uri=True)
    stats = {'scanned': 0, 'invalid_fen': 0, 'not_quiet': 0,
             'mate_or_missing_cp': 0, 'duplicate_state': 0, 'accepted': 0}
    found = {}
    try:
        cols = {r[1] for r in conn.execute('PRAGMA table_info(positions)')}
        needed = {'id', 'fen', 'teacher_cp', 'teacher_mate', 'teacher_at'}
        if not needed.issubset(cols):
            raise ValueError(f'Esquema SQLite incompatible; faltan {sorted(needed-cols)}')
        query = ('SELECT id, fen, teacher_cp, teacher_mate FROM positions '
                 'WHERE teacher_at IS NOT NULL ORDER BY id')
        for pid, fen, cp, mate in conn.execute(query):
            if scan_limit and stats['scanned'] >= scan_limit:
                break
            stats['scanned'] += 1
            if cp is None or mate is not None or not math.isfinite(float(cp)):
                stats['mate_or_missing_cp'] += 1
                continue
            try:
                board = chess.Board(fen)
                if not board.is_valid():
                    raise ValueError('FEN ilegal')
            except (ValueError, TypeError):
                stats['invalid_fen'] += 1
                continue
            if quiet_only and not is_quiet(board):
                stats['not_quiet'] += 1
                continue
            k = position_key(fen)
            if k in found:
                stats['duplicate_state'] += 1
                continue  # primer ID gana, por orden creciente
            white_cp = float(cp) * (1 if board.turn == chess.WHITE else -1)
            found[k] = {'id': int(pid), 'fen': fen, 'sf_cp': white_cp,
                        'sargon': float(evaluate_sargon(board))}
        stats['accepted'] = len(found)
        return list(found.values()), stats
    finally:
        conn.close()


def split_records(rows, sample, validation, seed):
    if len(rows) < 3:
        raise ValueError('Se requieren al menos tres posiciones elegibles')
    if sample < 0 or sample > len(rows):
        raise ValueError(f'--sample debe estar entre 0 y {len(rows)} (0=todas)')
    rng = random.Random(seed)
    selected = rng.sample(rows, sample if sample else len(rows))
    nval = round(len(selected) * validation / 100)
    if nval < 1 or nval >= len(selected):
        raise ValueError('Porcentaje de validación deja un conjunto vacío')
    return selected[nval:], selected[:nval]


def fit_calibration(train_rows, clip):
    s = np.asarray([r['sargon'] for r in train_rows], np.float64)
    t = np.clip([r['sf_cp'] for r in train_rows], -clip, clip).astype(np.float64)
    variance = float(np.var(s))
    if variance < 1e-10:
        raise ValueError('Sargon constante en entrenamiento: calibración no identificable')
    alpha = float(np.mean((s - s.mean()) * (t - t.mean())) / variance)
    beta = float(t.mean() - alpha * s.mean())
    return alpha, beta


def targets(rows, alpha, beta, clip):
    s = np.asarray([r['sargon'] for r in rows], np.float32)
    sf = np.clip(np.asarray([r['sf_cp'] for r in rows], np.float32), -clip, clip)
    sc = np.clip(alpha * s + beta, -clip, clip)
    residual = np.clip(sf - sc, -clip, clip)
    return residual.astype(np.float32)


def feature_matrix(rows):
    return np.stack([fen_to_features(chess.Board(r['fen'])) for r in rows]).astype(np.float32)


def sigmoid_loss(pred_cp, target_cp, temperature):
    # Regresión probabilística: etiqueta continua sigmoid(residual_cp / T),
    # predicción sigmoid(logit_cp/T). BCE con soft labels, NO clasificación.
    probabilities = torch.sigmoid(target_cp / temperature)
    return F.binary_cross_entropy_with_logits(pred_cp / temperature, probabilities)


def predict_np(model, matrix, device, batch):
    model.eval()
    outs = []
    with torch.no_grad():
        for start in range(0, len(matrix), batch):
            x = torch.from_numpy(matrix[start:start+batch]).to(device)
            outs.append(model(x).cpu().numpy())
    return np.concatenate(outs)


def measures(rows, predictions, alpha, beta, clip):
    sf = np.clip(np.asarray([r['sf_cp'] for r in rows], np.float64), -clip, clip)
    sc = np.clip(alpha * np.asarray([r['sargon'] for r in rows], np.float64) + beta, -clip, clip)
    combined = sc + np.asarray(predictions, np.float64)
    def calc(p):
        diff = p - sf
        tested = np.abs(sf) >= 100
        signs = np.mean(np.sign(sf[tested]) == np.sign(p[tested])) if tested.any() else None
        return {'mae_cp': float(np.mean(np.abs(diff))),
                'rmse_cp': float(np.sqrt(np.mean(diff**2))),
                'bias_cp': float(np.mean(diff)),
                'sign_accuracy_nonzero_100cp': None if signs is None else float(signs),
                'sign_tested': int(tested.sum())}
    return {'sargon_cal': calc(sc), 'sargon_plus_bnn': calc(combined)}


def checkpoint_read(path, device='cpu'):
    try:
        ck = torch.load(path, map_location=device, weights_only=True)
    except TypeError:
        raise RuntimeError('Se requiere PyTorch con soporte torch.load(weights_only=True)')
    if ck.get('format') != 'picobit-residual-bnn-v1':
        raise ValueError('Checkpoint incompatible con el modelo residual')
    conf = ck['config']
    if conf['input_dim'] != INPUT_DIM or conf['hidden'] != 64:
        raise ValueError('Arquitectura incompatible')
    model = ResidualBNN(INPUT_DIM, 64).to(device)
    model.load_state_dict(ck['state_dict'], strict=True)
    model.eval()
    return model, ck


def main(argv=None):
    ap = argparse.ArgumentParser(description=f'picoBit train.py v{VERSION} — Sargon + BNN residual')
    ap.add_argument('--in', dest='database', default=None, help='SQLite .pb de picoAlpha, teacher Stockfish')
    ap.add_argument('--sample', type=int, default=0, help='Muestra sin reemplazo; 0 = todas las elegibles')
    ap.add_argument('--validation', type=float, default=20.0, help='Porcentaje validación, default 20')
    ap.add_argument('--out', default=None, help='Directorio de corrida (nuevo)')
    ap.add_argument('--epoch', type=int, default=50)
    ap.add_argument('--batch', type=int, default=256)
    ap.add_argument('--lr', type=float, default=0.003)
    ap.add_argument('--seed', type=int, default=42)
    ap.add_argument('--clip', type=float, default=DEFAULT_CLIP)
    ap.add_argument('--sigmoid-temperature', type=float, default=400.0)
    ap.add_argument('--scan-limit', type=int, default=0, help='Máximo registros SQLite; 0=todos')
    ap.add_argument('--weight-decay', type=float, default=1e-4)
    ap.add_argument('--all-positions', action='store_true', help='Desactivar filtro quiet, decisión explícita')
    ap.add_argument('--device', default='auto', choices=['auto', 'cpu', 'cuda', 'xpu', 'mps'])
    ap.add_argument('--self-test', action='store_true', help='Validar modelo sin abrir base ni entrenar')
    args = ap.parse_args(argv)
    if (not 0 < args.validation < 100 or args.epoch < 1 or args.batch < 2 or
        args.lr <= 0 or args.clip <= 0 or args.sigmoid_temperature <= 0 or
        args.scan_limit < 0 or args.sample < 0 or args.weight_decay < 0):
        ap.error('Parámetros inválidos: revisar porcentajes, tamaños, LR y clipping')
    if args.self_test:
        model = ResidualBNN().train()
        pred = model(torch.zeros((4, INPUT_DIM)))
        sigmoid_loss(pred, torch.zeros_like(pred), args.sigmoid_temperature).backward()
        assert pred.shape == (4,) and all(v.grad is not None for v in model.parameters())
        print('✅ SELF-TEST: forward, backward, gradientes y dimensiones correctos')
        return 0
    if not args.database:
        ap.error('--in es obligatorio salvo con --self-test')
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    if args.device == 'auto':
        device = 'cuda' if torch.cuda.is_available() else ('mps' if hasattr(torch.backends,'mps') and torch.backends.mps.is_available() else 'cpu')
    else:
        device = args.device
    root = Path(__file__).resolve().parents[2]
    out = Path(args.out).resolve() if args.out else root / 'data' / 'residual_bnn' / datetime.now().strftime('%Y%m%d-%H%M%S-%f')
    if out.exists():
        raise FileExistsError(f'La corrida ya existe: {out}')
    print(f'⚙️ picoBit BNN residual v{VERSION} | device={device} | fuente={args.database}', flush=True)
    rows, selection = load_rows(args.database, args.scan_limit, not args.all_positions)
    print(f'📊 Elegibles={len(rows)} descartes={selection}', flush=True)
    train_rows, val_rows = split_records(rows, args.sample, args.validation, args.seed)
    del rows
    alpha, beta = fit_calibration(train_rows, args.clip)
    print(f'⚙️ Calibración sólo TRAIN: alpha={alpha:.9g} cp/punto_Sargon beta={beta:.5f} cp', flush=True)
    print(f'⚙️ TRAIN={len(train_rows)} VALID={len(val_rows)} quiet={not args.all_positions}', flush=True)
    xtr, xva = feature_matrix(train_rows), feature_matrix(val_rows)
    ytr, yva = targets(train_rows, alpha, beta, args.clip), targets(val_rows, alpha, beta, args.clip)
    model = ResidualBNN().to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    schedule = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=args.epoch)
    out.mkdir(parents=True)
    dbpath = Path(args.database).resolve()
    sargon_sha256 = hashlib.sha256((Path(__file__).with_name('sargon.py')).read_bytes()).hexdigest()
    manifest = {
        'format': 'picobit-residual-manifest-v1', 'version': VERSION,
        'database': str(dbpath), 'database_bytes': dbpath.stat().st_size,
        'teacher_cp_pov': 'side-to-move', 'model_pov': 'white',
        'sargon_scale': 'original_user_points', 'sargon_function': 'evaluate_sargon',
        'sargon_sha256':sargon_sha256,
        'seed': args.seed, 'train_ids': [r['id'] for r in train_rows],
        'validation_ids': [r['id'] for r in val_rows],
        'train_fen': [r['fen'] for r in train_rows],
        'validation_fen': [r['fen'] for r in val_rows],
        'validation_stockfish_white_cp': [r['sf_cp'] for r in val_rows],
        'selection': selection, 'filter': 'quiet no-check no-immediate-legal-capture/promotion' if not args.all_positions else 'all-valid-nonterminal',
        'alpha': alpha, 'beta': beta, 'clip_cp': args.clip,
        'sigmoid_temperature_cp': args.sigmoid_temperature,
        'input_dim': INPUT_DIM, 'hidden': 64,
        'hyperparameters': {'epoch':args.epoch, 'batch':args.batch, 'lr':args.lr,
                            'weight_decay':args.weight_decay, 'validation_pct':args.validation},
    }
    (out/'manifest.json').write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding='utf-8')
    config = {'input_dim': INPUT_DIM, 'hidden':64, 'clip_cp':args.clip,
              'sigmoid_temperature_cp':args.sigmoid_temperature,
              'alpha':alpha, 'beta':beta, 'sargon_sha256':sargon_sha256,
              'encoding':'piece-square 768; turn 1; castling 4; enpassant 8',
              'fc1':'int8-per-output-QAT', 'fc2':'binary-XNOR-meanabs-per-output',
              'bn':'BatchNorm before sign', 'out':'fp32 cp residual',
              'loss':'BCEWithLogits(estimated_residual_cp/T, sigmoid(target_residual_cp/T))'}
    best = float('inf')
    gen = torch.Generator().manual_seed(args.seed)
    xtr_cpu = torch.from_numpy(xtr)
    ytr_cpu = torch.from_numpy(ytr)
    history = out/'history.jsonl'
    for epoch in range(1, args.epoch+1):
        model.train()
        permutation = torch.randperm(len(xtr_cpu), generator=gen)
        total_loss = 0.0
        for start in range(0, len(xtr_cpu), args.batch):
            ids = permutation[start:start+args.batch]
            if len(ids) < 2:  # BN requiere al menos dos muestras en train
                continue
            xb, yb = xtr_cpu[ids].to(device), ytr_cpu[ids].to(device)
            opt.zero_grad(set_to_none=True)
            preds = model(xb)
            loss = sigmoid_loss(preds, yb, args.sigmoid_temperature)
            if not torch.isfinite(loss):
                raise FloatingPointError(f'Loss no finita epoch {epoch}')
            loss.backward()
            opt.step()
            with torch.no_grad():
                model.fc2.weight.clamp_(-1, 1)
            total_loss += loss.item() * len(ids)
        schedule.step()
        predicted = predict_np(model, xva, device, args.batch)
        # Selección por misma sigmoid loss, no por MAE material.
        val_loss = float(sigmoid_loss(torch.tensor(predicted), torch.tensor(yva), args.sigmoid_temperature).item())
        metric = measures(val_rows, predicted, alpha, beta, args.clip)
        rec = {'epoch':epoch,'train_loss':total_loss/len(xtr_cpu), 'validation_sigmoid_loss':val_loss,
               'mae_sargon_cp':metric['sargon_cal']['mae_cp'],
               'mae_combined_cp':metric['sargon_plus_bnn']['mae_cp'],
               'lr':opt.param_groups[0]['lr']}
        with history.open('a', encoding='utf-8') as fh:
            fh.write(json.dumps(rec, ensure_ascii=False)+'\n')
        if val_loss < best:
            best = val_loss
            torch.save({'format':'picobit-residual-bnn-v1', 'version':VERSION,
                        'config':config, 'state_dict':{k:v.detach().cpu() for k,v in model.state_dict().items()},
                        'epoch':epoch, 'validation_sigmoid_loss':val_loss},out/'best.pt')
            (out/'best_metrics.json').write_text(json.dumps(metric,indent=2),encoding='utf-8')
        print(f'  E{epoch:03d}/{args.epoch:03d} loss={rec["train_loss"]:.6f} '
              f'validSig={val_loss:.6f} SargonMAE={rec["mae_sargon_cp"]:.2f}cp '
              f'CombinedMAE={rec["mae_combined_cp"]:.2f}cp best={best:.6f}', flush=True)
    print(f'✅ Entrenamiento finalizado | checkpoint={out/"best.pt"}',flush=True)
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except Exception as e:
        print(f'❌ picoBit train: {type(e).__name__}: {e}',file=sys.stderr)
        raise
