# Sargon Micro — Doc + Grumpy v0.1.4 (experimental)

Motor independiente para **Raspberry Pi Pico W / Pico 2 W con MicroPython**. No utiliza `python-chess`, NumPy ni Sargon-NNUE de escritorio en la placa.

## Componentes

- `device/`: **única carpeta que debe subirse a la placa** (`main.py`, `chesscore.py`, `engine.py`, `grumpy.py`, `statusled.py`, `grumpy.bin`, `config.bin`).
- `networks/grumpy.nnx`: versión editable en texto de los 1.680 coeficientes enteros de Grumpy.
- `tools/convert_grumpy.py`: convierte `.nnx` en `.bin` y calcula SHA-256 para integridad.
- `tools/make_config.py`: genera configuración Wi-Fi/UCI.
- `tools/deploy.py`: despliegue con `mpremote`.
- `tests/`: pruebas de escritorio sin dependencias de terceros.

## Construcción (terminal de VS Code, en la raíz)

```powershell
python tools/convert_grumpy.py networks/grumpy.nnx -o device/grumpy.bin
python tools/make_config.py --name "Pico Doc Grumpy" --ssid "TU_WIFI" --port 6110 -o device/config.bin
python -m unittest discover -s tests -p test_grumpy.py -v
```

El utilitario de configuración solicita la contraseña. `config.bin` contiene credenciales **sin cifrado**, mantenerlo fuera de repositorios públicos.

Instalar firmware de **MicroPython para Pico W** y conectar la placa por USB. En Visual Studio Code, la extensión MicroPico sincroniza la carpeta `device` según `.vscode/settings.json` (es imprescindible incluir `.bin`). Alternativa desde terminal:

```powershell
python -m pip install mpremote
python tools/deploy.py --port COM6
```

Reiniciar la placa. Conectarse al TCP/IP indicado por la consola serial, puerto 6110 por defecto, mediante cliente UCI. El servidor acepta una sesión TCP a la vez y admite `uci`, `isready`, `ucinewgame`, `position`, `go`, `stop`, `quit`. Las líneas de UCI y conexión/desconexión se informan por puerto serial, no por el TCP salvo las respuestas UCI. No implementar reconexión durante una partida: una nueva sesión comienza sin tablero previo.

### Indicador LED incorporado

- **Encendido continuo**: inicialización.
- **1 s por ciclo**: disponible escuchando TCP.
- **3 s por ciclo**: cliente UCI conectado.
- **200 ms por ciclo**: error terminal.

### Algoritmo

Doc streamlined: Negamax alfa-beta, iterative deepening, PVS con ventanas nulas en jugadas tardías, LMR, heurísticas killer/history, transposition table de 128 entradas, reverse futility pruning, extensión de jaque y quiescence limitada (4 niveles). Profundidad principal fija hasta 4, no hay `boost`, `turbo` ni perfiles configurables. Se respeta un presupuesto temporal recibido por UCI y se conserva el último nivel completo. El generador de jugadas y las reglas residen en `chesscore.py`.

Grumpy: red factorizada de 1.680 coeficientes cuantizados a 6 bits; conserva dos acumuladores de 8 unidades y 8 buckets de salida, con componente material. Se guarda compacta en RAM (1.680 bytes de coeficientes ya decodificados) sin materializar una matriz entera de pesos. `grumpy.bin` ocupa 1.304 bytes. El `.nnx` y su conversor funcionan en el **PC**, no se suben a la placa.

### Limitaciones de validación

Se verifica el código en CPython y la conversión exacta de la red original. Todavía **no se ha probado en hardware MicroPython**: memoria disponible con Wi-Fi, latencia, búsqueda y robustez de reloj deben medirse en Pico W. La búsqueda es una **adaptación reducida de Doc**, no reproducción árbol-a-árbol del programa de escritorio. El núcleo de reglas requiere más pruebas de conformidad y rendimiento antes de jugar torneos reales.
