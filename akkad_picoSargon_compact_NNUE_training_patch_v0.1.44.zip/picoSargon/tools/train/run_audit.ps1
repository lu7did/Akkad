param([Parameter(ValueFromRemainingArguments=$true)][string[]]$Arguments)
& python (Join-Path $PSScriptRoot 'Audit.py') @Arguments
exit $LASTEXITCODE
