param([Parameter(ValueFromRemainingArguments=$true)][string[]]$Arguments)
& python (Join-Path $PSScriptRoot 'train.py') @Arguments
exit $LASTEXITCODE
