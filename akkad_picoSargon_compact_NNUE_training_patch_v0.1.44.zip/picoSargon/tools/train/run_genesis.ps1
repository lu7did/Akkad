# picoSargon compact 6-bit NNUE training genesis. All paths are anchored to this script.
param(
    [ValidateRange(1,4)][int]$mon = 1,
    [string]$database = '',
    [string]$network = 'pitty',
    [int]$sample = 100000,
    [double]$validation = 20,
    [double]$lr = 0.03,
    [double]$lrmin = 0.001,
    [int]$epoch = 50,
    [int]$batch = 512,
    [int]$seed = 2026,
    [string]$python = 'python'
)
$ErrorActionPreference = 'Stop'
$trainDir = $PSScriptRoot
$root = (Resolve-Path (Join-Path $trainDir '..\..')).Path
$assets = Join-Path $root 'assets'
$data = Join-Path $root 'data'
if (-not $database) { $database = Join-Path (Split-Path $root -Parent) 'picoAlpha\data\history.pb' }
$initial = Join-Path $assets 'grumpy.bin'   # Reference only; NEVER overwritten
$best = Join-Path $assets ("{0}_best.pt" -f $network)
$outputBin = Join-Path $assets ("{0}.bin" -f $network)
$outputHeader = Join-Path $assets ("{0}.h" -f $network)
$manifest = Join-Path $data ("{0}_split.json" -f $network)
$audit = Join-Path $data ("{0}_audit.json" -f $network)
New-Item -ItemType Directory -Force $assets,$data | Out-Null
$MON = $mon
function Invoke-Step([int]$number, [string]$title, [string[]]$params) {
    if ($MON -ne $number) { return }
    Write-Host "⚙️ Paso $number - $title (MON=$MON)"
    & $python @params
    if ($LASTEXITCODE -ne 0) { throw "Paso $number falló ($LASTEXITCODE). MON permanece en $MON" }
    $script:MON = $number + 1
    Write-Host "✅ Paso $number completo; MON=$script:MON"
}
Invoke-Step 1 'TRAIN' @((Join-Path $trainDir 'train.py'), '--in', $database, '--sample', "$sample", '--validation', "$validation", '--lr', "$lr", '--lrmin', "$lrmin", '--epoch', "$epoch", '--batch', "$batch", '--seed', "$seed", '--name', $network, '--init', $initial, '--assets', $assets, '--data', $data)
Invoke-Step 2 'EXPORT' @((Join-Path $trainDir 'export.py'), '--in', $best, '--bin', $outputBin, '--include', $outputHeader, '--symbol', "${network}_network")
Invoke-Step 3 'AUDIT' @((Join-Path $trainDir 'Audit.py'), '--in', $outputBin, '--bin', $initial, '--split', $manifest, '--db', $database, '--out', $audit)
Write-Host "✅ Genesis terminado MON=$MON output=$outputBin"
