param([Parameter(ValueFromRemainingArguments=$true)][string[]]$Arguments)
& python (Join-Path $PSScriptRoot 'export.py') @Arguments
exit $LASTEXITCODE
