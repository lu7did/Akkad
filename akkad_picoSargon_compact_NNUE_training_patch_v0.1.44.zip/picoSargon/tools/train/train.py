"""Quantization-aware training for picoSargon's exact 1680-coefficient GRMP0001 scorer.

SQLite source: picoAlpha positions.teacher_cp is side-to-move centipawns.
Only numeric centipawn labels are used; mate labels are excluded.
"""
import argparse
import hashlib
import json
import math
import random
import sqlite3
import sys
import time
from pathlib import Path

import numpy as np

from network import read_binary, encode_fen, encoded_arrays, convert_teacher_cp, N_CODES


def report(label, done, total, mse=None, games_done=None, games_total=None):
    pct = 100.0 * done / total if total else 100.0
    suffix = f' games={games_done}/{games_total}' if games_total is not None else ''
    suffix += f' MSE(cp²)={mse:.4f}' if mse is not None else ''
    print(f'{label:<15} [{pct:6.2f}%] positions={done}/{total}{suffix}', flush=True)


def open_db(path):
    db = sqlite3.connect(f'file:{Path(path).resolve().as_posix()}?mode=ro', uri=True)
    cols = {row[1] for row in db.execute('PRAGMA table_info(positions)')}
    if not {'id','fen','teacher_cp','teacher_mate','teacher_value'} <= cols:
        raise RuntimeError('SQLite positions must contain id,fen,teacher_cp,teacher_mate,teacher_value')
    return db


def prepare(dbpath, sample, validation, seed, manifest_path):
    db = open_db(dbpath)
    try:
        eligible = db.execute('''SELECT count(*) FROM positions
          WHERE teacher_cp IS NOT NULL AND teacher_mate IS NULL
            AND teacher_value IS NOT NULL''').fetchone()[0]
        if sample < 1 or sample > eligible:
            raise ValueError(f'--sample must be between 1 and {eligible}; requested {sample}')
        # RANDOM() samples without replacement; stable split is persisted below.
        print(f'⚙️ SQLite eligible={eligible} sample={sample} seed={seed} validation={validation:g}%', flush=True)
        t0 = time.monotonic()
        rows = db.execute('''SELECT id, game_id, fen, teacher_cp, teacher_value FROM positions
           WHERE teacher_cp IS NOT NULL AND teacher_mate IS NULL AND teacher_value IS NOT NULL
           ORDER BY RANDOM() LIMIT ?''', (sample,)).fetchall()
        # SQL RANDOM() is not seedable; seed controls the split, not the SQL sample.
        rng = random.Random(seed)
        rng.shuffle(rows)
        nval = round(sample * validation / 100.0)
        if nval == sample:
            raise ValueError('100% validation leaves no training data: choose validation < 100')
        training, valid = rows[nval:], rows[:nval]
        prepared = []
        skipped = []
        for posid, gameid, fen, cp, value in rows:
            try:
                feat = encode_fen(fen)
                if not math.isfinite(float(cp)) or not math.isfinite(float(value)):
                    raise ValueError('nonfinite label')
                expected = math.tanh(float(cp) / 400.0)
                if abs(float(value) - expected) > 1e-5:
                    raise ValueError('teacher_value vs tanh(cp_stm/400) discrepancy')
                prepared.append((int(posid), int(gameid), fen, float(convert_teacher_cp(cp, fen)), feat))
            except Exception as exc:
                skipped.append({'id': int(posid), 'reason': str(exc)})
        prepared_by_id = {x[0]:x for x in prepared}
        train_ids = [int(r[0]) for r in training if int(r[0]) in prepared_by_id]
        val_ids = [int(r[0]) for r in valid if int(r[0]) in prepared_by_id]
        if not train_ids:raise RuntimeError('No valid train positions after checking FENs')
        result = {'version':1,'database':str(Path(dbpath).resolve()), 'seed':seed,
                  'note':'SQL RANDOM() sample is not seed-reproducible; persisted IDs are authoritative',
                  'sample_requested':sample,'validation_percent':validation,
                  'train_ids':train_ids,'validation_ids':val_ids,'excluded':skipped,
                  'total_train':len(train_ids),'total_validation':len(val_ids),
                  'train_games':len({prepared_by_id[x][1] for x in train_ids}),
                  'validation_games':len({prepared_by_id[x][1] for x in val_ids})}
        manifest_path.parent.mkdir(parents=True,exist_ok=True)
        manifest_path.write_text(json.dumps(result,indent=2),encoding='utf-8')
        print(f'✅ Split train={len(train_ids)} ({result["train_games"]} games) '
              f'validation={len(val_ids)} ({result["validation_games"]} games) '
              f'excluded={len(skipped)} elapsed={time.monotonic()-t0:.1f}s',flush=True)
        tr = [prepared_by_id[x] for x in train_ids]
        va = [prepared_by_id[x] for x in val_ids]
        return tr,va
    finally:db.close()


def torch_model():
    import torch
    class GrmpModel(torch.nn.Module):
        def __init__(self, initial):
            super().__init__()
            self.weights = torch.nn.Parameter(torch.tensor(initial, dtype=torch.float32))

        def forward(self, batches):
            f0, f1, buck, mat, turns = batches
            # STE: exact 6-bit quantization in forward, usable gradients backward.
            clamped = self.weights.clamp(-31,32)
            w = clamped + (clamped.round() - clamped).detach()
            def acc(features):
                mask = features >= 0
                safe = features.clamp(min=0)
                base = (safe // 64) * 128
                squares = safe % 64
                channel = torch.arange(8, device=safe.device)
                idx_a = base.unsqueeze(-1) + (squares // 8).unsqueeze(-1)*8 + channel
                idx_b = base.unsqueeze(-1) + 64 + (squares % 8).unsqueeze(-1)*8 + channel
                return w[1536:1544].unsqueeze(0) + ((w[idx_a] + w[idx_b]) * mask.unsqueeze(-1)).sum(1)
            a, b = acc(f0), acc(f1)
            first = torch.where(turns[:,None], a, b)
            second = torch.where(turns[:,None], b, a)
            activation = torch.cat((first,second),1).clamp(0,32)
            coeff = w[1544 + buck[:,None]*16 + torch.arange(16,device=buck.device)]
            total = (activation * coeff).sum(1) + 8*w[1672+buck]
            # Exact integer truncation toward zero in forward; STE for gradient.
            scaled = total * (400.0/1024.0)
            exact = torch.trunc(scaled)
            neural = scaled + (exact-scaled).detach()
            return neural*torch.where(turns,1.0,-1.0) + mat
    return GrmpModel


def make_batches(records, batch_size, device):
    import torch
    items = [r[4] for r in records]
    features = encoded_arrays(items)
    arrays = [torch.as_tensor(arr,device=device) for arr in features]
    y = torch.tensor([r[3] for r in records],dtype=torch.float32,device=device)
    return arrays,y


def run_epoch(model, arrays, targets, batch_size, phase, games=None, optimizer=None, seed=0):
    import torch
    size = len(targets)
    if size == 0:return None
    indices = list(range(size))
    if optimizer is not None:random.Random(seed).shuffle(indices)
    chunks = math.ceil(size/batch_size)
    block = max(1, chunks//20)
    sum_sq = 0.0
    seen_games = set()
    games_total = len(set(games)) if games is not None else None
    model.train(optimizer is not None)
    for k in range(chunks):
        idx = indices[k*batch_size:(k+1)*batch_size]
        if games is not None: seen_games.update(games[i] for i in idx)
        batch = [a[idx] for a in arrays]
        with torch.set_grad_enabled(optimizer is not None):
            prediction = model(batch)
            # Optimize cp MSE /400² so gradient scale is well-conditioned.
            error = prediction - targets[idx]
            loss = (error/400.0).square().mean()
            if optimizer is not None:
                optimizer.zero_grad(set_to_none=True)
                loss.backward()
                optimizer.step()
        sum_sq += float(error.detach().square().sum().item())
        if (k+1) % block == 0 or k+1 == chunks:
            done = min(size,(k+1)*batch_size)
            report(phase,done,size,sum_sq/done, len(seen_games) if games is not None else None, games_total)
    return sum_sq/size


def main():
    p = argparse.ArgumentParser(description='Train 1680-weight 6-bit GRMP0001 network (white POV outputs)')
    p.add_argument('--in',dest='database',required=True,help='picoAlpha SQLite .pb database')
    p.add_argument('--sample',type=int,required=True)
    p.add_argument('--validation',type=float,default=20.0,help='percentage [0,100]')
    p.add_argument('--lr',type=float,default=0.03)
    p.add_argument('--lrmin',type=float,default=0.001)
    p.add_argument('--epoch',type=int,default=50)
    p.add_argument('--name',default='pitty')
    p.add_argument('--seed',type=int,default=2026)
    p.add_argument('--batch',type=int,default=512)
    p.add_argument('--init',help='Optional GRMP0001 start weights, read only')
    p.add_argument('--assets',help='Checkpoint directory (default picoSargon/assets)')
    p.add_argument('--data',help='Manifest/log directory (default picoSargon/data)')
    p.add_argument('--device',default='cpu',help='torch device: cpu or cuda')
    a = p.parse_args()
    if not 0 <= a.validation <= 100: p.error('--validation must be between 0 and 100')
    if not (a.lr >= a.lrmin > 0):p.error('Require --lr >= --lrmin > 0')
    if a.epoch < 1 or a.batch < 1:p.error('--epoch and --batch must be positive')
    if not a.name.isidentifier():p.error('--name must be a simple identifier')
    root=Path(__file__).resolve().parents[2]
    assets=Path(a.assets or root/'assets');data=Path(a.data or root/'data')
    assets.mkdir(parents=True,exist_ok=True);data.mkdir(parents=True,exist_ok=True)
    manifest=data/f'{a.name}_split.json'
    tr,va = prepare(a.database,a.sample,a.validation,a.seed,manifest)
    import torch
    torch.manual_seed(a.seed);np.random.seed(a.seed)
    init=np.asarray(read_binary(a.init),dtype=np.float32) if a.init else np.zeros(N_CODES,np.float32)
    model=torch_model()(init).to(a.device)
    train_arrays, train_targets=make_batches(tr,a.batch,a.device)
    val_arrays,val_targets=make_batches(va,a.batch,a.device) if va else (None,None)
    optimizer=torch.optim.Adam(model.parameters(),lr=a.lr)
    best = float('inf'); history=[]
    for epoch in range(1,a.epoch+1):
        lr=a.lrmin + (a.lr-a.lrmin)*(a.epoch-epoch)/max(1,a.epoch-1)
        for group in optimizer.param_groups:group['lr']=lr
        print(f'⚙️ Epoch {epoch}/{a.epoch} lr={lr:.8f} training={len(tr)} validation={len(va)}',flush=True)
        train_online=run_epoch(model,train_arrays,train_targets,a.batch,f'TRAIN {epoch}',[r[1] for r in tr],optimizer,seed=a.seed+epoch)
        train_replay=run_epoch(model,train_arrays,train_targets,a.batch,f'REPLAY {epoch}',[r[1] for r in tr])
        val_mse=run_epoch(model,val_arrays,val_targets,a.batch,f'VALID {epoch}',[r[1] for r in va]) if va else None
        metric=val_mse if val_mse is not None else train_replay
        record={'epoch':epoch,'lr':lr,'train_online_mse_cp2':train_online,
                'train_replay_mse_cp2':train_replay,'validation_mse_cp2':val_mse,
                'selection_metric':'validation' if va else 'train_replay'}
        history.append(record)
        ckpt={'version':1,'name':a.name,'epoch':epoch,'weights':model.weights.detach().cpu(),
              'manifest':str(manifest.resolve()),'stats':record}
        path=assets/f'{a.name}_epoch_{epoch:04d}.pt'
        torch.save(ckpt,path)
        if metric < best:
            best=metric; torch.save(ckpt,assets/f'{a.name}_best.pt')
            print(f'✅ BEST epoch={epoch} MSE(cp²)={best:.4f}',flush=True)
        print(f'📊 Epoch {epoch} TRAIN={train_replay:.4f} VALID={val_mse if val_mse is not None else "N/A"}',flush=True)
        (data/f'{a.name}_history.json').write_text(json.dumps(history,indent=2),encoding='utf-8')
    print(f'✅ Best MSE(cp²)={best:.4f} checkpoint={assets/f"{a.name}_best.pt"}',flush=True)


if __name__=='__main__':
    try:main()
    except Exception as exc:
        print(f'❌ {type(exc).__name__}: {exc}',file=sys.stderr,flush=True)
        raise
