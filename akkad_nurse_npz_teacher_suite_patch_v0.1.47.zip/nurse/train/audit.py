"""Compare Nurse NPZ score against Stockfish teacher labels on same POST/selected FEN.
EPD: promote 'bm' from EPD preposition; analyze posterior with Stockfish for a numerical label.
"""
from __future__ import annotations
import argparse, json, math, os, statistics, time
from pathlib import Path
from common import (open_database,require_chess,validate_npz,npz_predict_cp,label_cp_white,progress)

def main(argv=None):
    p=argparse.ArgumentParser(description='Audit original Nurse NPZ evaluator against Stockfish-labelled DB or EPD')
    p.add_argument('--npz',required=True)
    g=p.add_mutually_exclusive_group(required=True)
    g.add_argument('--in',dest='source')
    g.add_argument('--epd')
    p.add_argument('--out',help='Detailed JSON report')
    p.add_argument('--stockfish',help='UCI executable; required for EPD posterior labels')
    p.add_argument('--depth',type=int,default=12)
    p.add_argument('--limit',type=int,default=0,help='Maximum samples; 0=all')
    a=p.parse_args(argv)
    if a.depth<1 or a.limit<0:p.error('depth and limit must be nonnegative/positive')
    vals=validate_npz(a.npz);chess=require_chess()
    report=[];skipped=[]
    def add(row_id,board,teacher_cp,extra=None):
        model_cp=npz_predict_cp(board,vals)  # exact integer truncation Nurse uses
        delta=model_cp-teacher_cp
        # Single numerical teacher as reference => teacher's reference-residual is 0.
        record={'id':row_id,'fen_evaluated':board.fen(),'teacher_cp_white':teacher_cp,
                'npz_cp_white':model_cp,'npz_mse_vs_teacher':delta*delta,
                'teacher_mse_vs_teacher':0.,'mse_difference':delta*delta,
                'cp_difference':delta,'absolute_cp_difference':abs(delta)}
        if extra:record.update(extra)
        report.append(record)
    if a.source:
        with open_database(a.source) as db:
            cols={r[1] for r in db.execute('PRAGMA table_info(positions)')}
            cpfield='teacher_cp' if 'teacher_cp' in cols else 'NULL'
            matefield='teacher_mate' if 'teacher_mate' in cols else 'NULL'
            query=f'SELECT id,fen,teacher_value,{cpfield},{matefield} FROM positions WHERE teacher_value IS NOT NULL ORDER BY id'
            total=db.execute('SELECT COUNT(*) FROM positions WHERE teacher_value IS NOT NULL').fetchone()[0]
            if a.limit:total=min(total,a.limit)
            for pid,fen,value,cp,mate in db.execute(query):
                if a.limit and len(report)+len(skipped)>=a.limit:break
                try:
                    board=chess.Board(fen)
                    if not board.is_valid():raise ValueError('FEN no válido')
                    add(pid,board,label_cp_white(board,value,cp,mate),{'source':'picoAlpha SQLite labelled FEN'})
                except (ValueError,TypeError,OverflowError) as e:skipped.append({'id':pid,'reason':str(e)})
                if (len(report)+len(skipped))%200==0 or len(report)+len(skipped)==total:
                    progress('AUDIT DB',len(report)+len(skipped),total)
    else:
        if not a.stockfish:p.error('--epd requiere --stockfish para evaluar la posición posterior (ce del EPD anterior no sirve)')
        import chess.engine
        engine=chess.engine.SimpleEngine.popen_uci(a.stockfish)
        try:
            with open(a.epd,encoding='utf-8-sig') as f:lines=[(idx,s.strip()) for idx,s in enumerate(f,1) if s.strip() and not s.lstrip().startswith(('#',';'))]
            total=min(len(lines),a.limit) if a.limit else len(lines)
            for row_number,line in lines[:total]:
                try:
                    pre,ops=chess.Board.from_epd(line)
                    best=ops.get('bm')
                    if not best:raise ValueError('EPD sin operación bm (best move)')
                    if not isinstance(best,(list,tuple,set)):best=[best]
                    move=sorted(best,key=lambda m: m.uci() if hasattr(m,'uci') else str(m))[0]
                    if isinstance(move,str):
                        try:move=pre.parse_san(move)
                        except ValueError:move=chess.Move.from_uci(move)
                    if move not in pre.legal_moves:raise ValueError('bm ilegal')
                    post=pre.copy(stack=False);post.push(move)
                    if not post.is_valid():raise ValueError('FEN posterior inválido')
                    result=engine.analyse(post,chess.engine.Limit(depth=a.depth))
                    score=result['score'].white()
                    cp=score.score(mate_score=100000)
                    if cp is None:raise ValueError('Stockfish no devolvió score')
                    add(row_number,post,float(cp),{'source':'EPD posterior Stockfish','epd_before':pre.fen(),
                       'played_move':move.uci(),'stockfish_depth':a.depth})
                except (ValueError,KeyError,IndexError,TypeError,chess.engine.EngineError) as e:
                    skipped.append({'id':row_number,'reason':str(e)})
                if (len(report)+len(skipped))%20==0 or len(report)+len(skipped)==total:
                    progress('AUDIT EPD',len(report)+len(skipped),total)
        finally:engine.quit()
    if not report:raise RuntimeError('No se evaluó ninguna muestra válida')
    diffs=[r['cp_difference'] for r in report]
    sq=[r['npz_mse_vs_teacher'] for r in report]
    stats={'samples':len(report),'skipped':len(skipped),'difference_cp_min':min(diffs),
       'difference_cp_mean':statistics.fmean(diffs),'difference_cp_max':max(diffs),
       'absolute_difference_cp_mean':statistics.fmean(abs(x) for x in diffs),
       'mse_npz_vs_teacher_mean':statistics.fmean(sq),'mse_npz_vs_teacher_min':min(sq),
       'mse_npz_vs_teacher_max':max(sq),'teacher_reference_mse':0.0,
       'note':'Teacher is the single numerical reference; its self-MSE is 0 by definition, not an independent estimate of teacher accuracy.'}
    print('📊 AUDIT '+json.dumps(stats,ensure_ascii=False,indent=2))
    if a.out:
        dest=Path(a.out);dest.parent.mkdir(parents=True,exist_ok=True)
        payload={'npz':str(Path(a.npz).resolve()),'dataset':a.source or a.epd,
                 'stats':stats,'records':report,'skipped':skipped}
        temp=dest.with_name(dest.name+'.tmp')
        temp.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf8');os.replace(temp,dest)
        print('✅ JSON='+str(dest))
    return 0
if __name__=='__main__':raise SystemExit(main())
