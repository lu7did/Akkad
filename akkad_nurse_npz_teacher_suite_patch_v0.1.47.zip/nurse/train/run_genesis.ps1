param([Parameter(Mandatory=$true)][ValidateRange(0,2)][int]$Mon,
      [string]$In='', [string]$Epd='',[string]$Stockfish='',[string]$Assets='',
      [int]$Sample=0,[double]$Fraction=0,[double]$Validation=20,[int]$Epoch=10,
      [double]$Lr=0.001,[double]$MinLr=0.00001,[int]$Batch=64,[int]$Seed=42,[string]$Device='auto')
$ErrorActionPreference='Stop';$root=Split-Path -Parent $MyInvocation.MyCommand.Path
if(!$Assets){$Assets=Join-Path (Split-Path -Parent $root) 'assets'}
New-Item -ItemType Directory -Path $Assets -Force | Out-Null
$best=Join-Path $Assets 'best.npz';$report=Join-Path $Assets 'audit.json'
for($step=$Mon;$step -le 2;$step++){
  Write-Host "⚙️ MON=$step / paso $($step+1) de 3" -ForegroundColor Cyan
  if($step -eq 0){
    if(!$In){throw 'MON=0 requires -In SQLite .pb'}
    $invoke=@{In=$In;Out=$Assets;Validation=$Validation;Epoch=$Epoch;Lr=$Lr;MinLr=$MinLr;Batch=$Batch;Seed=$Seed;Device=$Device}
    if($Sample -gt 0){$invoke.Sample=$Sample};if($Fraction -gt 0){$invoke.Fraction=$Fraction}
    & (Join-Path $root 'run_train.ps1') @invoke
  }
  if($step -eq 1){
    if(!(Test-Path $best)){throw "Missing best checkpoint: $best"}
    $invoke=@{Npz=$best;Out=$report}
    if($Epd){$invoke.Epd=$Epd;$invoke.Stockfish=$Stockfish}elseif($In){$invoke.In=$In}else{throw 'MON=1 requires -In or -Epd'}
    & (Join-Path $root 'run_audit.ps1') @invoke
  }
  if($step -eq 2){
    if(!(Test-Path $best)){throw "Missing best checkpoint: $best"}
    & (Join-Path $root 'run_export.ps1') -In $best -Int8 (Join-Path $Assets 'best_int8.npz') -Hpp (Join-Path $Assets 'best_int8.hpp')
  }
  Write-Host "✅ MON=$step complete; next MON=$($step+1)" -ForegroundColor Green
}
