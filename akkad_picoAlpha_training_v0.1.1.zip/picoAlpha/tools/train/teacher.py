"""Re-entrant teacher labeling using local UCI Stockfish; replaces previous labels."""
import argparse
import math
import shlex
import subprocess
from common import connect,verify,progress,require_chess

def main():
    p=argparse.ArgumentParser(description='Re-label ALL position value/policy via Stockfish UCI')
    p.add_argument('--in',dest='source',required=True)
    p.add_argument('--engine',required=True,help='Path to Stockfish executable')
    p.add_argument('--args',default='',help='Extra command line arguments passed to engine')
    p.add_argument('--depth',type=int,default=10)
    p.add_argument('--nodes',type=int,default=None,help='Optional per-position node limit')
    a=p.parse_args()
    if a.depth<=0:p.error('--depth must be positive')
    chess=require_chess();import chess.engine
    with connect(a.source) as db:
        verify(db)
        total=db.execute('SELECT count(*) FROM positions').fetchone()[0]
        if not total:p.error('Database contains no positions')
        command=[a.engine]+shlex.split(a.args,posix=False if __import__('os').name=='nt' else True)
        print('🧠 Engine:',repr(command),'positions=',total)
        engine=chess.engine.SimpleEngine.popen_uci(command)
        completed=0
        try:
            for id,fen in db.execute('SELECT id,fen FROM positions ORDER BY id'):
                board=chess.Board(fen)
                if board.is_game_over(claim_draw=True):
                    # game-over draw or terminal: no legal policy
                    value=0. if board.is_stalemate() or board.is_insufficient_material() or board.can_claim_draw() else -1.
                    best=None;cp=None;mate=None
                else:
                    limit=chess.engine.Limit(depth=a.depth,nodes=a.nodes)
                    info=engine.analyse(board,limit)
                    pv=info.get('pv',[])
                    best=pv[0].uci() if pv else None
                    score=info['score'].pov(board.turn)
                    mate=score.mate() if score.is_mate() else None
                    cp=None if mate is not None else score.score()
                    value=(1. if mate>0 else -1.) if mate is not None else math.tanh(cp/400.)
                with db:
                    db.execute('UPDATE positions SET teacher_uci=?,teacher_cp=?,teacher_mate=?,teacher_value=?,teacher_depth=?,teacher_at=CURRENT_TIMESTAMP WHERE id=?',
                        (best,cp,mate,value,a.depth,id))
                completed+=1
                if completed%25==0 or completed==total:progress('Teaching',completed,total)
        finally:engine.quit()
        print(f'✅ Teacher labeled {completed}/{total} positions')
if __name__=='__main__':main()
