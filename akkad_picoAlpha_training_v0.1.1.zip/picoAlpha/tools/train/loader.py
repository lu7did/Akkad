"""Append PGN mainlines, preserving unique source and per-game chronological plies."""
import argparse
import glob
import json
import os
from common import connect,schema,progress,require_chess

def main():
    p=argparse.ArgumentParser(description='Append games from PGN filename glob to SQLite .pb')
    p.add_argument('--in',dest='source',required=True,help='PGN glob, e.g. C:/games/c*.pgn')
    p.add_argument('--out',required=True,help='SQLite .pb database')
    a=p.parse_args();chess=require_chess()
    files=sorted(f for f in glob.glob(a.source,recursive=True) if os.path.isfile(f))
    if not files: p.error('No PGN files matched --in')
    with connect(a.out) as db:
        schema(db); total_games=total_pos=0
        for file_number,path in enumerate(files,1):
            print(f'📄 File {file_number}/{len(files)} {path}')
            size=max(1,os.path.getsize(path)); game_no=0; new_games=0
            with open(path,'r',encoding='utf-8-sig',errors='replace') as stream:
                while True:
                    try: game=chess.pgn.read_game(stream)
                    except (ValueError, UnicodeError) as e:
                        print(f'⚠️ Cannot decode game {game_no+1}: {e}');break
                    if game is None:break
                    game_no+=1
                    if game.errors:
                        print(f'⚠️ Skipping game {game_no} with {len(game.errors)} parse error(s)')
                        continue
                    source=os.path.normcase(os.path.abspath(path))
                    exists=db.execute('SELECT id FROM games WHERE source_file=? AND source_ordinal=?',(source,game_no)).fetchone()
                    if exists:
                        continue  # idempotent per file and ordinal; other files append
                    board=game.board(); rows=[]
                    for ply,move in enumerate(game.mainline_moves(),1):
                        if move not in board.legal_moves: raise ValueError(f'Illegal PGN move {move} in {path} game {game_no}')
                        rows.append((ply,board.fen(en_passant='fen'),move.uci()))
                        board.push(move)
                    with db:
                        cur=db.execute('INSERT INTO games(source_file,source_ordinal,headers_json,result,start_fen) VALUES(?,?,?,?,?)',
                            (source,game_no,json.dumps(dict(game.headers),ensure_ascii=False),game.headers.get('Result','*'),game.board().fen(en_passant='fen')))
                        db.executemany('INSERT INTO positions(game_id,ply,fen,played_uci) VALUES(?,?,?,?)',
                            [(cur.lastrowid,*row) for row in rows])
                    new_games+=1;total_games+=1;total_pos+=len(rows)
                    if game_no%10==0:progress('PGN loading',min(stream.tell(),size),size,f'games={game_no} new={new_games}')
                progress('PGN loading',size,size,f'games={game_no} new={new_games}')
            print(f'📊 Files [{file_number}/{len(files)}] loaded games={total_games} positions={total_pos}')
        print(f'✅ Total DB games={db.execute("SELECT count(*) FROM games").fetchone()[0]}, positions={db.execute("SELECT count(*) FROM positions").fetchone()[0]}')
if __name__=='__main__':main()
