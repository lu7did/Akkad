"""picoAlpha training data contract v0.1.1: SQLite database with .pb extension.
No relationship to protobuf or Berkeley DB; .pb is a user-selected suffix.
"""
import json
import sqlite3
import sys
import time

SCHEMA = '''
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS games (
 id INTEGER PRIMARY KEY, source_file TEXT NOT NULL, source_ordinal INTEGER NOT NULL,
 headers_json TEXT NOT NULL, result TEXT NOT NULL, start_fen TEXT NOT NULL,
 imported_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(source_file,source_ordinal)
);
CREATE TABLE IF NOT EXISTS positions (
 id INTEGER PRIMARY KEY, game_id INTEGER NOT NULL REFERENCES games(id) ON DELETE CASCADE,
 ply INTEGER NOT NULL, fen TEXT NOT NULL, played_uci TEXT NOT NULL,
 teacher_uci TEXT, teacher_cp INTEGER, teacher_mate INTEGER, teacher_value REAL,
 teacher_depth INTEGER, teacher_at TEXT,
 UNIQUE(game_id,ply)
);
CREATE INDEX IF NOT EXISTS idx_positions_game ON positions(game_id,ply);
CREATE INDEX IF NOT EXISTS idx_positions_teacher ON positions(teacher_value);
'''

def connect(path):
    c=sqlite3.connect(path,timeout=30)
    c.execute('PRAGMA foreign_keys=ON')
    c.execute('PRAGMA busy_timeout=30000')
    return c

def schema(c):
    c.executescript(SCHEMA)

def verify(c):
    needed={'games','positions'}
    have={r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    if not needed<=have: raise ValueError('Database missing required tables: '+str(needed-have))

def progress(label, current, total, tail=''):
    fraction=min(1.,current/max(1,total)); filled=round(32*fraction)
    line=f'\r{label:<14} [{"█"*filled}{"░"*(32-filled)}] {100*fraction:6.2f}% {current}/{total} {tail[:55]:<55}'
    print(line,end='\n' if current>=total else '',flush=True)

def require_chess():
    try: import chess; import chess.pgn; return chess
    except ImportError as e: raise SystemExit('Install dependencies: python -m pip install -r requirements.txt') from e

def features(board):
    """780 sparse inputs: 12*64 relative pieces, 4 relative castling, 8 EP files."""
    chess=require_chess()
    own=board.turn
    out=[]
    for sq,piece in board.piece_map().items():
        ptype=piece.piece_type-1 + (0 if piece.color==own else 6)
        # exact transform in supplied network sketch: white a8=0; black rotated 180
        ix=(7-chess.square_rank(sq))*8+chess.square_file(sq)
        if not own: ix=63-ix
        out.append(ptype*64+ix)
    for flag,color,short in [(768,own,True),(769,own,False),(770,not own,True),(771,not own,False)]:
        if (board.has_kingside_castling_rights(color) if short else board.has_queenside_castling_rights(color)):
            out.append(flag)
    if board.ep_square is not None:
        f=chess.square_file(board.ep_square)
        out.append(772+(f if own else 7-f))
    return sorted(out)

def square_index(sq,turn):
    chess=require_chess()
    index=(7-chess.square_rank(sq))*8+chess.square_file(sq)
    return index if turn else 63-index

def move_indices(move,turn): return square_index(move.from_square,turn),square_index(move.to_square,turn)

def quant_params(): return 780*16+16+16*64*2
