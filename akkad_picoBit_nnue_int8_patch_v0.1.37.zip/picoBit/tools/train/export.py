"""Exportación NNUE-INT8 residual: checkpoint PyTorch -> cabecera C99/C++.

No implementa motor C++: contiene funciones de inferencia portable y
acumulador incremental para un futuro port. Conserva Sargon externo.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import numpy as np
import torch
from train import INPUT_DIM, VERSION, checkpoint_read, fen_to_features, predict_np
import chess


def _weights_int8(weights):
    w = weights.detach().cpu().numpy().astype(np.float64)
    scale = np.maximum(np.max(np.abs(w), axis=1), 1e-8) / 127.0
    q = np.clip(np.rint(w/scale[:, None]), -127, 127).astype(np.int8)
    return q, scale


def _bn_affine(bn, weight_scale, divided_by=1.0):
    """Fold BN(q_acc*weight_scale/divided_by) = mul*q_acc + add."""
    gamma = bn.weight.detach().cpu().numpy().astype(np.float64)
    beta = bn.bias.detach().cpu().numpy().astype(np.float64)
    mean = bn.running_mean.detach().cpu().numpy().astype(np.float64)
    var = bn.running_var.detach().cpu().numpy().astype(np.float64)
    g = gamma / np.sqrt(var + bn.eps)
    return (g*weight_scale/divided_by).astype(np.float32), (beta-g*mean).astype(np.float32)


def derive_params(model, checkpoint):
    if checkpoint.get('format') != 'picobit-residual-nnue-int8-v1':
        raise ValueError('Checkpoint no es NNUE INT8')
    q1, s1 = _weights_int8(model.fc1.weight)
    q2, s2 = _weights_int8(model.fc2.weight)
    m1, b1 = _bn_affine(model.bn1,s1)
    m2, b2 = _bn_affine(model.bn2,s2,127.0)
    wo = model.fc_out.weight.detach().cpu().numpy().reshape(-1).astype(np.float64)
    bo = float(model.fc_out.bias.detach().cpu().item())
    so = max(float(np.max(np.abs(wo))),1e-8)/32767.0
    qo = np.clip(np.rint(wo/so), -32767, 32767).astype(np.int16)
    return {'w1':q1,'w2':q2,'m1':m1,'b1':b1,'m2':m2,'b2':b2,
            'outw':qo,'outscale':so,'outbias':bo,
            'alpha':float(checkpoint['config']['alpha']),
            'beta':float(checkpoint['config']['beta']),
            'clip':float(checkpoint['config']['clip_cp'])}


def infer_integer(x,p):
    """Referencia del datapath INT8, acumuladores INT32 y BN plegada FP32.

    Calcula a partir de enteros usando las mismas escalas que la cabecera C.
    """
    x = np.asarray(x, dtype=np.int32)
    if x.ndim == 1: x = x[None,:]
    if x.shape[1] != INPUT_DIM or not np.all((x==0)|(x==1)):
        raise ValueError('Entrada binaria de 781 dimensiones requerida')
    acc1 = x @ p['w1'].astype(np.int32).T
    h1 = acc1.astype(np.float32)*p['m1'][None,:] + p['b1'][None,:]
    a1 = np.clip(np.rint(np.clip(h1,0,1)*127),0,127).astype(np.int32)
    acc2 = a1 @ p['w2'].astype(np.int32).T
    h2 = acc2.astype(np.float32)*p['m2'][None,:] + p['b2'][None,:]
    a2 = np.clip(np.rint(np.clip(h2,0,1)*127),0,127).astype(np.int32)
    out = (a2@p['outw'].astype(np.int32))*(p['outscale']/127.0)+p['outbias']
    return np.asarray(out,dtype=np.float64)


def c_array(name, typ, values, fmt=str, per_line=12):
    arr=np.asarray(values)
    if arr.ndim==2:
        rows=['    {'+', '.join(fmt(item) for item in row)+'},' for row in arr]
        return f'static const {typ} {name}[{arr.shape[0]}][{arr.shape[1]}] = {{\n'+'\n'.join(rows)+'\n};\n'
    rows=['    '+', '.join(fmt(v) for v in arr[i:i+per_line])+',' for i in range(0,len(arr),per_line)]
    return f'static const {typ} {name}[{len(arr)}] = {{\n'+'\n'.join(rows)+'\n};\n'


def f32(v):
    # Python repr float32 precision: literal C always with decimal or exponent.
    s=format(float(np.float32(v)),'.9g')
    if 'e' not in s and '.' not in s:s+='.0'
    return s+'f'


def generate_header(p, checkpoint_path):
    parts=[f'/* picoBit residual NNUE INT8 v{VERSION}; checkpoint {Path(checkpoint_path).name}.',
           ' * 781 -> 64 -> 64 -> 1. FC1/FC2 INT8; activation 0..127 INT8;',
           ' * output INT16; BN folded as FP32 affine (not binary thresholds).',
           ' * Memory of weight matrices: 781*64 + 64*64 bytes; no floating matrix.',
           ' * Feature order: 768 piece-square + side-to-move + castling 4 + en-passant 8.',
           ' * Sargon is supplied by the chess engine, in original Sargon points.',
           ' */',
           '#ifndef PICOBIT_RESIDUAL_NNUE_INT8_V1_H',
           '#define PICOBIT_RESIDUAL_NNUE_INT8_V1_H',
           '#include <stdint.h>', '#include <stddef.h>', '#include <math.h>',
           '#define PB_INPUT 781', '#define PB_HIDDEN 64',
           f'static const double pb_alpha = {p["alpha"]:.17g};',
           f'static const double pb_beta = {p["beta"]:.17g};',
           f'static const double pb_clip_cp = {p["clip"]:.17g};',
           f'static const float pb_outscale = {f32(p["outscale"])};',
           f'static const float pb_outbias = {f32(p["outbias"])};']
    for name,typ,v,fmt in [('pb_w1','int8_t',p['w1'],str),('pb_w2','int8_t',p['w2'],str),
                            ('pb_m1','float',p['m1'],f32),('pb_b1','float',p['b1'],f32),
                            ('pb_m2','float',p['m2'],f32),('pb_b2','float',p['b2'],f32),
                            ('pb_out_w','int16_t',p['outw'],str)]:
        parts.append(c_array(name,typ,v,fmt))
    parts.append(r'''
/* fc1 accumulates only active features. Call init once per position; during
 * search, remove old piece/state feature with delta -1 and add new with +1.
 * Promotion, capture, rook castling and ep require all corresponding deltas.
 * The chess engine is responsible for computing those changes correctly.
 */
static inline void pb_fc1_init(int32_t acc[PB_HIDDEN], const uint16_t *active, size_t n) {
    for (unsigned j=0;j<PB_HIDDEN;j++) acc[j]=0;
    for (size_t k=0;k<n;k++) {
        unsigned index=active[k];
        if (index>=PB_INPUT) continue;
        for (unsigned j=0;j<PB_HIDDEN;j++) acc[j]+=(int32_t)pb_w1[j][index];
    }
}
static inline void pb_fc1_delta(int32_t acc[PB_HIDDEN], uint16_t index, int delta) {
    if (index>=PB_INPUT || (delta!=1 && delta!=-1)) return;
    for (unsigned j=0;j<PB_HIDDEN;j++) acc[j]+=(int32_t)pb_w1[j][index]*delta;
}
static inline uint8_t pb_quant_relu(float x) {
    if (x<=0.0f) return 0;
    if (x>=1.0f) return 127;
    return (uint8_t)lroundf(x*127.0f);
}
static inline float pb_residual_from_acc(const int32_t acc1[PB_HIDDEN]) {
    uint8_t a1[PB_HIDDEN], a2[PB_HIDDEN];
    for (unsigned j=0;j<PB_HIDDEN;j++)
        a1[j]=pb_quant_relu((float)acc1[j]*pb_m1[j]+pb_b1[j]);
    for (unsigned j=0;j<PB_HIDDEN;j++) {
        int32_t acc2=0;
        for (unsigned i=0;i<PB_HIDDEN;i++) acc2+=(int32_t)pb_w2[j][i]*a1[i];
        a2[j]=pb_quant_relu((float)acc2*pb_m2[j]+pb_b2[j]);
    }
    int32_t total=0;
    for (unsigned i=0;i<PB_HIDDEN;i++) total+=(int32_t)pb_out_w[i]*a2[i];
    return (float)total*(pb_outscale/127.0f)+pb_outbias;
}
static inline double pb_calibrated_sargon(double sargon_points) {
    double y=pb_alpha*sargon_points+pb_beta;
    if (y>pb_clip_cp) y=pb_clip_cp;
    if (y<-pb_clip_cp) y=-pb_clip_cp;
    return y;
}
static inline double pb_eval(double sargon_points, const int32_t acc1[PB_HIDDEN]) {
    return pb_calibrated_sargon(sargon_points)+(double)pb_residual_from_acc(acc1);
}
#endif
''')
    return '\n'.join(parts)


def main(argv=None):
    ap=argparse.ArgumentParser(description='Exportar picoBit NNUE INT8 residual .pt -> .h')
    ap.add_argument('--in',dest='model',required=True)
    ap.add_argument('--out',required=True)
    ap.add_argument('--manifest',default=None)
    ap.add_argument('--check-count',type=int,default=64)
    ap.add_argument('--max-export-error-cp',type=float,default=2.0)
    args=ap.parse_args(argv)
    if Path(args.out).suffix.lower()!='.h' or args.check_count<1 or args.max_export_error_cp<=0:
        ap.error('Requiere --out .h, --check-count >=1, --max-export-error-cp >0')
    model,ck=checkpoint_read(args.model)
    p=derive_params(model,ck)
    if args.manifest:
        info=json.loads(Path(args.manifest).read_text(encoding='utf-8'))
        if info.get('format')!='picobit-residual-nnue-int8-manifest-v1':
            raise ValueError('Manifest no corresponde al NNUE INT8')
        x=np.stack([fen_to_features(chess.Board(item)) for item in info['validation_fen'][:args.check_count]])
    else:
        rng=np.random.default_rng(29)
        x=np.zeros((args.check_count,INPUT_DIM),np.float32)
        for row in x:
            row[rng.choice(768, size=28, replace=False)] = 1
            row[768] = rng.integers(0,2)
    if not len(x): raise ValueError('No hay entradas de prueba')
    reference=predict_np(model,x,'cpu',128)
    packed=infer_integer(x,p)
    error=np.abs(reference-packed)
    report={'format':'picobit-nnue-int8-export-v1', 'version':VERSION,
            'checked':len(x),'max_abs_residual_cp':float(np.max(error)),
            'mae_residual_cp':float(np.mean(error)),
            'max_export_error_cp':args.max_export_error_cp}
    if not np.all(np.isfinite(error)) or np.max(error)>args.max_export_error_cp:
        raise RuntimeError(f'EXPORTACIÓN ABORTADA: error máximo {np.max(error):.6f}cp supera {args.max_export_error_cp}cp')
    target=Path(args.out)
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_text(generate_header(p,args.model),encoding='utf-8')
    target.with_suffix('.export.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(f'✅ NNUE INT8 .h={target} n={len(x)} máximoΔ={np.max(error):.6f}cp MAEΔ={np.mean(error):.6f}cp')
    print('⚠️ La equivalencia de la cabecera C/C++ se valida en la fase x86 posterior.')

if __name__=='__main__':
    main()
