# picoSargon x86 - build v0.2.25
# Ambos interruptores activados por defecto; se pueden desactivar explicitamente.
param(
    [string]$Python = "python",
    [string]$CMake = "cmake",
    [bool]$steroids = $true,
    [bool]$twins = $true
)
$ErrorActionPreference = 'Stop'
& $Python (Join-Path $PSScriptRoot 'build_host.py') --cmake $CMake --steroids $steroids.ToString().ToLowerInvariant() --twins $twins.ToString().ToLowerInvariant()
if ($LASTEXITCODE -ne 0) { throw 'Error compilando picoSargon x86' }
# Confirmar el resultado efectivo (no basta el valor solicitado en PowerShell).
$cachePath = Join-Path $PSScriptRoot 'build\CMakeCache.txt'
if (-not (Test-Path -LiteralPath $cachePath)) { throw "No existe CMakeCache.txt: $cachePath" }
$cache = Get-Content -LiteralPath $cachePath
foreach ($entry in @(@{Name='STEROIDS'; Expected=$steroids}, @{Name='TWINS'; Expected=$twins})) {
    $key = [regex]::Escape($entry.Name)
    $matches = @($cache | Where-Object { $_ -match "^${key}:BOOL=(ON|OFF)$" })
    if ($matches.Count -ne 1) { throw "No se puede verificar $($entry.Name) en CMakeCache.txt" }
    $actual = $matches[0] -match '=ON$'
    if ($actual -ne $entry.Expected) {
        throw "Configuracion inconsistente: $($entry.Name) esperado=$($entry.Expected) real=$actual"
    }
    Write-Host ("picoSargon {0}={1}" -f $entry.Name, $(if ($actual) { 'ON' } else { 'OFF' }))
}
Write-Host (Join-Path $PSScriptRoot 'build\picoSargon.exe')
