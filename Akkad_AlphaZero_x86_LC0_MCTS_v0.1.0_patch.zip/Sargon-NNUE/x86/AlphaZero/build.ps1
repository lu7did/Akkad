param(
    [string]$LC0Source = "",
    [string]$LC0Ref = "master",
    [ValidateSet('eigen','dx','onnx')][string]$Backend = 'eigen',
    [string]$OnnxInclude = "",
    [string]$OnnxLibdir = ""
)
$ErrorActionPreference = 'Stop'
$here = $PSScriptRoot
$build = Join-Path $here 'build'
$vendor = Join-Path $build 'lc0-src'
$mesonBuild = Join-Path $build 'lc0-build'
New-Item -ItemType Directory -Force -Path $build | Out-Null
foreach ($program in @('git','python','meson','ninja')) {
    if (-not (Get-Command $program -ErrorAction SilentlyContinue)) { throw "Missing tool: $program" }
}
if (-not $LC0Source) {
    if (-not (Test-Path (Join-Path $vendor '.git'))) {
        & git clone --depth 1 --branch $LC0Ref https://github.com/LeelaChessZero/lc0.git $vendor
        if ($LASTEXITCODE -ne 0) { throw 'LC0 clone failed' }
    }
} else {
    $LC0Source = (Resolve-Path $LC0Source).Path
    if (-not (Test-Path (Join-Path $LC0Source 'meson.build'))) { throw 'Invalid LC0 source directory' }
    if (-not (Test-Path (Join-Path $vendor '.git'))) {
        if (Test-Path $vendor) { Remove-Item $vendor -Recurse -Force }
        & git clone --local $LC0Source $vendor
        if ($LASTEXITCODE -ne 0) { throw 'LC0 local clone failed' }
    }
}
$main = Join-Path $vendor 'src/main.cc'
if (-not (Test-Path $main)) { throw 'LC0 source layout changed: src/main.cc missing' }
# Modify ONLY the isolated source checkout; never touch the provided LC0 repository.
Copy-Item (Join-Path $here 'src/akkad_alphazero_main.cc') $main -Force
# Configuring a fresh tree avoids stale absolute paths and mixed backends.
if (Test-Path $mesonBuild) { Remove-Item $mesonBuild -Recurse -Force }
$argsMeson = @('setup',$mesonBuild,$vendor,'--backend=vs','--buildtype=release','-Ddefault_library=static','-Db_vscrt=mt','-Dlc0=true')
switch ($Backend) {
    'eigen' {$argsMeson += @('-Dblas=true','-Dopenblas=false','-Dmkl=false','-Ddnnl=false')}
    'dx'    {$argsMeson += @('-Ddx=true')}
    'onnx'  {
        if (-not $OnnxInclude -or -not $OnnxLibdir) { throw 'ONNX requires -OnnxInclude and -OnnxLibdir' }
        $argsMeson += @('-Donnx=true',"-Donnx_include=$OnnxInclude", "-Donnx_libdir=$OnnxLibdir")
    }
}
& meson @argsMeson
if ($LASTEXITCODE -ne 0) { throw 'Meson setup failed' }
& meson compile -C $mesonBuild lc0
if ($LASTEXITCODE -ne 0) { throw 'LC0-linked AlphaZero compile failed' }
$exe = Get-ChildItem $mesonBuild -Filter lc0.exe -Recurse -File | Select-Object -First 1
if (-not $exe) { throw 'Linked executable not found' }
Copy-Item $exe.FullName (Join-Path $build 'AlphaZero.exe') -Force
Write-Host "Created: $(Join-Path $build 'AlphaZero.exe')"
