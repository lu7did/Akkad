"""Telemetry regression: measured quantities and progress line width."""
import contextlib
import io
import json
import math
import sqlite3
import tempfile
from pathlib import Path
from train import Progress, prepare, summary_line

def test_progress():
    sink=io.StringIO()
    with contextlib.redirect_stdout(sink):
        p=Progress('SAMPLE',100)
        for n in [0,5,25,50,75,100]:p.update(n)
    rendered=sink.getvalue()
    assert 'SAMPLE' in rendered and '100.00%' in rendered
    assert '####' in rendered
    assert 'pos=' in rendered
    s=summary_line('Replay',10000)
    assert 'RMSE=100.000 cp' in s and 'MSE=10000.000 cp2' in s
    print('PASS: progress charts, snapshots and RMSE = sqrt(MSE)')

if __name__=='__main__':test_progress()
