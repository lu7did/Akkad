# picoSargon: arquitectura y entrenamiento de la NNUE compacta GRMP0001

**Nota técnica — Akkad / picoSargon**  
**Fecha:** 16 de noviembre de 2026  
**Implementación documentada:** cadena `picoSargon/tools/train`, parches v0.1.44–v0.1.49; resultados de `dopey` aportados el 16/11/2026.  
**Modelo histórico:** `grumpy.bin` (referencia de comparación, **no modificada**).  
**Modelo experimental:** `dopey.bin` (entrenado, cuantizado a 6 bits).  
**Alcance:** arquitectura, formatos, preparación de datos, FP32, QAT, exportación, auditoría, resultados, dificultades y limitaciones. Este documento no cambia código ni pesos.

## Resumen ejecutivo

Se ha reconstruido una cadena de entrenamiento específica para el evaluador compacto conocido por su archivo de referencia `grumpy.bin`. El objetivo no es fabricar una NNUE genérica y comprimirla después, sino **optimizar una función que puede ser evaluada con la aritmética y el formato binario originales de picoSargon**. El circuito se divide en aprendizaje continuo con parámetros FP32, ajuste consciente de cuantización (QAT), selección del mejor modelo **cuantizado real** y auditoría contra las etiquetas de Stockfish de un SQLite.

Los resultados de la ejecución analizada, con **10.000 posiciones sorteadas (8.000 de entrenamiento, 2.000 reservadas)**, son favorables: el modelo `dopey.bin` alcanza **MSE(value) = 0,1189727**, frente a **0,1838455** de `grumpy.bin`, sobre las mismas 2.000 posiciones. Es una reducción relativa del **35,29 %** de la pérdida normalizada; en RMSE de centipeones pasa de **405,28** a **207,79 cp**. Se trata de una mejora respecto a las etiquetas de Stockfish, **no de un Elo medido ni de una auditoría verdaderamente independiente**: el checkpoint se seleccionó utilizando ese mismo conjunto de validación.

![Arquitectura de la red](images/arquitectura_grmp0001.png)

## 1. Objetivo y alcance de la red

La red sustituye una parte de la función heurística de evaluación del motor picoSargon. Recibe una posición ajedrecística —piezas, color y casillas ocupadas, cantidad de piezas y jugador al turno— y devuelve **una evaluación escalar de la posición en centipeones desde la perspectiva de las blancas**. No es una red de política: no predice probabilidades de movimientos. La elección de jugadas corresponde al buscador de picoSargon y no al evaluador.

Se conserva el término de material **fijo**, que se suma a la contribución neuronal. Esto significa que la red aprende principalmente una corrección posicional condicionada por las características y por la ocupación, en vez de aprender libremente todos los valores materiales.

La denominación *NNUE* describe la familia conceptual de redes ligeras para evaluación ajedrecística, pero **esta implementación no debe confundirse con las arquitecturas HalfKP/Stockfish ni presuponer que dispone de actualización incremental de acumuladores**. La función inspeccionada en `picoSargon/x86/src/grumpy.cpp` construye los acumuladores al evaluar una posición; cualquier afirmación sobre actualización incremental necesita comprobar otra ruta de ejecución.

## 2. Arquitectura exacta

### 2.1 Representación de la posición

Cada pieza aporta una característica codificada por: **color de la pieza, tipo de pieza y casilla**. Hay 2 colores × 6 tipos × 64 casillas = **768 características posibles**. Para cada característica se utilizan **dos pequeñas tablas aditivas**:

- un conjunto dependiente de la fila (*rank*);
- otro dependiente de la columna (*file*).

Cada tabla aporta **8 componentes**. Se construyen dos acumuladores de 8 componentes, uno por perspectiva de color, con inversión geométrica de filas para la perspectiva opuesta. En la salida, el acumulador del jugador al turno ocupa los primeros ocho canales y el del adversario los ocho siguientes. No se ingresa un vector denso de 768 números a una matriz tradicional: se realizan **búsquedas y sumas de coeficientes** para las piezas efectivamente presentes.

Si `f` es el índice de característica, `c ∈ {0,…,7}` el canal y `square = f mod 64`, la descomposición en el archivo se corresponde con:

```text
bloque = floor(f / 64) * 128
índice_fila(f,c)    = bloque + floor(square / 8) * 8 + c
índice_columna(f,c) = bloque + 64 + (square mod 8) * 8 + c
```

En cada acumulador se suman las dos contribuciones. El diseño **separable fila/columna** ahorra coeficientes, pero restringe su capacidad expresiva respecto de una tabla independiente por cada combinación de casilla y canal.

### 2.2 Distribución de los 1.680 coeficientes

| Índices | Cantidad | Función |
|---|---:|---|
| 0–1535 | 1.536 | Tablas de características (12 bloques tipo/color × 128 pesos de fila/columna) |
| 1536–1543 | 8 | Sesgo compartido de los acumuladores |
| 1544–1671 | 128 | Ocho cabezas de salida, 16 coeficientes por cabeza |
| 1672–1679 | 8 | Sesgo escalar de cada cabeza o *bucket* |
| **Total** | **1.680** | **Parámetros cuantizados** |

Los acumuladores resultan en **16 activaciones** que se limitan por saturación (*clipped ReLU*):

\[
 h_i = \min(32,\max(0,a_i)),\quad i=0,\ldots,15.
\]

Hay **8 buckets**, seleccionados por el número total de piezas presentes:

\[
 b=\left\lfloor\frac{N_{\mathrm{piezas}}-2}{4}\right\rfloor,\qquad 0\le b\le 7.
\]

Por ejemplo, de 2 a 5 piezas se utiliza el bucket 0; de 30 a 32, el bucket 7. Para cada bucket se calcula la suma ponderada de las 16 activaciones y un sesgo multiplicado por 8:

\[
 T=\sum_{i=0}^{15}h_i w_{b,i}+8\beta_b.
\]

En la implementación entera, la contribución neuronal se escala aproximadamente como \(400T/1024\), **truncando hacia cero**. Se añade después el material fijo, con los ajustes de signo necesarios para devolver el resultado desde blancas. La escala y la saturación forman parte del contrato del evaluador; cambiar cualquiera de ellas modificaría la función que se pretende aprender.

### 2.3 Coste computacional e idoneidad para plataformas pequeñas

La red se almacena en un binario de **1.304 bytes**. Las operaciones principales durante la inferencia son accesos a tablas y sumas enteras por pieza/canal, una activación limitada y un producto escalar de 16 términos; no se necesita PyTorch en producción. El archivo `.h` incorpora los mismos bytes como un arreglo C++ `constexpr` y permite ubicar el modelo en memoria de programa/flash si el compilador y el enlazador de la plataforma lo soportan. **La ubicación efectiva en flash y la RAM empleada deben medirse por plataforma; no las garantiza por sí sola la palabra `constexpr`.**

## 3. Representación binaria: GRMP0001 e INT6

El archivo tiene una estructura fija y verificable:

| Desplazamiento | Longitud | Contenido |
|---|---:|---|
| 0 | 8 bytes | Firma ASCII `GRMP0001` |
| 8 | 4 bytes | Entero little-endian: 105 bloques |
| 12 | 32 bytes | SHA-256 del *payload* |
| 44 | 1.260 bytes | 105 bloques × 12 bytes |
| **Total** | **1.304 bytes** | |

Cada bloque de 12 bytes contiene **16 códigos de 6 bits** (16 × 6 = 96 bits), empaquetados en orden little-endian. La decodificación es:

\[
 w = (\mathrm{code6}\;\&\;63)-31.
\]

Por tanto, el rango formal exacto es **−31 a +32**. No debe confundirse con `int8`; los pesos no son bytes independientes ni existe una escala `int8` aprendida. En la exportación observada de Dopey, los valores efectivamente utilizados estuvieron entre **−3 y +3**, con 324 coeficientes negativos, 736 cero y ninguna saturación reportada.

`export.py` valida tamaño, firma, SHA-256 y equivalencia de los coeficientes releídos tras escribir el archivo. `grumpy.bin` se mantiene como modelo de referencia en solo lectura: el exportador produce otro nombre de red, por ejemplo `dopey.bin` y `dopey.h`.

## 4. Datos de entrenamiento y convención de perspectiva

La fuente es una base **SQLite con tabla `positions`**, originada en el pipeline de picoAlpha y etiquetada con Stockfish. Los campos necesarios son `id`, `game_id`, `fen`, `teacher_cp`, `teacher_value` y `teacher_mate`. Para entrenar se incluyen únicamente posiciones con un centipeón numérico y sin etiqueta de mate.

La convención de picoAlpha es:

\[
 v_{\mathrm{STM}}=\tanh\left(\frac{cp_{\mathrm{STM}}}{400}\right),
\]

con `STM = side-to-move` (jugador que mueve). En cambio, el evaluador GRMP devuelve centipeones **desde blancas**. El pipeline convierte cada etiqueta mediante:

\[
 cp_{\mathrm{white}}=\begin{cases}
cp_{\mathrm{STM}},&\text{juegan blancas},\\
-cp_{\mathrm{STM}},&\text{juegan negras}.
\end{cases}
\]

**Control importante:** durante la preparación y la auditoría se verifica que `teacher_value ≈ tanh(teacher_cp/400)` con tolerancia `1e−5`; no se toma una columna con perspectiva blanca sin demostrarlo. Una auditoría anterior del SQLite completo informó 10.088.531 registros coherentes y **cero discrepancias internas** entre las dos columnas. Esa coherencia **no certifica la procedencia externa**: si ambas etiquetas hubieran sido generadas bajo un criterio equivocado, podrían coincidir entre sí. La última prueba de procedencia sería reevaluar una muestra de FEN con Stockfish y la misma configuración original.

Stockfish **no se ejecuta en cada epoch**: proporciona los objetivos ya almacenados en SQLite.

## 5. Muestra, separación y reproducibilidad

Con los parámetros de la corrida documentada:

```text
Universo SQLite etiquetado: 10.088.531 posiciones
Muestra sin reposición:       10.000 posiciones
Semilla:                       2026
TRAIN / VERIFY:               8.000 posiciones (7.699 partidas representadas)
VALID:                        2.000 posiciones (1.984 partidas representadas)
```

Para evitar que `ORDER BY RANDOM()` sobre millones de filas deje la consola sin actividad, `train.py` recorre los IDs elegibles y utiliza **reservoir sampling** con semilla fija; muestra una barra de avance `SAMPLE` durante el recorrido. Después carga las filas seleccionadas (`LOAD`), verifica FEN y etiquetas (`VERIFY` de datos) y guarda un manifiesto `picoSargon/data/dopey_split.json` con los IDs separados. Esos IDs son la identidad real de la selección; `Audit.py` no vuelve a sortear las posiciones.

**Distinción terminológica:** la barra `VERIFY` de la preparación significa verificar integridad de datos. El `VERIFY` por epoch significa reevaluar los **8.000 ejemplos de entrenamiento con los pesos ya congelados**. Son operaciones distintas y deben documentarse como tales.

**Limitación:** los grupos se separan por **posición, no por partida**. Aunque no se reutiliza un mismo ID entre entrenamiento y validación, pueden existir posiciones muy correlacionadas procedentes de una misma partida en los dos conjuntos. Para una estimación de generalización más fiable debería prepararse una separación por `game_id`, conservando un conjunto TEST independiente.

## 6. Función de pérdida: el mismo criterio que picoAlpha

Se definió como métrica primaria el **MSE sobre el valor normalizado**, no MSE en centipeones cuadrados:

\[
 \mathcal{L}_{\mathrm{value}}=\frac1N\sum_{i=1}^{N}
 \left[\tanh(\widehat{cp}_i/400)-\tanh(cp_i/400)\right]^2.
\]

Por ser `tanh` impar, transformar consistentemente predicción y etiqueta de STM a blancas conserva el cuadrado del error normalizado. La selección del *best* emplea `MSE(value)` de la red cuantizada en VALID; si `--validation 0`, utiliza el conjunto VERIFY e informa que no hubo validación independiente.

Se mide además el error interpretable en centipeones:

\[
 \mathrm{MSE}_{cp^2}=\frac1N\sum_i(\widehat{cp}_i-cp_i)^2,
 \qquad \mathrm{RMSE}_{cp}=\sqrt{\mathrm{MSE}_{cp^2}}.
\]

**No son intercambiables.** `MSE(value)` es adimensional y comprime errores extremos por la saturación de `tanh`; RMSE está en cp y pondera fuertemente desaciertos grandes. Por eso no es correcto interpretar valores como `0,006` o `0,12` como centipeones: son pérdidas normalizadas cuya magnitud depende también de los datos y la capacidad de la red.

## 7. Secuencia del entrenamiento

### 7.1 Fase FP32: aprender una representación continua

`train.py` crea exactamente **1.680 parámetros maestros FP32**, con la topología fijada por GRMP0001. En la versión documentada se inicializan de manera **independiente y reproducible** mediante una normal de media 0 y desviación típica 0,35, con semilla configurada. **No inicializa desde `grumpy.bin`**: por decisión del proyecto, ese archivo se utiliza solo en AUDIT.

Los parámetros se optimizan con **AdamW** y decaimiento de pesos `0.0` (es decir, sin penalización de peso), lote predeterminado 512, barajado reproducible de posiciones y schedule lineal de learning rate. Para la ejecución documentada:

```text
FP32 epochs = 10
lr inicial  = 0,010
lr mínimo   = 0,001
batch       = 512
```

El forward FP32 conserva la suma de características, los acumuladores, las activaciones limitadas, los buckets, la escala y el material, pero **no redondea pesos ni el resultado neuronal a enteros durante esta fase**. Eso permite gradientes continuos y evita que los pequeños cambios queden invisibles al cuantizador.

En cada epoch se realizan tres operaciones lógicamente separadas:

1. **TRAIN (8.000 posiciones):** actualización de los parámetros tras cada lote. Su MSE es un promedio *online*, calculado mientras los pesos cambian, **no** es una evaluación de un modelo único congelado.
2. **VERIFY (8.000 posiciones):** con los pesos finales del epoch ya fijos, se mide la misma muestra tanto con forward FP32 como con **evaluación entera INT6 exacta**.
3. **VALID (2.000 posiciones):** se utiliza exclusivamente la muestra reservada; se miden FP32 e INT6 de nuevo. No se calculan gradientes con estas posiciones.

El mejor `FP32` se guarda en `dopey_best_fp32.pt` según el `MSE(value)` de selección. En paralelo se evalúa la **cuantización directa** del FP32 y se conserva `dopey_best_quant.pt` cuando mejora el criterio de validación de la evaluación entera. El historial completo se guarda en `picoSargon/data/dopey_history.json`.

### 7.2 Fase QAT: adaptar el forward a los 6 bits

Tras FP32 se recupera el **mejor checkpoint continuo**, no necesariamente el último. Comienza entonces el ajuste consciente de cuantización (*Quantization-Aware Training*):

```text
QAT epochs  = 5
lr inicial  = 0,050
lr mínimo   = 0,005
```

Los parámetros maestros **siguen siendo FP32**. En el forward se aplica *fake quantization* mediante redondeo y saturación al rango −31…+32, y se simula el truncamiento entero de la salida. En el backward, el método **Straight-Through Estimator (STE)** deja pasar una aproximación del gradiente a través de esos operadores no diferenciables. Esta es una heurística práctica, no el gradiente exacto de una función entera discontinua.

El QAT persigue que las actualizaciones FP32 se traduzcan en **una mejor evaluación del binario realmente exportable**. La medición de `VERIFY INT6` y `VALID INT6` se realiza con el evaluador entero (`eval_encoded`) y no depende de confiar en que el forward aproximado de PyTorch sea idéntico.

### 7.3 Checkpoints y criterio de publicación

Se escribe un `.pt` por epoch (`dopey_fp32_epoch_0001.pt`, `dopey_qat_epoch_0001.pt`, etc.), además de `dopey_best_fp32.pt`, `dopey_best_quant.pt` y el alias `dopey_best.pt`. Los checkpoints contienen coeficientes maestros, epoch/fase, manifiesto y métricas.

El archivo **que debe exportarse es `dopey_best_quant.pt`**, elegido por `VALID INT6` (*MSE(value)*) y no por el mejor resultado continuo FP32. El entrenamiento falla si no consigue una red cuantizada diferente de su inicialización; esto evita declarar éxito cuando se entrenaron valores flotantes pero el binario seguiría siendo el mismo. **Este control no demuestra por sí solo una mejora respecto de Grumpy**, ya que Grumpy queda fuera del entrenamiento por contrato.

## 8. Evolución observada: FP32 frente a INT6

![Evolución de la validación FP32 e INT6](images/evolucion_validacion_fp32_int6.png)

![Verificación y validación](images/verificacion_validacion.png)

Los 15 epochs de la corrida adjunta presentan una mejora sostenida. Selección de puntos de control, todos en **MSE(value)**:

| Epoch | VALID FP32 | VALID INT6 | Interpretación |
|---|---:|---:|---|
| FP32 1 | 0,13072 | 0,13099 | Primer epoch de la inicialización independiente |
| FP32 5 | 0,12771 | 0,12803 | Disminuyen ambos errores |
| FP32 10 | 0,12714 | 0,12742 | Fin del entrenamiento continuo |
| QAT 1 | 0,12519 | 0,12540 | Ajuste con forward cuantizado |
| QAT 3 | 0,12077 | 0,12044 | INT6 supera ligeramente a la medición FP32 |
| QAT 5 | 0,11873 | **0,11897** | Mejor modelo exportable de esta ejecución |

Es posible que `VALID INT6` resulte mejor que `VALID FP32` en algún epoch: son dos forwards distintos con los mismos parámetros maestros; el entrenamiento QAT optimiza el comportamiento cuantizado, por lo que no hay una desigualdad matemática que obligue a FP32 a ganar.

En la última corrida se informaron **933 de 1.680 coeficientes INT6 diferentes de la inicialización independiente**. Ese número no significa necesariamente que 933 difieran de `grumpy.bin`: el conteo usa como referencia el modelo cuantizado **inicial de esta corrida**.

## 9. Exportación y forma de reutilización

El paso `MON=2` ejecuta `export.py` sobre `dopey_best_quant.pt`. Se recuperan los parámetros maestros, se hace `clip + round`, se empaquetan 16 códigos de seis bits en cada bloque de 12 bytes, se calcula SHA-256 sobre el payload y se generan:

- `picoSargon/assets/dopey.bin` — `GRMP0001`, **1.304 bytes**;
- `picoSargon/assets/dopey.h` — arreglo `constexpr` con el mismo contenido para inclusión C++.

El exportador comprueba por lectura inversa que todos los coeficientes coinciden con los del checkpoint ya cuantizados. Esta prueba verifica el *codec*, no de manera automática la fuerza de la red ni su comportamiento en todas las posiciones posibles.

Se debe usar **un nombre de red distinto** de `grumpy` para no pisar la referencia histórica. En el uso normal de picoSargon, se elige el binario externo mediante `--weights` cuando la variante del ejecutable admite esa opción.

## 10. AUDIT: comparación Dopey y Grumpy contra Stockfish

El paso `MON=3` ejecuta `Audit.py` con la red nueva (`--in dopey.bin`), el manifiesto (`--split dopey_split.json`) y opcionalmente la referencia (`--bin grumpy.bin`). Recorre **exactamente los IDs de validación persistidos**, reconsulta sus etiquetas en SQLite, confirma su coherencia, evalúa ambos binarios con el mismo `eval_encoded` y escribe `picoSargon/data/dopey_audit.json`, incluyendo **FEN, evaluación de Stockfish, salida y error de cada red**.

**La referencia Grumpy solo participa aquí.** No debe figurar como comparador en las métricas TRAIN, VERIFY ni VALID. En AUDIT, ambos errores se miden **contra Stockfish**, no uno directamente contra el otro. Una diferencia positiva `MSE_Grumpy − MSE_Dopey` significa que Dopey se aproxima mejor al objetivo etiquetado.

![Resultado de auditoría de Dopey y Grumpy](images/audit_dopey_vs_grumpy.png)

### 10.1 Resultados exactos sobre 2.000 posiciones

| Magnitud (contra Stockfish) | `grumpy.bin` | `dopey.bin` |
|---|---:|---:|
| MSE(value), menor es mejor | 0,18384551 | **0,11897271** |
| MSE(cp²) | 164.254,0920 | **43.174,9345** |
| RMSE(cp) | 405,283 | **207,786** |
| MAE(cp) | 219,459 | **127,922** |
| Sesgo medio(cp) | +10,763 | −20,074 |

La reducción relativa de MSE(value) es `100 × (0,18384551 − 0,11897271)/0,18384551 = 35,29 %`. La reducción de RMSE(cp) es `48,73 %`. En **1.289 posiciones** Dopey tiene menor error absoluto, en **700** lo tiene Grumpy y en **11** empatan. Estos conteos se obtuvieron comparando las columnas de error por posición de `dopey_audit.json`.

### 10.2 Consistencia por turno

| Turno en la posición | Casos | RMSE(cp) Dopey | RMSE(cp) Grumpy |
|---|---:|---:|---:|
| Blancas | 1.015 | **205,02** | 393,05 |
| Negras | 985 | **210,60** | 417,52 |

El beneficio aparece en ambos subconjuntos. No se observa en estas métricas un fallo sistemático de inversión de perspectiva, aunque ello no reemplaza las pruebas unitarias para FEN y signo.

### 10.3 Tipo de posición y errores grandes

| Valor absoluto de Stockfish | Casos | RMSE(cp) Dopey | RMSE(cp) Grumpy |
|---|---:|---:|---:|
| ≤100 cp | 1.355 | **111,90** | 323,06 |
| 101–300 cp | 327 | **195,54** | 408,88 |
| >300 cp | 318 | **422,93** | 645,30 |

Dopey se aproxima más a Stockfish en promedio dentro de los tres rangos, pero sigue presentando errores significativos en posiciones muy desequilibradas. El fuerte peso de ciertos errores extremos en MSE(cp²) explica por qué es útil acompañar MSE(value) con RMSE y MAE, aunque la selección de checkpoints continúe basándose en la métrica de picoAlpha.

## 11. Dificultades detectadas y soluciones implementadas

| Dificultad | Intervención | Comprobación / límite |
|---|---|---|
| Muestreo SQLite aparentemente congelado | Sustituir `ORDER BY RANDOM()` por reservoir sampling con barra `SAMPLE` | Recorrido visible sobre 10,09 millones de elegibles; coste lineal de lectura |
| Etiquetas Stockfish expresadas en STM | Convertir a blancas según `fen.split()[1]`, verificar relación `teacher_value`/`teacher_cp` | Auditoría interna de 10.088.531 filas sin discrepancias; procedencia externa aún por verificar |
| Intento de optimizar directamente pesos de 6 bits con LR muy pequeño | Pesos maestros FP32 y dos fases FP32→QAT | La corrida previa con valores discretos había dejado MSE idéntico en todos los epochs |
| FP32 mejor pero cuantización degradada | Evaluación INT6 en cada epoch, QAT con STE y selección por error cuantizado real | La mejora de la red exportable se observa explícitamente en VALID INT6 |
| Confusión MSE(value) vs MSE(cp²) | Usar la pérdida normalizada de picoAlpha como criterio primario e informar RMSE/MAE(cp) | Métricas dimensionalmente distintas, no se igualan numéricamente |
| Telemetría sin actualización en consola y emojis corruptos | Barra Unicode `█░`, retorno de carro y scripts `.ps1` UTF-8 con BOM | Windows/PowerShell informado como funcional en la ejecución adjunta |
| Mezcla de TRAIN, VERIFY y VALID | Mostrar cada etapa y columnas FP32/INT6, pesos congelados en VERIFY y VALID | El MSE de TRAIN es *online*, diferente del post-epoch |
| Confusión entre referencia y conjunto de validación | Grumpy retirado de entrenamiento e inicialización, utilizado **solo** en AUDIT | Cambia la curva de aprendizaje respecto de corridas que comenzaban desde Grumpy |
| Riesgo de exportar un FP32 no representable | `best_fp32.pt` separado de `best_quant.pt`; exportación desde el segundo | Verificación del formato exacto y relectura de coeficientes |
| Diferencias potenciales Python/C++ por truncamiento y signo | Implementar evaluador entero de referencia y validar contra el C++ de picoSargon | Se informó concordancia exacta en 7 posiciones; se requieren tests adicionales y propiedades exhaustivas |

## 12. Reproducir el experimento

Desde `akkad/picoSargon/tools/train`, con rutas reales configuradas en `run_genesis.ps1`:

```powershell
# Ejecuta TRAIN, después EXPORT y AUDIT si cada paso termina bien.
.\run_genesis.ps1 -mon 1 -network dopey -sample 10000 -validation 20 -seed 2026

# Reanuda solo exportación + auditoría si el checkpoint está disponible.
.\run_genesis.ps1 -mon 2 -network dopey

# Repite únicamente la auditoría con la referencia original.
.\run_genesis.ps1 -mon 3 -network dopey -referenceBin '..\..\assets\grumpy.bin'
```

Los argumentos principales de `train.py` son `--in`, `--sample`, `--validation`, `--lr`, `--lrmin`, `--epoch`, `--qat-epoch`, `--qat-lr`, `--qat-lrmin`, `--batch`, `--seed` y `--name`. El script PowerShell centraliza rutas de SQLite, `assets` y `data`, y controla los pasos con `MON=1` (entrenar), `MON=2` (exportar), `MON=3` (auditar). Si un paso falla no se incrementa MON.

**Archivos principales:**

| Ruta relativa a `akkad` | Uso |
|---|---|
| `picoSargon/tools/train/network.py` | Codec, representación, evaluación entera y conversión de perspectiva |
| `picoSargon/tools/train/train.py` | Muestreo, separación, FP32, QAT, checkpoints, progreso |
| `picoSargon/tools/train/export.py` | Convierte el checkpoint a `.bin` y `.h` |
| `picoSargon/tools/train/Audit.py` | Comparación contra Stockfish y Grumpy, por posición |
| `picoSargon/tools/train/run_genesis.ps1` | Orquestación MON y parámetros |
| `picoSargon/assets/dopey_best_fp32.pt` | Mejor representación continua |
| `picoSargon/assets/dopey_best_quant.pt` | Mejor representación exportable |
| `picoSargon/assets/dopey.bin` | Red INT6 para el motor |
| `picoSargon/data/dopey_split.json` | IDs entrenados y validados |
| `picoSargon/data/dopey_history.json` | Métricas y pesos cambiados por epoch |
| `picoSargon/data/dopey_audit.json` | Predicción, objetivo y errores de los dos binarios |

## 13. Qué se ha demostrado y qué no

**Comprobado en el código y los datos entregados:** topología de 1.680 coeficientes, empaquetado `GRMP0001` de 1.304 bytes, separación explícita TRAIN/VERIFY/VALID por IDs, aprendizaje FP32 y QAT con disminución de MSE(value), selección por error cuantizado y mejora sustancial respecto de las etiquetas de Stockfish en los 2.000 registros auditados. También existe evidencia previa de paridad entre Python y C++ para una muestra de posiciones.

**No demostrado todavía:** generalización a posiciones completamente inéditas, ausencia de contaminación entre partidas, reproducibilidad de todos los hashes sin congelar versión de base y entorno, mejora de Elo, ausencia de divergencias con reglas terminales o repetición de posiciones, y preservación exacta del rendimiento al portar a ARM. La red no sustituye al buscador: el efecto de su error sobre las jugadas requiere medirlo en partidas.

La principal limitación estadística es que **AUDIT reutiliza los 2.000 ejemplos de VALID utilizados para elegir el mejor checkpoint**. No son gradientes de entrenamiento, pero sí influyen indirectamente en la selección del modelo. Por eso la comparación de 35,29 % es una medida *interna de selección*, no una estimación ciega de generalización. Si se evalúan muchos epochs contra las mismas posiciones, se puede sobreajustar indirectamente la selección a ese conjunto.

## 14. Próximos experimentos recomendados

1. **Separar por partida y reservar TEST antes de entrenar.** Evitar que cualquier `game_id` aparezca en más de un conjunto y mantener TEST fuera de la selección. Preservar la semilla y los hashes del manifiesto.
2. **Auditar una segunda muestra ciega** con `dopey.bin` y `grumpy.bin` ejecutando el mismo evaluador entero; comparar MSE(value), RMSE(cp), MAE, sesgo y resultados por color, fase de juego y bucket.
3. **Verificar contra Stockfish en vivo una submuestra pequeña** para confirmar perspectiva, profundidad y procedencia de `teacher_cp`, sin modificar las etiquetas originales.
4. **Ensayar partidas reproducibles** alternando colores, posiciones iniciales y parámetros de búsqueda; registrar el identificador y hash del binario realmente cargado por cada ejecutable.
5. **Medir recursos en plataforma de destino:** flash, RAM, coste de extraer características, nodos/s y efecto sobre latencia de búsqueda. Solo después considerar acumuladores incrementales u optimizaciones que cambien el código.

### Conclusión

La decisión técnica más importante fue **separar el aprendizaje de una función continua de la evaluación final de un entero de 6 bits**, y no dar por buena una red hasta medir exactamente el binario que ejecutará picoSargon. La cadena FP32→QAT resuelve el bloqueo por cuantización que había producido epochs sin variación efectiva y obtiene una reducción considerable del error de evaluación en los datos reservados. El paso pendiente con mayor impacto no es aumentar los epochs ni ajustar todavía más el learning rate: es **realizar una prueba ciega, separada por partidas, y medir luego el efecto sobre la fuerza de juego**.

---

## Anexo A. Figuras reproducibles y descargables

Los siguientes archivos acompañan este Markdown (las rutas relativas funcionan al mantener la carpeta `images/` junto al documento):

- [`arquitectura_grmp0001.png`](images/arquitectura_grmp0001.png) — esquema de entradas, acumuladores, buckets, material y salida.
- [`evolucion_validacion_fp32_int6.png`](images/evolucion_validacion_fp32_int6.png) — 15 epochs, validación FP32 frente a INT6.
- [`verificacion_validacion.png`](images/verificacion_validacion.png) — error en el grupo de entrenamiento congelado frente al reservado.
- [`audit_dopey_vs_grumpy.png`](images/audit_dopey_vs_grumpy.png) — evaluación comparativa contra etiquetas de Stockfish.

También se incluyen versiones vectoriales `.svg` de las cuatro figuras y `picoSargon_grumpy_evolucion_mse.json` con los puntos de la curva extraídos de la telemetría aportada.

## Anexo B. Fuentes de esta nota

- Implementaciones inspeccionadas: `picoSargon/x86/src/grumpy.cpp` y `picoSargon/ARM/src/grumpy.cpp`, en la línea de base de Akkad; `picoSargon/tools/train/network.py`, `train.py`, `export.py`, `Audit.py` y `run_genesis.ps1`, reconstruidos a partir de los parches incrementales v0.1.44–v0.1.49.
- Registros de la ejecución del 16/11/2026: telemetría completa de quince epochs y exportación, más `dopey_audit.json` con 2.000 filas individuales. No se han inventado curvas de entrenamiento ni resultados de AUDIT.
- La documentación describe la implementación **observable en estos archivos**. Si en el repositorio local se realizaron cambios posteriores, deben verificarse contra una nueva base antes de tratar esta nota como especificación ejecutable actual.
