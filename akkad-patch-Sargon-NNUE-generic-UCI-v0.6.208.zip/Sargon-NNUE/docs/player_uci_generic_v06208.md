# Sargon-NNUE v0.6.208 — player UCI genérico

El nuevo `player=UCI` es un adaptador a un **motor local por STDIN/STDOUT**. Requiere `evaluator=null`: el motor hijo es responsable de la búsqueda y su evaluación. Esto **no es** `player=external` (TCP).

## Configuración en `brains.json`

```json
{
  "brains": {
    "motor_uci": {
      "player": "UCI",
      "evaluator": "null",
      "engine-path": {
        "windows": "C:/tools/engine.exe",
        "debian": "/usr/local/bin/engine",
        "macos": "/opt/homebrew/bin/engine"
      },
      "args": ["--option", "value with spaces"],
      "tmax": 15000,
      "timeout": 30000,
      "rating_elo": 400
    }
  }
}
```

Para un motor escrito en Python, **`engine-path` debe ser el intérprete Python**, y en `args` se indica el script (no se construye una cadena para el shell):

```json
"engine-path": {"windows": "C:/Python/python.exe", "debian": "/usr/bin/python3", "macos": "/opt/homebrew/bin/python3"},
"args": ["-u", "/ruta/absoluta/motor_uci.py"]
```

Las rutas de `args` son literales, no se fuerzan bajo `Sargon-NNUE`; si se usan relativas, se resuelven desde el directorio actual del proceso. Para portabilidad se recomienda un launcher estable por plataforma o rutas absolutas del script adecuadas a cada sistema. El mapa `engine-path` selecciona exactamente la plataforma correspondiente o `default` si existe.

`args` solo admite una lista JSON de cadenas. `rating_elo` es **metadato** y nunca se envía al motor como control UCI.

## Protocolo y sincronización

- Arranque: `uci` → `uciok`, luego `isready` → `readyok`.
- Antes de una jugada: `isready` → `readyok`, luego `position ...` y `go`.
- Si `go` no incluye límite, se convierte en `go movetime <tmax>`. Si incluye un límite UCI explícito, se respeta. `go infinite` se limita a `tmax` porque el listener actual procesa `go` sincrónicamente.
- Se espera a `bestmove` **antes de permitir la siguiente jugada**; `ucinewgame` también espera `readyok`.
- `timeout` (ms) limita esperas de handshake y protege ante bloqueos; con `go movetime`, incluye margen adicional al tiempo de búsqueda. Ante timeout se envía `stop` y se termina el proceso para evitar respuestas obsoletas.
- `stdout` del hijo es exclusivamente protocolo UCI. `stderr` del hijo se recoge en un hilo y se reenvía exclusivamente a `stderr` del contenedor Sargon-NNUE. Los mensajes `info` se conservan y se reenvían desde `listen`.
- La clase `GenericUCIPlayer` implementa `choose()`, `new_game()`, `is_ready()`, `stop()` y `close()` con terminación forzada si el proceso no responde a `quit`.

**Limitación conocida:** la capa `UCISession` de Sargon-NNUE procesa búsquedas sincrónicamente para todos los players; por ello, un comando `stop` recibido **durante** `choose()` no se despacha inmediatamente. El uso normal de `match`, `rally` y `benchmark` es con `go` acotado; no utilizar `go infinite` para este frontend.

## Compatibilidad

La misma definición de `brains.json` se usa desde `listen --brain ... --id ...`, `benchmark --brain ... --ids ...`, `match --brain ... --idA ... --idB ...` y `rally` (que invoca a `match`).

Pruebas de integración: `python -m unittest discover -s tests -p 'test_generic_uci_v06208.py'`.
