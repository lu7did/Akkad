"""Microchess historical move policy with optional deeper adversarial extension.

v0.3.0: GNM and piece slots are owned by the Microchess core; JANUS/STRATGY
is used at every depth when paired with the Microchess evaluator. Other
interchangeable evaluators retain the shared position-only evaluate(board).
"""
from __future__ import annotations
import time
import chess
from .base import Player,PlayerError
from ..types import MoveChoice,MATE_CP
from ..evaluators.microchess import PieceTable,gnm,MicrochessEvaluator

class _Deadline(Exception):pass

class MicrochessPlayer(Player):
    name='MICROCHESS'
    version='0.3.0'
    def __init__(self,evaluator,depth=2,qdepth=0,tmax_ms=15000,telemetry=None):
        if int(depth)<1 or int(qdepth)<0:raise PlayerError('microchess: depth>=1, qdepth>=0')
        self.evaluator=evaluator;self.depth=int(depth);self.qdepth=int(qdepth)
        self.tmax_ms=max(1,int(tmax_ms or 15000));self.telemetry=telemetry
        self.nodes=0;self._table=None

    def _check(self):
        if time.monotonic()>self.deadline:raise _Deadline()

    def _moves(self,board):
        return list(gnm(board,board.turn,table=self._table))

    def _static(self,board,ply):
        if board.is_checkmate():return -MATE_CP+ply
        if board.is_stalemate() or board.is_insufficient_material() or board.is_seventyfive_moves() or board.is_fivefold_repetition():return 0
        return int(self.evaluator.evaluate(board))*(1 if board.turn else -1)

    def _qsearch(self,board,qleft,alpha,beta,ply):
        self.nodes+=1;self._check()
        if board.is_game_over(claim_draw=False):return self._static(board,ply)
        score=self._static(board,ply)
        if qleft<=0:return score
        if board.is_check():moves=self._moves(board)
        else:
            if score>=beta:return score
            alpha=max(alpha,score)
            moves=[m for m in self._moves(board) if board.is_capture(m) or m.promotion]
        if not moves:return score if board.is_check() else alpha
        for m in moves:
            self._table.push(m,board);board.push(m)
            try:v=-self._qsearch(board,qleft-1,-beta,-alpha,ply+1)
            finally:board.pop();self._table.pop()
            if v>=beta:return v
            alpha=max(alpha,v)
        return alpha

    def _search(self,board,depth,alpha,beta,ply):
        self.nodes+=1;self._check()
        if board.is_game_over(claim_draw=False):return self._static(board,ply)
        if depth<=0:return self._qsearch(board,self.qdepth,alpha,beta,ply)
        moves=self._moves(board)
        if not moves:return self._static(board,ply)
        historical=isinstance(self.evaluator,MicrochessEvaluator)
        # Historical move scores are calculated at every interior node; they
        # are not silently replaced by a different static function at depth 2.
        graded=[]
        if historical:
            for m in moves:
                self._check()
                graded.append((self.evaluator.evaluate_candidate(board,m,exchange_branch=2),m))
            graded.sort(key=lambda item:item[0],reverse=True)
        else:
            graded=[(0,m) for m in moves]
        best=-MATE_CP-1
        for immediate,m in graded:
            self._check()
            if depth==1 and historical:
                v=immediate
            else:
                self._table.push(m,board);board.push(m)
                try:continuation=-self._search(board,depth-1,-beta,-alpha,ply+1)
                finally:board.pop();self._table.pop()
                # When using STRATGY, average immediate and opponent-aware
                # continuation in the SAME move-score scale. This extension
                # is modern and NOT Jennings' original depth-1 selection.
                v=(immediate+continuation)//2 if historical else continuation
            best=max(best,v);alpha=max(alpha,v)
            if alpha>=beta:break
        return best

    def choose(self,board):
        start=time.monotonic();self.deadline=start+self.tmax_ms/1000
        self.nodes=0;self._table=PieceTable(board)
        fen=board.fen();moves=self._moves(board)
        if not moves:return MoveChoice(None,0,0,0,0.0,self.name)
        best=moves[0];score=0;completed=0
        historical=isinstance(self.evaluator,MicrochessEvaluator)
        try:
            # Depth 1 = historical-style decision. Depth > 1 is an explicitly
            # extended policy that retains move-specific STRATGY throughout.
            for d in range(1,self.depth+1):
                candidate=None;value=-MATE_CP-1
                ranked=[]
                if historical:
                    for m in moves:
                        self._check()
                        ranked.append((self.evaluator.evaluate_candidate(board,m,exchange_branch=2),m))
                    ranked.sort(key=lambda item:item[0],reverse=True)
                else:ranked=[(0,m) for m in moves]
                for immediate,m in ranked:
                    self._check()
                    if d==1 and historical:result=immediate
                    else:
                        self._table.push(m,board);board.push(m)
                        try:continuation=-self._search(board,d-1,-MATE_CP-1,MATE_CP+1,1)
                        finally:board.pop();self._table.pop()
                        result=(immediate+continuation)//2 if historical else continuation
                    if result>value: candidate,value=m,result
                if candidate is not None:best,score,completed=candidate,value,d
        except _Deadline:pass
        finally:
            if board.fen()!=fen or self._table._undos:
                raise PlayerError('microchess: board or piece table not restored')
        return MoveChoice(best,int(score if board.turn else -score),completed,
                          self.nodes,(time.monotonic()-start)*1000,self.name)
