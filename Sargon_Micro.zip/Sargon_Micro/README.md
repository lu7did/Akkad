# Pico Sargon / Doc — núcleo portátil de reglas v0.1.3

**Objetivo:** sustituir las funciones esenciales de `python-chess` utilizadas por un futuro player Doc reducido en **MicroPython / Raspberry Pi Pico W**. Este paquete es un módulo incremental respecto del núcleo `device/chesscore.py` de Pico SargonPlus NPZ v0.1.2; **no integra aún Doc con el nuevo tablero**.

## Organización

- `device/chesscore.py`: motor puro Python/MicroPython, sin bibliotecas externas.
- `tests/test_chesscore.py`: validación en CPython mediante `unittest`.
- Las reglas, la NNUE y el protocolo UCI están deliberadamente separados.

## Convenciones compatibles con Pico SargonPlus

- Casilla `a1 = 0`, `h8 = 63`; `square = rank * 8 + file`.
- Piezas: `P=1`, `N=2`, `B=3`, `R=4`, `Q=5`, `K=6`; negativas para negras.
- Turno: `+1` blancas, `-1` negras.
- Jugadas: `(from_square, to_square, promotion)`; `promotion=0` o `2/3/4/5`.
- Entradas/salidas en notación UCI: `e2e4`, `e7e8q`, etc.
- FEN estándar: disposición, turno, derechos de enroque, en-passant y contadores.

## Interfaz

```python
from chesscore import Board
b = Board()
move = b.parse('e2e4') # comprueba legalidad
b.push(move)           # hace jugada y guarda estado
assert not b.in_check()
b.pop()                # deshace exactamente la jugada
legal = b.legal()      # lista de tuplas de jugadas
result = b.outcome(claim_draw=True)
```

`outcome()` devuelve `None` si la partida sigue, o `(causa, ganador)` donde el ganador es `1` (blancas), `-1` (negras) o `0` (tablas). Se reconocen mate, ahogado, material insuficiente, cinco repeticiones, 75 movimientos, y reclamaciones opcionales de tres repeticiones y 50 movimientos. Los derechos de enroque, la promoción y la captura al paso están implementados.

La detección de repetición usa la **posición**, el turno, los derechos de enroque y el derecho efectivo de captura al paso (no confunde cambios del reloj con posiciones nuevas). Se conserva un historial en memoria: un reinicio elimina ese historial y, por ello, **no puede recuperar repeticiones previas a la reconexión** sin recibir la lista de jugadas desde UCI.

### Condiciones que necesitan tratamiento especial

- Una oferta voluntaria de tablas no es una condición de tablero y queda fuera de `chesscore`.
- El plazo de reclamación de 50 movimientos y tres repeticiones se representa mediante `claim_draw=True`, mientras que los finales obligatorios se reconocen sin reclamación.
- La validación FEN es **sintáctica y parcial**: no comprueba todas las imposibilidades retrospectivas de un tablero arbitrario. El cliente debe proporcionar posiciones legales.
- No implementa Chess960, variantes ni la notación SAN/PGN; el protocolo es UCI.
- No es un sustituto *drop-in* de los objetos `chess.Board` y `chess.Move`; Doc deberá adaptarse a las tuplas y funciones aquí documentadas.

## Pruebas

Desde el directorio raíz de este paquete:

```bash
python -m unittest discover -s tests -v
```

Incluye **perft** de referencia: inicio 20/400/8902 y posición táctica 14/191/2812 a profundidades 1/2/3, además de enroque, captura al paso, promoción, mate, ahogado, material insuficiente, repetición, regla de 50/75 movimientos y restauración del tablero.

**Pendiente para producción**: ejecutar perft más profundo y un conjunto amplio comparado contra `python-chess`, probar límites de SRAM y tiempo en hardware Pico W, y sustituir los snapshots de deshacer por deltas si su memoria resulta excesiva. El núcleo actual privilegia simplicidad y corrección frente a eficiencia.

## Decisión de arquitectura

Recomiendo **conservar este módulo como único motor de reglas** en Pico, compartido por el player y por la interfaz UCI. Evita implementar dos motores de movimientos que puedan discrepar. Al portar Doc, su evaluador Grumpy recibirá `b.squares` y `b.turn` directamente con estas convenciones. Nunca se deben declarar equivalentes la función `evaluate` de Grumpy y la verificación de legalidad: esta última pertenece solo al tablero.
