#include "multicore.hpp"
#include <algorithm>
#include <atomic>
#include <chrono>
#include <exception>
#include <cmath>
#include <limits>
#include <stdexcept>
#include <thread>
#include <utility>

namespace {
using Clock=std::chrono::steady_clock;
using picoSargon::Board;
using picoSargon::Move;
using TimePoint=Clock::time_point;
struct WorkerData {
 std::uint64_t nodes=0, leaves=0, batches=0, evaluations=0;
 std::int64_t inference_us=0;
};
struct SearchValue {double value=0.0; bool complete=false;};
constexpr double INF=2.0; // network evaluation is constrained to [-1,+1]

bool expired(const TimePoint& deadline) {return Clock::now()>=deadline;}
SearchValue minimax(Board& board, Evaluator& evaluator, int depth,
                    double alpha, double beta, const TimePoint& deadline,
                    WorkerData& stats) {
 if(expired(deadline))return {};
 ++stats.nodes;
 if(board.draw())return {0.0,true};
 std::vector<Move> legal;
 board.legal(legal);
 if(legal.empty())return {board.in_check()?-1.0:0.0,true};
 if(depth<=0){
  const auto start=Clock::now();
  const double v=evaluator.eval(board);
  stats.inference_us+=std::chrono::duration_cast<std::chrono::microseconds>(Clock::now()-start).count();
  ++stats.leaves; ++stats.evaluations; ++stats.batches;
  return {v,!expired(deadline)};
 }
 // Batch all sibling leaves. Avoids one neural invocation per chess move.
 if(depth==1){
  std::vector<Board> batch;
  std::vector<size_t> indices;
  std::vector<double> values(legal.size());
  batch.reserve(legal.size());indices.reserve(legal.size());
  for(size_t i=0;i<legal.size();++i){
   if(expired(deadline))return {};
   board.push(legal[i]);
   if(board.draw())values[i]=0.0;
   else {
    std::vector<Move> replies;board.legal(replies);
    if(replies.empty())values[i]=board.in_check()?-1.0:0.0;
    else {batch.push_back(board);indices.push_back(i);}
   }
   board.pop();
   ++stats.nodes; ++stats.leaves;
  }
  if(!batch.empty()){
   const auto start=Clock::now();
   auto predicted=evaluator.eval_batch(batch);
   stats.inference_us+=std::chrono::duration_cast<std::chrono::microseconds>(Clock::now()-start).count();
   if(predicted.size()!=indices.size())throw std::runtime_error("neural batch size mismatch");
   ++stats.batches; stats.evaluations+=batch.size();
   for(size_t j=0;j<indices.size();++j)values[indices[j]]=predicted[j];
  }
  if(expired(deadline))return {};
  double best=-INF;
  for(double child_value:values)best=(std::max)(best,-child_value);
  return {best,true};
 }
 double best=-INF;
 for(Move move:legal){
  if(expired(deadline))return {};
  board.push(move);
  auto child=minimax(board,evaluator,depth-1,-beta,-alpha,deadline,stats);
  board.pop();
  if(!child.complete)return {};
  const double v=-child.value;
  best=(std::max)(best,v);
  alpha=(std::max)(alpha,v);
  if(alpha>=beta)break;
 }
 return {best,true};
}
}

ParallelResult choose_multicore(const Board& board,
                                const std::vector<Evaluator*>& evaluators,
                                int depth, std::int64_t budget_ms) {
 if(evaluators.empty() || depth<2 || depth>8 || budget_ms<1)
  throw std::invalid_argument("invalid multicore search configuration");
 const auto start=Clock::now();
 const auto deadline=start+std::chrono::milliseconds(budget_ms);
 ParallelResult result;
 result.depth=depth;
 std::vector<Move> moves;
 Board root=board;
 root.legal(moves);
 if(root.draw()||moves.empty())return result;
 const unsigned workers=(std::min)(evaluators.size(),moves.size());
 result.workers=static_cast<int>(workers);
 std::vector<double> values(moves.size(),-INF);
 std::vector<unsigned char> completed(moves.size(),0);
 std::vector<WorkerData> data(workers);
 std::vector<std::exception_ptr> failures(workers);
 std::atomic<size_t> next{0};
 std::vector<std::thread> threads;
 threads.reserve(workers);
 for(unsigned w=0;w<workers;++w){
  threads.emplace_back([&,w]{
   try {
   auto& evaluator=*evaluators[w];
   auto& stats=data[w];
   while(!expired(deadline)){
    const size_t i=next.fetch_add(1,std::memory_order_relaxed);
    if(i>=moves.size())break;
    Board child=board;
    child.push(moves[i]);
    const auto value=minimax(child,evaluator,depth-1,-INF,INF,deadline,stats);
    if(value.complete){values[i]=-value.value;completed[i]=1;}
   }
   } catch(...) {failures[w]=std::current_exception();}
  });
 }
 for(auto& t:threads)t.join();
 for(const auto& failure:failures)if(failure)std::rethrow_exception(failure);
 result.elapsed_ms=std::chrono::duration_cast<std::chrono::milliseconds>(Clock::now()-start).count();
 result.timed_out=std::any_of(completed.begin(),completed.end(),[](unsigned char x){return x==0;});
 result.worker_nodes.reserve(workers);
 for(const auto& w:data){
  result.nodes+=w.nodes;result.leaves+=w.leaves;result.batches+=w.batches;
  result.evaluations+=w.evaluations;result.inference_us+=w.inference_us;
  result.worker_nodes.push_back(w.nodes);
 }
 // Stable tie-break, irrespective of completion order.
 double best=-INF;
 for(size_t i=0;i<moves.size();++i){
  if(completed[i] && (!result.found || values[i]>best)){
   result.found=true;result.move=moves[i];result.score=values[i];best=values[i];
  }
 }
 // Never emit bestmove (none) merely because the budget elapsed before the
 // first root subtree finished; choose the first legal move as safe fallback.
 if(!result.found){result.move=moves.front();result.found=true;result.score=0.0;}
 return result;
}
