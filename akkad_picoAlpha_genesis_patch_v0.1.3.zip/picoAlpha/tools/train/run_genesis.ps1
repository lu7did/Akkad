# Akkad / picoAlpha - Genesis training orchestrator v0.1.3
# Execute from any directory. Edit defaults in the CONFIGURATION block.
[CmdletBinding()]
param(
    [Alias('h')][switch]$Help,
    [string]$HistoryDir = 'C:\Users\pedro\github\Bobby\Chess_History_pb\picoAlpha',
    [string]$PgnPattern = 'C:\Users\pedro\github\Bobby\Chess_History_pb\pgn\*.pgn',
    [ValidateRange(0,100)][int]$Sample = 20,
    [int]$Seed = 42,
    [string]$Engine = 'stockfish.exe',
    [string]$EngineArgs = '',
    [ValidateRange(1,2147483647)][int]$Depth = 10,
    [Nullable[int]]$Nodes = $null,
    [ValidateRange(0,100)][int]$Validate = 20,
    [ValidateRange(1,2147483647)][int]$Epoch = 20,
    [ValidateSet('AdamW','Adam','SGD','RMSprop')][string]$Method = 'AdamW',
    [double]$Lr = 0.005,
    [double]$LrMin = 0.0001,
    [ValidateRange(1,2147483647)][int]$Batch = 64,
    [ValidateSet('cpu','cuda','xpu')][string]$Device = 'cpu',
    [double]$ValueWeight = 2.0,
    [string]$AssetsDir = '',
    [string]$Namespace = 'picoalpha_nnue'
)

$ErrorActionPreference = 'Stop'
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProjectDir = [System.IO.Path]::GetFullPath((Join-Path $ScriptDir '..\..'))

if ($Help) {
    Write-Host 'Genesis pipeline picoAlpha v0.1.3 - seis pasos secuenciales MON=0..5'
    Write-Host 'Uso: .\run_genesis.ps1 [-HistoryDir PATH] [-PgnPattern GLOB] [-Sample 0..100] ... [-Help]'
    Write-Host 'Todos los parametros pueden modificarse al invocar el script:'
    Write-Host '  -HistoryDir PATH    Base de datos history.pb y sample_history.pb (directorio)'
    Write-Host '  -PgnPattern GLOB    Archivos PGN para loader.py'
    Write-Host '  -Sample N           Porcentaje de partidas muestreadas (default 20)'
    Write-Host '  -Seed N             Semilla de muestreo y entrenamiento (default 42)'
    Write-Host '  -Engine PATH        Ejecutable Stockfish (default stockfish.exe)'
    Write-Host '  -EngineArgs STRING  Argumentos adicionales Stockfish (default vacio)'
    Write-Host '  -Depth N            Profundidad Stockfish (default 10)'
    Write-Host '  -Nodes N            Limite opcional de nodos para Stockfish'
    Write-Host '  -Validate N         Porcentaje validacion (default 20)'
    Write-Host '  -Epoch N            Epocas PyTorch (default 20)'
    Write-Host '  -Method NAME        AdamW|Adam|SGD|RMSprop (default AdamW)'
    Write-Host '  -Lr N               Learning rate inicial (default 0.005)'
    Write-Host '  -LrMin N            Learning rate minimo (default 0.0001)'
    Write-Host '  -Batch N            Tamaño de lote (default 64)'
    Write-Host '  -Device NAME        cpu|cuda|xpu (default cpu)'
    Write-Host '  -ValueWeight N      Peso del loss valor (default 2.0)'
    Write-Host '  -AssetsDir PATH     Carpeta de activos (default picoAlpha/assets)'
    Write-Host '  -Namespace NAME     Namespace del header C++ (default picoalpha_nnue)'
    Write-Host 'Paso 0 sobrescribe history.pb; paso 2 sobrescribe sample_history.pb.'
    return
}

if ([string]::IsNullOrWhiteSpace($AssetsDir)) { $AssetsDir = Join-Path $ProjectDir 'assets' }
$HistoryDir = [System.IO.Path]::GetFullPath($HistoryDir)
$AssetsDir = [System.IO.Path]::GetFullPath($AssetsDir)
$HistoryDb = Join-Path $HistoryDir 'history.pb'
$SampleDb = Join-Path $HistoryDir 'sample_history.pb'
$CheckpointDir = Join-Path $AssetsDir 'checkpoints'
$BestPt = Join-Path $CheckpointDir 'best.pt'
$CppHeader = Join-Path $AssetsDir 'picoalpha_nnue_weights.hpp'

# MON is the next step permitted to execute. Advance only after an exit code of zero.
$MON = 0

function Invoke-GenesisStep {
    param(
        [Parameter(Mandatory=$true)][int]$Number,
        [Parameter(Mandatory=$true)][string]$Purpose,
        [Parameter(Mandatory=$true)][string]$Runner,
        [Parameter(Mandatory=$true)][string[]]$Arguments
    )
    if ($script:MON -ne $Number) { return }
    $runnerPath = Join-Path $ScriptDir $Runner
    if (-not (Test-Path -LiteralPath $runnerPath -PathType Leaf)) {
        throw "Falta el script requerido: $runnerPath (MON=$script:MON)"
    }
    Write-Host ("⚙️ Paso {0:D2} - {1}" -f $Number, $Purpose)
    $global:LASTEXITCODE = 0
    try {
        & $runnerPath @Arguments
        $invocationSucceeded = $?
        $code = $LASTEXITCODE
        if (-not $invocationSucceeded) { throw 'El script invocado reporto un fallo.' }
        if ($null -ne $code -and $code -ne 0) { throw "Codigo de salida: $code" }
    } catch {
        throw ("Paso {0:D2} fallido; MON permanece en {1}. {2}" -f $Number, $script:MON, $_.Exception.Message)
    }
    $script:MON++
}

New-Item -ItemType Directory -Force -Path $HistoryDir, $CheckpointDir | Out-Null
Write-Host ("Genesis: history={0} sample={1} checkpoints={2} best={3}" -f $HistoryDb, $SampleDb, $CheckpointDir, $BestPt)

Invoke-GenesisStep -Number 0 -Purpose 'Inicializar historico history.pb' -Runner 'run_create.ps1' -Arguments @('--out', $HistoryDb)
Invoke-GenesisStep -Number 1 -Purpose 'Importar partidas PGN al historico' -Runner 'run_loader.ps1' -Arguments @('--in', $PgnPattern, '--out', $HistoryDb)
Invoke-GenesisStep -Number 2 -Purpose 'Crear muestra sample_history.pb' -Runner 'run_sampler.ps1' -Arguments @('--in', $HistoryDb, '--out', $SampleDb, '--sample', [string]$Sample, '--seed', [string]$Seed)
$teacherArgs = @('--in', $SampleDb, '--engine', $Engine, '--args', $EngineArgs, '--depth', [string]$Depth)
if ($null -ne $Nodes) { $teacherArgs += @('--nodes', [string]$Nodes) }
Invoke-GenesisStep -Number 3 -Purpose 'Etiquetar politica y valor con Stockfish' -Runner 'run_teacher.ps1' -Arguments $teacherArgs
Invoke-GenesisStep -Number 4 -Purpose 'Entrenar NNUE y generar checkpoints PyTorch' -Runner 'run_train.ps1' -Arguments @('--in', $SampleDb, '--out', $CheckpointDir, '--validate', [string]$Validate, '--epoch', [string]$Epoch, '--method', $Method, '--lr', [string]$Lr, '--lr_min', [string]$LrMin, '--batch', [string]$Batch, '--seed', [string]$Seed, '--device', $Device, '--value_weight', [string]$ValueWeight)
if ($MON -eq 5 -and -not (Test-Path -LiteralPath $BestPt -PathType Leaf)) {
    throw "Paso 05 no puede comenzar: no existe el checkpoint $BestPt"
}
Invoke-GenesisStep -Number 5 -Purpose 'Exportar mejor checkpoint como pesos INT8 C++' -Runner 'run_export.ps1' -Arguments @('--in', $BestPt, '--out', $CppHeader, '--namespace', $Namespace)
if ($MON -eq 6) { Write-Host ("Genesis completado: MON={0}; best={1}; header={2}" -f $MON, $BestPt, $CppHeader) }
