"""picoGen v0.1.54 — GRMP0001 architecture, FP32, EvoTorch PGPE + analytic refinement.

Fitness: probability MSE + normalized cp MSE. PGPE still selects/updates its
population using ranking; separate Adam refinement uses the real objective
magnitude and derivatives, seeded by the best PGPE candidate. No T77 updates.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path

import numpy as np
import torch

from gen_grumpy_pgpe_core import (PARAMS, FORMAT, load_csv, to_torch,
                                  forward, loss_parts, metrics)
from gen_csv_dataset import sha256
from gen_fp32_core import write_json_atomic, write_npy_atomic

VERSION='0.1.54'
CK_FORMAT='picogen-grumpy-1680-pgpe-hybrid-cp-v2'


def device_for(value):
    if value!='auto':
        dev=value
    elif hasattr(torch,'xpu') and torch.xpu.is_available():
        dev='xpu'
    elif torch.cuda.is_available():
        dev='cuda'
    else:
        dev='cpu'
    d=torch.device(dev)
    if d.type=='xpu' and (not hasattr(torch,'xpu') or not torch.xpu.is_available()):
        raise RuntimeError('XPU unavailable')
    return d


def fitness_population(params, batch, device, pos_chunk, pop_chunk, cp_weight):
    # EvoTorch supplies ReadOnlyTensor values. A .to(device) call may preserve
    # their subclass, especially when source and target are on the same device.
    # Materialize a fresh ordinary Tensor: the objective must not propagate
    # ReadOnlyTensor into mutable running accumulators (or in-place kernels).
    # Population is small (50 x 1680 FP32 ~= 336 KB).
    values=params.detach().clone().as_subclass(torch.Tensor).to(device=device,dtype=torch.float32)
    outputs=[]
    for i in range(0,len(values),pop_chunk):
        w=values[i:i+pop_chunk]
        sum_loss=torch.zeros(len(w),dtype=torch.float64,device=device)
        for j in range(0,len(batch[-1]),pos_chunk):
            sub=tuple(t[j:j+pos_chunk] for t in batch)
            with torch.no_grad():
                pred=forward(w,sub)
                loss,_,_=loss_parts(pred,sub[-1][None,:],cp_weight)
            sum_loss = sum_loss + loss.double()*len(sub[-1])
        outputs.append((sum_loss/len(batch[-1])).float().to(params.device))
    return torch.cat(outputs)


def refine_cpu_adam(refined, adam, batch, device, cp_weight, steps):
    """PGPE companion: differentiate on evaluation device, update Adam on CPU.

    The optimizer, parameters, first/second moments and step counter are
    allocated on host memory. No multi_tensor/foreach Adam kernel runs on XPU.
    """
    if refined.device.type != 'cpu':
        raise RuntimeError('Analytic Adam parameters must reside on CPU')
    for _ in range(steps):
        adam.zero_grad(set_to_none=True)
        leaf=refined.detach().to(device).clone().requires_grad_(True)
        pred=forward(leaf,batch)
        mixed,_,_=loss_parts(pred,batch[-1],cp_weight)
        mixed.backward()
        if leaf.grad is None or not torch.isfinite(leaf.grad).all():
            raise FloatingPointError('Missing/nonfinite analytic gradient')
        refined.grad=leaf.grad.detach().to('cpu').clone()
        torch.nn.utils.clip_grad_norm_([refined],10.0)
        adam.step()
        del pred,mixed,leaf
    if any(torch.is_tensor(v) and v.device.type != 'cpu'
           for state in adam.state.values() for v in state.values()):
        raise RuntimeError('Adam state unexpectedly allocated outside CPU')


def main():
    p=argparse.ArgumentParser(description='picoGen Grumpy FP32 PGPE + gradient refinement v'+VERSION)
    for flag in ('train','validation','out'):p.add_argument('--'+flag,required=True)
    p.add_argument('--population',type=int,default=50)
    p.add_argument('--generations',type=int,default=100)
    p.add_argument('--seed',type=int,default=42)
    p.add_argument('--fitness-sample',type=int,default=500000)
    p.add_argument('--validation-sample',type=int,default=1000)
    p.add_argument('--batch-size',type=int,default=20000)
    p.add_argument('--device',default='auto')
    p.add_argument('--pgpe-stdev',type=float,default=0.1)
    p.add_argument('--center-lr',type=float,default=0.01)
    p.add_argument('--stdev-lr',type=float,default=0.1)
    p.add_argument('--population-chunk',type=int,default=4)
    p.add_argument('--position-chunk',type=int,default=256)
    p.add_argument('--cp-weight',type=float,default=1.0)
    p.add_argument('--gradient-lr',type=float,default=0.03)
    p.add_argument('--gradient-batch',type=int,default=2048)
    p.add_argument('--gradient-steps',type=int,default=4)
    p.add_argument('--resume')
    p.add_argument('--exclude-zero',action='store_true',default=True)
    a=p.parse_args()
    if (a.population<2 or a.population%2 or a.generations<1 or
        min(a.fitness_sample,a.validation_sample,a.batch_size,a.gradient_batch,
            a.gradient_steps,a.position_chunk,a.population_chunk)<=0 or
        a.batch_size>a.fitness_sample or not 0<=a.cp_weight<=20 or
        a.gradient_lr<=0 or a.pgpe_stdev<=0):
        p.error('Invalid run settings')
    if Path(a.out).suffix.lower()!='.npy':p.error('Output must be .npy')
    from evotorch import Problem
    from evotorch.decorators import vectorized
    from evotorch.algorithms import PGPE
    import evotorch
    d=device_for(a.device)
    torch.manual_seed(a.seed); rng=np.random.default_rng(a.seed)
    print(f'GRUMPY-PGPE v{VERSION} device={d} torch={torch.__version__} '
          f'evotorch={getattr(evotorch,"__version__","unknown")} genes={PARAMS} '
          f'architecture=GRMP0001-FP32 fixed_material=ON loss=prob_MSE+{a.cp_weight:g}*cp_MSE/2000^2 '
          f'pgpe_ranking=centered analytic_adam=CPU-state/XPU-grad' ,flush=True)
    train,keys,tstats=load_csv(a.train,a.fitness_sample,a.seed,exclude_zero=a.exclude_zero)
    valid,_,vstats=load_csv(a.validation,a.validation_sample,a.seed+1,
                            exclude_zero=a.exclude_zero,exclude_check=False,exclude_capture=False,
                            overlap=keys)
    if tstats['eligible']<a.fitness_sample:raise ValueError(
        f'T79 eligible positions={tstats["eligible"]}; expected={a.fitness_sample}. Increase CSV count.')
    del keys
    pool=to_torch(train,'cpu');validation=to_torch(valid,d)
    del train,valid
    digest=hashlib.sha256(json.dumps({'version':CK_FORMAT,'train':sha256(a.train),
        'validation':sha256(a.validation),'seed':a.seed,'population':a.population,
        'pool':a.fitness_sample,'batch':a.batch_size,'gradient_batch':a.gradient_batch,
        'gradient_steps':a.gradient_steps,'gradient_lr':a.gradient_lr,
        'cp_weight':a.cp_weight,'pgpe_stdev':a.pgpe_stdev,'center_lr':a.center_lr,
        'stdev_lr':a.stdev_lr},sort_keys=True).encode()).hexdigest()
    anchor_indices=torch.as_tensor(np.random.default_rng(a.seed+8191).choice(
        len(pool[-1]),size=min(4096,len(pool[-1])),replace=False),dtype=torch.long)
    def select(indices):
        return tuple(t[indices].to(d) for t in pool)
    anchor=select(anchor_indices)
    current=[anchor]
    search_device=torch.device('cpu') if d.type=='xpu' else d
    @vectorized
    def objective(solutions):
        return fitness_population(solutions,current[0],d,a.position_chunk,
                                  a.population_chunk,a.cp_weight).to(search_device)
    problem=Problem('min',objective,solution_length=PARAMS,initial_bounds=(-0.01,0.01),
                    dtype=torch.float32,device=str(search_device),seed=a.seed)
    # Center represents the neutral correction to the fixed material baseline.
    # Non-degenerate initialization is required: zero factor+output weights
    # would give no analytic gradient through the clipped hidden units.
    initialization=np.zeros(PARAMS,dtype=np.float32)
    init_rng=np.random.default_rng(a.seed+271828)
    initialization[:1536]=init_rng.normal(0,0.1,1536).astype(np.float32)
    initialization[1536:1544]=2.0
    initialization[1544:1672]=init_rng.normal(0,4.0,128).astype(np.float32)
    center=torch.from_numpy(initialization).to(search_device)
    searcher=PGPE(problem,popsize=a.population,center_learning_rate=a.center_lr,
                  stdev_learning_rate=a.stdev_lr,optimizer='adam',
                  center_init=center,stdev_init=a.pgpe_stdev,stdev_min=0.0001,
                  ranking_method='centered')
    out=Path(a.out);out.parent.mkdir(parents=True,exist_ok=True)
    ckpath=out.with_name('best.grumpy-pgpe-v2.latest.pt')
    # Adam parameters and optimizer state MUST remain on CPU for Intel XPU.
    # On the GPU we create a disposable differentiable leaf for each gradient
    # calculation and copy only its 1680-element gradient to CPU. This avoids
    # PyTorch XPU foreach Adam state allocation and preserves exact FP32 math.
    refined=torch.nn.Parameter(center.detach().to('cpu').clone())
    adam=torch.optim.Adam([refined],lr=a.gradient_lr,foreach=False)
    assert refined.device.type == 'cpu'
    assert all(p.device.type == 'cpu' for group in adam.param_groups for p in group['params'])
    best=None;best_anchor=float('inf');start=1
    if a.resume:
        ck=torch.load(a.resume,map_location='cpu',weights_only=False)
        if ck['identity']!=digest or ck['format']!=CK_FORMAT:
            raise ValueError('Incompatible Grumpy PGPE checkpoint')
        from evotorch import SolutionBatch
        searcher._distribution=ck['distribution'];searcher._optimizer=ck['optimizer']
        searcher._first_iter=ck['first_iter']
        solutions=SolutionBatch(problem,popsize=a.population,device=search_device,empty=True)
        solutions.access_values().copy_(ck['population_values'].to(search_device))
        solutions.set_evals(ck['population_evals'].to(search_device).reshape(-1))
        searcher._population=solutions
        refined.data.copy_(ck['refined'].to('cpu'));adam.load_state_dict(ck['adam'])
        if any(torch.is_tensor(v) and v.device.type!='cpu' for state in adam.state.values() for v in state.values()):
            raise RuntimeError('Adam state must be on CPU')
        best=ck['best'].numpy().astype(np.float32);best_anchor=ck['best_anchor']
        rng.bit_generator.state=ck['numpy_rng'];torch.set_rng_state(ck['torch_rng'])
        start=ck['generation']+1
        print(f'Resumed G{start}',flush=True)
    for gen in range(start,a.generations+1):
        indices=torch.as_tensor(rng.choice(len(pool[-1]),size=a.batch_size,replace=False),dtype=torch.long)
        current[0]=select(indices)
        searcher.step()
        # Refine only with T79, using an actual per-parameter derivative and
        # the true (unnormalized-by-rank) mixed loss; no validation leakage.
        grad_indices=torch.as_tensor(rng.choice(len(pool[-1]),size=a.gradient_batch,replace=False),dtype=torch.long)
        gd=select(grad_indices)
        refine_cpu_adam(refined,adam,gd,d,a.cp_weight,a.gradient_steps)
        # Compare the best PGPE sample against the analytic candidate on the
        # same immutable T79 anchor. An improved PGPE candidate seeds the
        # refinement trajectory, preserving interaction between both methods.
        evolving=searcher.status['pop_best'].values.detach().to(d)
        rebasing=fitness_population(torch.stack((evolving,refined.detach().to(d))),
                    anchor,d,a.position_chunk,2,a.cp_weight).detach().cpu().numpy()
        if rebasing[0] < rebasing[1]:
            with torch.no_grad():refined.copy_(evolving.to('cpu'))
            adam.state.clear()
        cand=torch.stack((searcher.status['pop_best'].values.detach().to(d),
                          searcher.status['center'].detach().to(d),refined.detach().to(d)),dim=0)
        aloss=fitness_population(cand,anchor,d,a.position_chunk,3,a.cp_weight).cpu().numpy()
        k=int(np.argmin(aloss))
        if aloss[k]<best_anchor:
            best_anchor=float(aloss[k]);best=cand[k].cpu().numpy().astype(np.float32).copy()
            write_npy_atomic(out,best)
            write_json_atomic(out.with_name(out.stem+'.active.json'),{
                'format':FORMAT,'dtype':'float32','file':out.name,'genes':PARAMS,
                'architecture':'GRMP0001-192x8-dual-8bucket-fp32','hidden_clip':32,
                'fixed_material':list(int(t) for t in __import__('gen_grumpy_pgpe_core').MATERIAL),
                'output_scale':1,'generation':gen,'train_anchor_mixed_loss':best_anchor})
        if best is None:raise RuntimeError('No candidate selected')
        with torch.no_grad():
            pred=forward(torch.from_numpy(best).to(d),validation)
            val=metrics(pred.cpu().numpy(),validation[-1].cpu().numpy())
            val['mixed_loss']=val['mse_probability']+a.cp_weight*val['mse_cp_normalized']
        center_stdev=float(searcher.status['stdev'].detach().mean())
        ck={'format':CK_FORMAT,'version':VERSION,'identity':digest,'generation':gen,
            'best':torch.from_numpy(best),'best_anchor':best_anchor,'distribution':searcher._distribution,
            'optimizer':searcher._optimizer,'first_iter':searcher._first_iter,
            'population_values':searcher.population.access_values(keep_evals=True).detach().cpu(),
            'population_evals':searcher.population.access_evals().detach().cpu(),
            'refined':refined.detach().cpu(),'adam':adam.state_dict(),'numpy_rng':rng.bit_generator.state,
            'torch_rng':torch.get_rng_state(),'validation':val,'train_stats':tstats,'validation_stats':vstats}
        tmp=ckpath.with_name(ckpath.name+'.partial');torch.save(ck,tmp);os.replace(tmp,ckpath)
        summary={'format':CK_FORMAT,'generation':gen,'checkpoint':ckpath.name,
            'best_anchor_mixed_loss':best_anchor,'valid':val,
            'sigma_mean':center_stdev,'train_stats':tstats,'validation_stats':vstats}
        write_json_atomic(out.with_name(f'best.grumpy-pgpe-v2.gen{gen:05d}.json'),summary)
        print(f'GRUMPY-PGPE G{gen:05d} anchor_mixed={best_anchor:.7f} '
              f'val_rmse_cp={val["rmse_cp"]:.2f} val_prob_mse={val["mse_probability"]:.7f} '
              f'val_cp_mse_norm={val["mse_cp_normalized"]:.7f} '
              f'val_pred_std_cp={val["pred_std_cp"]:.2f} '
              f'val_range=[{val["pred_min_cp"]:.1f},{val["pred_max_cp"]:.1f}] '
              f'sigma={center_stdev:.5f} winner={"pgpe" if k<2 else "gradient"}',flush=True)
    print(f'GRUMPY-PGPE complete anchor_mixed={best_anchor:.7f} model={out}',flush=True)


if __name__=='__main__':main()
