# MCTS Rust/Bullet v0.1.1 — corrección backend Metal

Base: bullet_mcts_rust_genesis_v0.1.0.zip, sobre Bullet commit 5d70177680437b7c0ddf958bd4722d95afa78b0c.

`bullet_trainer::run::DefaultDevice` resuelve erróneamente `MockGpu` cuando solo está activada la feature `metal`. El helper `bullet_lib::value::save::save_to_checkpoint` exige `bullet_lib::nn::ExecutionContext` (`Metal` en esa compilación). Se sustituye `DefaultDevice` por `Device::<ExecutionContext>::new(0)`, sin modificar arquitectura, datos, pérdidas ni exportación.

Aplicar en la raíz de `~/github/Bobby/bullet/`, sustituyendo solo `mcts_genesis/mcts_train.rs`. El MON=2 copia esa fuente a `examples/mcts_picoalpha_bullet_train.rs`. Reintentar `./run_genesis_mcts.sh`.

Limitación: no se compiló Rust/Metal en el entorno de preparación.
