#pragma once
// picoSargon v0.2.12 - configuracion local editable (contiene credenciales).
// Modificar este archivo y recompilar con .\build.ps1 -Board pico_w.
// No compartir ni subir a repositorios publicos.
namespace picoSargon { namespace config {
inline constexpr const char* UCI_NAME = "picoSargon v0.2.12";
inline constexpr const char* SSID = "bolSPA_EXT";
inline constexpr const char* PASSWORD = "PERSONAL2025"; // texto claro, por solicitud
inline constexpr unsigned PORT = 6110;
inline constexpr unsigned PLL_SYS = 220; // MHz: 0 conserva frecuencia del SDK; 120..250 intenta cambiarla
inline constexpr unsigned TIMEOUT_MS = 15000; // 0 = sin limite temporal
inline constexpr int DEPTH = 4;               // ply de busqueda principal
inline constexpr int QDEPTH = 2;              // ply de quiescencia
inline constexpr bool DEBUG = true;          // true: esperar USB CDC y emitir telemetria serie
inline constexpr bool UCI = true;            // trace RX/TX UCI sobre USB, independiente de DEBUG
inline constexpr unsigned WIFI_RETRY_MS = 10000; // 10 segundos entre intentos WiFi
inline constexpr bool MDNS_ENABLED = true;    // false: sin codigo mDNS en el firmware
inline constexpr const char* MDNS_HOSTNAME = "picosargon"; // sin .local
inline constexpr const char* MDNS_SERVICE_NAME = "picoSargon UCI";
} }
