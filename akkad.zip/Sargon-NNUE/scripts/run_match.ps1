#*================================================================================================================*
#* Proyecto sargon-nnue
#* Chess player using different Neural Networks as the game evaluation engine
#*
#* A new mind for the old buddy
#* Created as a learning experience
#*
#* By Dr. Pedro E. Colla 2026 (UADER Teoria de la Comunicación / UFASTA Gestión de Redes)
#* License: CC AS BY 4.0
#*================================================================================================================*
#* run_match.ps1
#* Runs chess matches using Sargon-NNUE
#=================================================================================================================*
#.\sargon_match.ps1 --brain ../etc/brains/brains.json `
#     --pairs 1 `
#     --collect `
#     --idA picoSargon --idB manon `
#     --bellman-misses-jsonl "../data/bellman/bellman_audit.jsonl"
.\sargon_match.ps1 --brain ../etc/brains/brains.json `
     --pairs 1 `
     --idA classic --idB manon

