"""Regression: UCI info frames are emitted only once using ℹ️."""
import contextlib
import importlib.util
import io
import pathlib
import queue
import sys
import time
import unittest

PATH = pathlib.Path(__file__).resolve().parents[1] / "src" / "hive.py"
spec = importlib.util.spec_from_file_location("hive_telemetry_v029", PATH)
hive = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = hive
spec.loader.exec_module(hive)

class NoDuplicateInfo(unittest.TestCase):
    def test_info_once(self):
        engine = object.__new__(hive.Transport)
        engine.name = "stockfish"
        engine.q = queue.Queue()
        engine.q.put("info depth 9 score cp 40 pv e2e4")
        stderr = io.StringIO()
        with contextlib.redirect_stderr(stderr):
            result = engine.recv(time.monotonic() + 2)
        self.assertEqual(result, "info depth 9 score cp 40 pv e2e4")
        rows = stderr.getvalue().splitlines()
        self.assertEqual(len(rows), 1, rows)
        self.assertTrue(rows[0].startswith("ℹ️["), rows)
        self.assertNotIn("📮", rows[0])

    def test_generic_info_is_suppressed(self):
        line = "info depth 0 multipv 1 score cp -782 nodes 1201 time 1707 nps 703 pv c4d3 string ALPHAZERO root_visits=246 root_source=mcts simulations=1200"
        stderr = io.StringIO()
        with contextlib.redirect_stderr(stderr):
            hive.telemetry('📮', 'alphazero', line)
            hive.telemetry('ℹ️', 'alphazero', line)
            hive.telemetry('ℹ️', 'alphazero', line)
        rows = stderr.getvalue().splitlines()
        self.assertEqual(len(rows), 2)
        self.assertTrue(all(row.startswith('ℹ️[') for row in rows))

    def test_info_whitespace(self):
        for line in ('info', 'info\tdepth 9', 'info depth 9'):
            engine = object.__new__(hive.Transport)
            engine.name = 'alphazero'
            engine.q = queue.Queue()
            engine.q.put(line)
            stderr = io.StringIO()
            with contextlib.redirect_stderr(stderr):
                self.assertEqual(engine.recv(time.monotonic() + 2), line)
            self.assertEqual(len(stderr.getvalue().splitlines()), 1)
            self.assertTrue(stderr.getvalue().startswith('ℹ️['))

    def test_regular_reply_preserves_marker(self):
        engine = object.__new__(hive.Transport)
        engine.name = "stockfish"
        engine.q = queue.Queue()
        engine.q.put("readyok")
        stderr = io.StringIO()
        with contextlib.redirect_stderr(stderr):
            self.assertEqual(engine.recv(time.monotonic() + 2), "readyok")
        self.assertEqual(stderr.getvalue().count("📮["), 1)
        self.assertNotIn("ℹ️", stderr.getvalue())

if __name__ == "__main__":
    unittest.main()
