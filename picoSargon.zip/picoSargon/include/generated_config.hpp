// GENERATED: DO NOT COMMIT. Created with tools/generate_config.py
#pragma once
namespace picoSargon { namespace config {
inline constexpr const char* SSID = "bolSPA_EXT";
inline constexpr const char* PASSWORD = "PERSONAL2025";
inline constexpr unsigned PORT = 6110;
inline constexpr unsigned TIMEOUT_MS = 15000;
inline constexpr int PLIES = 4;
} }
