# picoSargon x86 - build v0.2.24
# Ambos interruptores activados por defecto; se pueden desactivar explicitamente.
param(
    [string]$Python = "python",
    [string]$CMake = "cmake",
    [bool]$steroids = $true,
    [bool]$twins = $true
)
$ErrorActionPreference = 'Stop'
& $Python (Join-Path $PSScriptRoot 'build_host.py') --cmake $CMake --steroids $steroids.ToString().ToLowerInvariant() --twins $twins.ToString().ToLowerInvariant()
if ($LASTEXITCODE -ne 0) { throw 'Error compilando picoSargon x86' }
Write-Host (Join-Path $PSScriptRoot 'build\picoSargon.exe')
