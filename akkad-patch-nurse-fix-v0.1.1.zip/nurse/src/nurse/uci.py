"""Nurse orchestrator: one UCI frontend; three persistent backend types."""
import argparse,sys,threading,time,json,shlex,os
from pathlib import Path
from . import __version__
from .config import read_brain,read_brains
from .transport import Transport,TransportError
from .telemetry import log

class Nurse:
    def __init__(self,brains,ident,out=None):
        self.brains=Path(brains).resolve();self.ident=ident
        self.cfg=read_brain(self.brains,ident)
        self.out=out if out is not None else sys.stdout
        self._outlock=threading.Lock();self._state_lock=threading.RLock()
        self.transport=None;self.position='position startpos';self.search=None
        self.started=False;self.closed=False;self.options={}
        self.timeout=max(1,int(self.cfg.get('timeout',15000)))/1000
        self.retry=float(self.cfg.get('retry',5))
        self.next_retry=0.0
        log(f'💻 sargon-nurse v{__version__} brain={ident} type={self.cfg["_type"]} ELO={self.cfg.get("ELO","n/a")} timeout_ms={self.cfg.get("timeout",15000)}')
        if self.cfg['_type']=='nurse':
            log(f'⚙️ player={self.cfg["_player"]} evaluator={self.cfg["_evaluator"]} network={self.cfg.get("_network")} depth={self.cfg.get("Depth",2)} qdepth={self.cfg.get("QDepth",0)} arguments={self.cfg.get("arguments",{})}')
        elif self.cfg['_type']=='uci':log(f'⚙️ UCI engine={self.cfg["_engine"]} args={self.cfg.get("args",[])}')
        else:log(f'⚙️ TCP endpoint={self.cfg["ipaddress"]}:{self.cfg["port"]} retry_seconds={self.cfg.get("retry",5)}')
    def emit(self,line):
        with self._outlock:print(line,file=self.out,flush=True)
    def _ensure(self):
        if self.transport is not None:return
        typ=self.cfg['_type']
        if typ=='external' and time.monotonic()<self.next_retry:
            raise TransportError(f'TCP desconectado; próximo reintento en {self.next_retry-time.monotonic():.1f}s')
        t=Transport()
        try:
            if typ=='nurse':
                mod=self.cfg['_player'].replace('-','_')
                t.process([sys.executable,'-u','-m','nurse.players.'+mod,'--serve','--config',json.dumps(self.cfg)])
                t.send(json.dumps({'cmd':'ready'}))
                reply=json.loads(t.recv(min(30,self.timeout)))
                if not reply.get('ready'):raise TransportError('worker no listo')
            elif typ=='uci':
                exe=self.cfg['_engine'];args=self.cfg.get('args',[])
                t.process([exe]+args,cwd=str(Path(exe).parent) if Path(exe).is_absolute() else None)
                t.handshake(max(30,self.timeout))
            else:
                t.tcp(self.cfg['ipaddress'],self.cfg['port'],timeout=min(10,self.timeout))
                t.handshake(max(30,self.timeout))
            self.transport=t;self.started=True
        except BaseException:
            t.close()
            if typ=='external':self.next_retry=time.monotonic()+self.retry
            raise
    def _position_fen(self):
        import chess
        tokens=shlex.split(self.position)
        if len(tokens)<2:raise ValueError('position incompleta')
        if tokens[1]=='startpos':board=chess.Board();idx=2
        elif tokens[1]=='fen':
            if len(tokens)<8:raise ValueError('FEN incompleto')
            board=chess.Board(' '.join(tokens[2:8]));idx=8
        else:raise ValueError('position inválida')
        if idx<len(tokens) and tokens[idx]=='moves':
            for uci in tokens[idx+1:]:board.push_uci(uci)
        return board.fen()
    def _emit_error(self,exc,search=False):
        log(f'❌ brain={self.ident} {type(exc).__name__}: {exc}')
        self.emit('info string nurse error '+str(exc).replace('\n',' ')[:180])
        if search:self.emit('bestmove 0000')
    def _search_worker(self,go):
        try:
            self._ensure()
            typ=self.cfg['_type']
            if typ=='nurse':
                self.transport.send(json.dumps({'cmd':'choose','fen':self._position_fen(),'go':go}))
                reply=json.loads(self.transport.recv(max(3,self.timeout+5)))
                if not reply.get('ok'):raise TransportError(reply.get('error','worker error'))
                # Legacy evaluators return White-perspective cp; UCI requires side-to-move.
                cp=reply['score_cp'] if reply.get('turn_white') else -reply['score_cp']
                info='info depth {depth} nodes {nodes} time {time} nps {nps} score cp '.format(**reply)+str(cp)
                self.emit(info);self.emit('bestmove '+reply['bestmove'])
            else:
                self.transport.send(self.position)
                # A bare "go" would leave Stockfish searching indefinitely.
                tokens=go.split()
                bounded=go
                if not any(key in tokens for key in ('movetime','depth','nodes','wtime','btime','infinite','mate')):
                    bounded='go movetime '+str(max(1,int(self.cfg.get('timeout',15000))))
                self.transport.send(bounded)
                parts=bounded.split()
                go_ms=None
                for key in ('movetime',):
                    if key in parts:
                        pos=parts.index(key)
                        if pos+1<len(parts):go_ms=int(parts[pos+1])
                # The supervisor must honor a long Bratko-Kopec movetime.
                search_timeout=max(self.timeout+10,30,(go_ms/1000+15) if go_ms else 0)
                deadline=time.monotonic()+search_timeout
                while True:
                    line=self.transport.recv(max(.01,deadline-time.monotonic()))
                    if line.startswith('info ') or line.startswith('bestmove '):self.emit(line)
                    if line.startswith('bestmove '):break
        except (TransportError,TimeoutError,ValueError,OSError,json.JSONDecodeError) as exc:
            self._emit_error(exc,search=True)
            self._drop_transport()
        finally:
            with self._state_lock:self.search=None
    def _drop_transport(self):
        t=self.transport;self.transport=None
        if t:
            t.close()
            if self.cfg['_type']=='external':
                self.next_retry=time.monotonic()+self.retry
                log(f'🔄 TCP próxima reconexión en {self.retry:g}s')
    def _reconnect_loop(self):
        while not self.closed:
            if self.started and self.transport is None and self.cfg['_type']=='external':
                if time.monotonic()>=self.next_retry:
                    try:
                        self._ensure()
                        log('✅ TCP reconectado; enviar nueva posición antes de buscar')
                    except (TransportError,TimeoutError,OSError) as exc:
                        log(f'🔄 TCP reintento fallido: {exc}')
            time.sleep(.2)
    def dispatch(self,line):
        if not line:return True
        cmd=line.split(None,1)[0].lower()
        if cmd=='uci':
            self.emit(f'id name Sargon Nurse {self.ident} v{__version__}')
            self.emit('id author Akkad')
            self.emit('uciok')
        elif cmd=='isready':
            try:self._ensure();self.emit('readyok')
            except Exception as e:self._emit_error(e)
        elif cmd=='ucinewgame':
            self.position='position startpos'
            if self.transport and self.cfg['_type']!='nurse':
                try:self.transport.send('ucinewgame')
                except TransportError:self._drop_transport()
        elif cmd=='position':self.position=line
        elif cmd=='setoption':
            # Forward options only to UCI backends, preserve original spelling.
            if self.transport and self.cfg['_type']!='nurse':self.transport.send(line)
        elif cmd=='go':
            with self._state_lock:
                if self.search and self.search.is_alive():
                    self.emit('info string nurse busy: search in progress')
                    return True
                self.search=threading.Thread(target=self._search_worker,args=(line,),daemon=True)
                self.search.start()
        elif cmd=='stop':
            if self.transport and self.cfg['_type']!='nurse':
                try:self.transport.send('stop')
                except TransportError:self._drop_transport()
            else:log('⚠️ stop de player Python no es preemptivo; espera búsqueda en curso')
        elif cmd=='ponderhit':
            if self.transport and self.cfg['_type']!='nurse':self.transport.send('ponderhit')
        elif cmd=='quit':return False
        else:self.emit('info string nurse comando desconocido '+cmd)
        return True
    def run(self,input_stream=None):
        if self.cfg['_type']=='external':
            threading.Thread(target=self._reconnect_loop,daemon=True).start()
        try:
            for line in input_stream if input_stream is not None else sys.stdin:
                if not self.dispatch(line.strip()):break
        finally:
            self.closed=True
            if self.search and self.search.is_alive():
                if self.transport and self.cfg['_type']!='nurse':
                    try:self.transport.send('stop')
                    except TransportError:pass
                self.search.join(timeout=3)
            self._drop_transport()
        return 0

def main(argv=None):
    ap=argparse.ArgumentParser(description='Sargon Nurse independent UCI engine')
    ap.add_argument('--brains',required=True,help='brains.json configuration')
    ap.add_argument('--id',required=True,help='brain identifier')
    ap.add_argument('--depth',type=int,help='override Depth')
    ap.add_argument('--qdepth',type=int,help='override QDepth')
    ap.add_argument('--timeout',type=int,help='override timeout in milliseconds')
    ap.add_argument('--cp',type=int,help='forward cp parameter')
    ap.add_argument('--arg',action='append',default=[],metavar='KEY=VALUE',help='forward arbitrary player argument')
    a=ap.parse_args(argv)
    try:
        nurse=Nurse(a.brains,a.id)
        if nurse.cfg['_type']=='nurse':
            for attr,key in [('depth','Depth'),('qdepth','QDepth'),('timeout','timeout')]:
                value=getattr(a,attr)
                if value is not None:nurse.cfg[key]=value
            user=dict(nurse.cfg.get('arguments',{}))
            if a.cp is not None:user['cp']=a.cp
            for token in a.arg:
                if '=' not in token:raise ValueError('--arg exige KEY=VALUE')
                k,v=token.split('=',1);user[k]=v
            nurse.cfg['arguments']=user
        if a.timeout is not None:nurse.timeout=max(1,a.timeout)/1000
        return nurse.run()
    except KeyboardInterrupt:
        log('🛑 Interrupción del usuario (Ctrl+C): Nurse finalizando voluntariamente')
        return 130
    except Exception as exc:
        log(f'❌ fatal: {exc}')
        return 2
if __name__=='__main__':raise SystemExit(main())
