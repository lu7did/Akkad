"""CSV adapter for *unchanged* archived genetic NNUE algorithm.

Reuses archive/genNNUE.py train/breed and archive/gen_nnue_core.py 768x16.
No PyTorch, Bullet, or SQLite in the executed data path.
"""
import argparse
import sys
from pathlib import Path
from gen_csv_dataset import load_pair

ARCHIVE=Path(__file__).resolve().parent/'archive'
if not (ARCHIVE/'genNNUE.py').is_file():
    raise SystemExit('Missing archive/genNNUE.py: preserve the original genetic trainer in archive/')
sys.path.insert(0,str(ARCHIVE))
import genNNUE as original  # noqa: E402


def main():
    p=argparse.ArgumentParser(description='Original picoGen 768x16 genetic NNUE, T79/T77 CSV')
    p.add_argument('--train',required=True);p.add_argument('--validation',required=True)
    p.add_argument('--out',required=True);p.add_argument('--population',type=int,default=30)
    p.add_argument('--generations',type=int,default=20);p.add_argument('--seed',type=int,default=42)
    p.add_argument('--fitness-sample',type=int,default=10000)
    p.add_argument('--validation-sample',type=int,default=1000)
    p.add_argument('--resume')
    a=p.parse_args()
    if a.population<5 or a.generations<1 or not a.out.lower().endswith('.npy'):
        p.error('population>=5, generations>=1, out must be .npy')
    train,val,digest,_=load_pair(a.train,a.validation,a.fitness_sample,a.validation_sample,a.seed)
    # The archived prepare() expects a loader returning the original 6-field row tuple.
    original.load_split=lambda _source,_seed,_max_positions,_validation_sample:(train,val,digest)
    datasets,model_digest=original.prepare('T79/T77 CSV',a.seed,0,20.0)
    Path(a.out).parent.mkdir(parents=True,exist_ok=True)
    mse=original.train(datasets,model_digest,a.out,a.population,a.generations,a.seed,20.0,a.resume)
    print(f'NNUE complete best_train_rmse_cp={mse**.5:.3f} model={a.out}',flush=True)
if __name__=='__main__':main()
