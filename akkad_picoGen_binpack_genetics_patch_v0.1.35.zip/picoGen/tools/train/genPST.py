"""CSV adapter for *unchanged* archived genetic PST algorithm.

Reuses archive/genPST.py initial/offspring/train and archive/gen_sargon_core.py.
Does not import or execute any SQLite loader.
"""
import argparse
import sys
from pathlib import Path
from gen_csv_dataset import load_pair

ARCHIVE=Path(__file__).resolve().parent/'archive'
if not (ARCHIVE/'genPST.py').is_file():
    raise SystemExit('Missing archive/genPST.py: preserve the original genetic trainer in archive/')
sys.path.insert(0,str(ARCHIVE))
import genPST as original  # noqa: E402  - explicit selected archived genetic implementation

def main():
    p=argparse.ArgumentParser(description='Original picoGen PST genetic operators, binpack CSV labels, T77 validation')
    p.add_argument('--train',required=True);p.add_argument('--validation',required=True)
    p.add_argument('--out',required=True);p.add_argument('--population',type=int,default=30)
    p.add_argument('--generations',type=int,default=20);p.add_argument('--seed',type=int,default=42)
    p.add_argument('--fitness-sample',type=int,default=10000)
    p.add_argument('--validation-sample',type=int,default=1000)
    p.add_argument('--resume')
    a=p.parse_args()
    if a.population<2 or a.generations<1: p.error('population>=2 and generations>=1')
    train,val,digest,_=load_pair(a.train,a.validation,a.fitness_sample,a.validation_sample,a.seed)
    source=[(r[2],r[3],r[4]) for r in train]
    validation=[(r[2],r[3],r[4]) for r in val]
    Path(a.out).parent.mkdir(parents=True,exist_ok=True)
    mse=original.train(source,a.out,a.population,a.generations,a.seed,a.resume,validation,digest)
    print(f'PST complete best_train_rmse_cp={mse**.5:.3f} model={a.out}',flush=True)
if __name__=='__main__':main()
