"""Evolve a small 768x16x1 value-only integer NNUE against Stockfish-labeled positions."""
import argparse
import os
from gen_progress import TrainingProgress
from gen_checkpoints import npy_atomic, json_atomic, generation_path, best_path
import numpy as np
from gen_common import atomic_path, load_labeled, open_source, require_chess, target_cp, validate_board
from gen_nnue_core import PARAMS, padded_features, forward, random_genome, mutate


def training_data(rows):
    chess=require_chess()
    boards=[];targets=[];ignored=0
    progress=TrainingProgress("NNUE prep",len(rows))
    progress.update(0,force=True)
    for row_index,(_,fen,_,cp,mate,value) in enumerate(rows,1):
        progress.update(row_index)
        board=validate_board(fen,chess)
        if board is None:
            ignored+=1;continue
        score=target_cp((cp,mate,value),board.turn)
        if score is None:
            ignored+=1;continue
        boards.append(board);targets.append(score)
    progress.finish()
    if not boards:
        raise ValueError('No hay posiciones FEN con score válido')
    x,m=padded_features(boards)
    print(f'🧬 NNUE positions={len(boards)} genes={PARAMS} ignored={ignored}',flush=True)
    return x,m,np.asarray(targets,dtype=np.float64)


def evolve(dataset,population=100,generations=500,seed=42,on_progress=None,
           on_best=None,on_generation=None):
    # All genetic operators and fitness (MSE) are unchanged.
    rng=np.random.default_rng(seed)
    x,mask,target=dataset
    pop=[random_genome(rng) for _ in range(population)]
    best_genes=None;best_mse=float('inf')
    count=len(target)
    progress=TrainingProgress('NNUE train',count,population,generations)
    progress.update(0,force=True)
    try:
        for gen in range(generations):
            errors=[]
            progress.reset_errors()
            for individual,genes in enumerate(pop):
                mse_i=float(np.mean((forward(genes,x,mask)-target)**2))
                errors.append(mse_i)
                progress.set_errors(float(np.sqrt(np.min(errors))),
                                    float(np.sqrt(errors).mean()))
                progress.update((gen*population+individual+1)*count,auto_end=False)
                if mse_i<best_mse:
                    best_mse=mse_i
                    best_genes=genes.copy()
                    if on_best is not None:
                        on_best(best_genes,best_mse,gen+1)
            mse=np.asarray(errors)
            order=np.argsort(mse)
            progress.set_errors(float(np.sqrt(mse.min())),float(np.sqrt(mse).mean()))
            progress.finish_generation((gen+1)*population*count)
            if on_generation is not None:
                on_generation(gen+1,pop[int(order[0])].copy(),
                              {'generation':gen+1,'rmse_min_cp':float(np.sqrt(mse.min())),
                               'rmse_mean_cp':float(np.sqrt(mse).mean()),
                               'mse_min':float(mse.min()),'population':population,
                               'positions':count,'generations':generations,'seed':seed,
                               'format':'picogenus-nnue-768-16-1-int8'})
            if on_progress is not None:
                hits=np.sum(np.abs(forward(pop[int(order[0])],x,mask)-target)<=100.)
                on_progress(f'Generation {gen+1}/{generations} population={population} '
                            f'correct_100cp={int(hits)}/{count} '
                            f'error_min={np.sqrt(mse.min()):.2f}cp '
                            f'error_mean={np.sqrt(mse).mean():.2f}cp')
            if gen==generations-1:break
            elite=min(4,population)
            next_pop=[pop[int(i)].copy() for i in order[:elite]]
            pool=order[:max(2,min(population,20))]
            while len(next_pop)<population:
                p1,p2=rng.choice(pool,size=2)
                mask_crossover=rng.random(PARAMS)<.5
                child=np.where(mask_crossover,pop[int(p1)],pop[int(p2)]).astype(np.int8)
                next_pop.append(mutate(child,rng)[()])
            pop=next_pop
    except KeyboardInterrupt:
        progress.abort()
        raise
    progress.finish()
    return best_genes,best_mse


def main():
    p=argparse.ArgumentParser(description='NNUE valor 768x16x1 por evolución genética (.npy INT8)')
    p.add_argument('--in',dest='source',required=True)
    p.add_argument('--out',required=True)
    p.add_argument('--población','--poblacion',type=int,default=100,dest='population')
    p.add_argument('--generaciones',type=int,default=500)
    p.add_argument('--seed',type=int,default=42)
    p.add_argument('--max-positions',type=int,default=0,help='0 = TODAS, N = reservorio aleatorio')
    a=p.parse_args()
    if a.population<2 or a.generaciones<1 or a.max_positions<0:
        p.error('población >=2, generaciones >=1, max-positions >=0')
    if not a.out.lower().endswith('.npy'):
        p.error('--out debe terminar en .npy')
    try:
        with open_source(a.source) as db:
            rows=load_labeled(db,seed=a.seed,max_rows=a.max_positions)
        dataset=training_data(rows)
        # Main output always remains a valid best model, even under Ctrl+C.
        def save_best(genes,mse,generation):
            npy_atomic(a.out,genes)
            npy_atomic(best_path(a.out),genes)
            json_atomic(str(best_path(a.out)).removesuffix('.npy')+'.json',
                        {'generation':generation,'rmse_cp':float(np.sqrt(mse)),
                         'mse':float(mse),'positions':len(dataset[2])},
                        auxiliary=True)
        def save_generation(number,genes,stats):
            npy_atomic(generation_path(a.out,number),genes)
            json_atomic(str(generation_path(a.out,number)).removesuffix('.npy')+'.json',stats)
        best,mse=evolve(dataset,a.population,a.generaciones,a.seed,
                        on_best=save_best,on_generation=save_generation)
        print(f'✅ NNUE output={a.out} genes={len(best)} dtype={best.dtype} rmse={mse**.5:.2f}cp')
    except KeyboardInterrupt:
        print('\nNNUE interrupted with Ctrl+C; best network and completed generations remain on disk.',flush=True)
        raise SystemExit(130)
    except (ValueError,OSError) as e:p.error(str(e))

if __name__=='__main__': main()
