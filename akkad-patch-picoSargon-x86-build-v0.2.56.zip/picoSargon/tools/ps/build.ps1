﻿# picoSargon Windows x86 build v0.2.56
# Invoke from anywhere: .\picoSargon\tools\ps\build.ps1
# No param() deliberately: accept GNU-style --options reliably in Windows PowerShell 5.1.
$ErrorActionPreference = 'Stop'
$Version = '0.2.56'
$Steroids = 'ON'
$Multicore = 'ON'
$AllowInstall = $true
$Clean = $false
$Jobs = [Math]::Max(1, [Environment]::ProcessorCount)

function Show-Help {
@'
picoSargon x86 Windows build v0.2.56
Uso: .\picoSargon\tools\ps\build.ps1 [opciones]

  --help, -help             Muestra esta ayuda y termina.
  --steroids ON|OFF         Optimizaciones STEROIDS (por defecto ON).
  --multicore ON|OFF        Busqueda multinucleo (por defecto ON).
  --jobs N                  Compilaciones simultaneas (por defecto: CPUs).
  --clean                   Elimina x86/build antes de compilar.
  --no-install              No instalar dependencias; informar las faltantes.

Dependencias: CMake >= 3.16 y MSVC C++17 con SDK Windows (Visual Studio
2022 o Build Tools). Cuando faltan, se intenta instalar con winget.
Salida: picoSargon/x86/build/picoSargon.exe
TWINS es exclusivo de ARM: no es una opcion para x86.
'@ | Write-Host
}
function Fail([string]$Message) { throw "picoSargon build: $Message" }
function Value-After([int]$Index, [string]$Option) {
    if ($Index + 1 -ge $argsList.Length -or $argsList[$Index+1].StartsWith('-')) { Fail "falta valor para $Option" }
    return $argsList[$Index+1]
}
$argsList = @($args)
for ($i=0; $i -lt $argsList.Length; $i++) {
    $a = [string]$argsList[$i]
    switch -Regex ($a.ToLowerInvariant()) {
        '^(-h|--help|-help)$' { Show-Help; return }
        '^(--steroids|-steroids)$' {
            $Steroids = (Value-After $i $a).ToUpperInvariant()
            if ($Steroids -notin @('ON','OFF')) { Fail "$a: usar ON u OFF" }
            $i++; break
        }
        '^(--multicore|-multicore)$' {
            $Multicore = (Value-After $i $a).ToUpperInvariant()
            if ($Multicore -notin @('ON','OFF')) { Fail "$a: usar ON u OFF" }
            $i++; break
        }
        '^(--jobs|-jobs)$' {
            $v = Value-After $i $a
            $n = 0
            if (-not [int]::TryParse($v,[ref]$n) -or $n -lt 1) { Fail "$a: se requiere entero positivo" }
            $Jobs = $n; $i++; break
        }
        '^(--clean|-clean)$' { $Clean=$true; break }
        '^(--no-install|-no-install)$' { $AllowInstall=$false; break }
        default { Fail "opcion desconocida: $a (usar --help)" }
    }
}
if ($env:OS -ne 'Windows_NT') { Fail 'este script es exclusivamente para Windows x86/x64' }
$project = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$source = Join-Path $project 'x86'
$build = Join-Path $source 'build'
if (-not (Test-Path (Join-Path $source 'CMakeLists.txt'))) { Fail "no existe $source\CMakeLists.txt" }

function Find-CMake {
    $cmd = Get-Command cmake.exe -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    $p = @(
        (Join-Path ${env:ProgramFiles} 'CMake\bin\cmake.exe'),
        (Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe')
    )
    if (Test-Path $p[0]) { return $p[0] }
    return $null
}
function Find-VS {
    $pf86 = [Environment]::GetFolderPath('ProgramFilesX86')
    $vswhere = Join-Path $pf86 'Microsoft Visual Studio\Installer\vswhere.exe'
    if (Test-Path $vswhere) {
        $raw = @(& $vswhere -products '*' -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -format json 2>$null)
        if ($LASTEXITCODE -eq 0 -and $raw) {
            try {
                $inst = @((($raw -join "`n") | ConvertFrom-Json))
                foreach ($x in $inst) {
                    $ver = [string]$x.installationVersion
                    $p = [string]$x.installationPath
                    if ($ver.StartsWith('17.') -and (Test-Path (Join-Path $p 'VC\Tools\MSVC'))) {
                        return @{ Path=$p; Generator='Visual Studio 17 2022' }
                    }
                }
            } catch { }
        }
    }
    foreach ($edition in @('BuildTools','Community','Professional','Enterprise')) {
        $base = Join-Path ${env:ProgramFiles} "Microsoft Visual Studio\2022\$edition"
        if ((Test-Path (Join-Path $base 'VC\Tools\MSVC')) -and
            (Test-Path (Join-Path $base 'MSBuild\Current\Bin\MSBuild.exe'))) {
            return @{Path=$base; Generator='Visual Studio 17 2022'}
        }
    }
    return $null
}
function Install-Winget([string]$Id, [string[]]$Extra) {
    if (-not $AllowInstall) { Fail "falta $Id y se indico --no-install" }
    $wg = Get-Command winget.exe -ErrorAction SilentlyContinue
    if (-not $wg) { Fail "falta $Id y winget no esta instalado. Instalar App Installer y volver a ejecutar" }
    Write-Host "[DEPENDENCIA] Instalando $Id mediante winget..."
    $arguments = @('install','--id',$Id,'--exact','--source','winget',
        '--accept-source-agreements','--accept-package-agreements','--disable-interactivity') + $Extra
    & $wg.Source @arguments
    if ($LASTEXITCODE -ne 0) { Fail "winget no pudo instalar $Id (exit=$LASTEXITCODE). Comprobar permisos y conectividad" }
}

Write-Host "[BUILD] picoSargon x86 v$Version STEROIDS=$Steroids MULTICORE=$Multicore jobs=$Jobs"
$cmake = Find-CMake
if (-not $cmake) {
    Install-Winget 'Kitware.CMake' @()
    $cmake = Find-CMake
    if (-not $cmake) { Fail 'CMake instalado pero no localizable; abrir nueva terminal o verificar PATH' }
}
$cmakeVersion = & $cmake --version | Select-Object -First 1
Write-Host "[OK] $cmakeVersion ($cmake)"
$vs = Find-VS
if (-not $vs) {
    Install-Winget 'Microsoft.VisualStudio.2022.BuildTools' @('--override',
        '--quiet --wait --norestart --add Microsoft.VisualStudio.Workload.VCTools --includeRecommended')
    $vs = Find-VS
    if (-not $vs) { Fail 'Build Tools instalado pero no se detecta toolchain C++/SDK; revisar instalador de Visual Studio y componentes C++' }
}
Write-Host "[OK] MSVC: $($vs.Path)"
if ($Clean -and (Test-Path $build)) {
    Write-Host "[CLEAN] $build"
    Remove-Item -LiteralPath $build -Recurse -Force
}
# A new build directory / generator change must not reuse an incompatible CMakeCache.
$cache = Join-Path $build 'CMakeCache.txt'
if (Test-Path $cache) {
    $oldGenerator = Select-String -LiteralPath $cache -Pattern '^CMAKE_GENERATOR:INTERNAL=' | Select-Object -First 1
    if ($oldGenerator -and $oldGenerator.Line.Split('=')[-1] -ne $vs.Generator) {
        Fail "el build existente usa otro generador; ejecutar con --clean para regenerarlo"
    }
}
Write-Host "[CMAKE] Configurando $source"
& $cmake -S $source -B $build -G $vs.Generator -A x64 -D "STEROIDS=$Steroids" -D "MULTICORE=$Multicore"
if ($LASTEXITCODE -ne 0) { Fail "fallo la configuracion CMake (exit=$LASTEXITCODE)" }
Write-Host '[CMAKE] Compilando Release...'
& $cmake --build $build --config Release --parallel $Jobs
if ($LASTEXITCODE -ne 0) { Fail "fallo la compilacion (exit=$LASTEXITCODE)" }
$exe = Join-Path $build 'picoSargon.exe'
if (-not (Test-Path -LiteralPath $exe -PathType Leaf)) {
    Fail "compilacion finalizada pero no existe $exe"
}
Write-Host "[OK] Ejecutable: $exe"
Write-Host "[OK] STEROIDS=$Steroids MULTICORE=$Multicore"
