"""Evolución PST reproduciendo el ejemplo entrenar_david_ga.py, con datos .pb.

Fitness exacto: (cantidad de movimientos coincidentes con teacher_uci)**2.
No se emplean centipeones de Stockfish para ponderar aptitud.
"""
import argparse
import json
import os
from gen_progress import TrainingProgress
from gen_checkpoints import json_atomic, generation_path, best_path

import numpy as np
from gen_common import atomic_path, load_labeled, open_source, require_chess, validate_board
from gen_pst_core import (BITS,NAMES,decode,PARAM_SPECS,
                          decodificar_cromosoma,elegir_jugada_1ply)


def build_dataset(rows):
    chess=require_chess()
    dataset=[]
    ignored=0
    progress = TrainingProgress("PST prep", len(rows))
    progress.update(0, force=True)
    for row_index, (_,fen,teacher,cp,mate,value) in enumerate(rows, 1):
        progress.update(row_index)
        board=validate_board(fen,chess)
        if board is None or not teacher:
            ignored+=1;continue
        try:move=chess.Move.from_uci(teacher)
        except ValueError:
            ignored+=1;continue
        if move not in board.legal_moves:
            ignored+=1;continue
        dataset.append((board,move))
    progress.finish()
    if not dataset:
        raise ValueError('No hay posiciones válidas con jugadas de Stockfish')
    print(f'🧬 PST positions={len(dataset)} ignored={ignored}',flush=True)
    return dataset


def evaluate_fitness(chromosome,dataset,progress=None,offset=0):
    params=decodificar_cromosoma(chromosome)
    hits=0
    for position_index,(board,teacher) in enumerate(dataset,1):
        hits += (elegir_jugada_1ply(board,params)==teacher)
        if progress is not None and (position_index % 64 == 0 or position_index==len(dataset)):
            progress.update(offset+position_index,auto_end=False)
    return hits**2,hits


def _result(chrom, hits, dataset_size, population, generations, seed, generation):
    values=decodificar_cromosoma(chrom)
    return {'format':'picogenus-pst-v1','encoding':'gray-224','pawn_value':100,
            'parameters':{key:int(values[key]) for key in NAMES},
            'chromosome_bits':''.join(map(str,chrom.tolist())),
            'fitness':int(hits)**2,'correct':int(hits),'positions':dataset_size,
            'population':population,'generations':generations,'seed':seed,
            'generation':generation, 'version':'0.1.3',
            'reference':'entrenar_david_ga.py'}


def evolve(dataset,population=100,generations=500,seed=42,on_progress=None,
           on_best=None,on_generation=None):
    # Genetic operators and fitness are preserved from entrenar_david_ga.py.
    rng=np.random.RandomState(seed)
    pop=rng.randint(0,2,size=(population,BITS)).astype(np.uint8)
    best_chrom=None
    best_hits=-1
    count=len(dataset)
    progress=TrainingProgress('PST train', count, population, generations)
    progress.update(0,force=True)
    try:
        for gen in range(generations):
            results=[]
            current_hits=[]
            progress.reset_errors()
            for i,chrom in enumerate(pop):
                fitness_i,hits_i=evaluate_fitness(chrom,dataset,progress,
                                                  (gen*population+i)*count)
                results.append((fitness_i,hits_i))
                current_hits.append(int(hits_i))
                errors=count-np.asarray(current_hits,dtype=np.int64)
                progress.set_errors(int(errors.min()),float(errors.mean()))
                progress.update((gen*population+i+1)*count,auto_end=False)
                if hits_i>best_hits:
                    best_hits=int(hits_i)
                    best_chrom=chrom.copy()
                    if on_best is not None:
                        on_best(_result(best_chrom,best_hits,count,population,
                                        generations,seed,gen+1))
            fitness=np.asarray([t[0] for t in results],dtype=np.float64)
            hits=np.asarray([t[1] for t in results],dtype=np.int64)
            best=int(np.argmax(fitness))
            errors=count-hits
            progress.set_errors(int(errors.min()),float(errors.mean()))
            progress.finish_generation((gen+1)*population*count)
            if on_generation is not None:
                snapshot=_result(pop[best],hits[best],count,population,generations,seed,gen+1)
                snapshot['error_min']=int(errors.min())
                snapshot['error_mean']=float(errors.mean())
                on_generation(gen+1,snapshot)
            if on_progress is not None:
                on_progress(f'Generation {gen+1}/{generations} participants={population} '
                            f'correct={int(hits[best])}/{count} '
                            f'error_min={int(errors.min())} error_mean={float(errors.mean()):.2f}')
            if gen==generations-1:break
            next_pop=[pop[best].copy()]
            total=fitness.sum()
            probabilities=fitness/total if total>0 else np.ones(population)/population
            while len(next_pop)<population:
                p1,p2=rng.choice(population,size=2,p=probabilities)
                father,mother=pop[p1],pop[p2]
                if rng.rand()<.75:
                    child=np.where(rng.rand(BITS)<.5,father,mother).astype(np.uint8)
                else:child=father.copy()
                mutations=rng.rand(BITS)<.005
                child=np.bitwise_xor(child,mutations.astype(np.uint8))
                next_pop.append(child)
            pop=np.asarray(next_pop,dtype=np.uint8)
    except KeyboardInterrupt:
        progress.abort()
        raise
    progress.finish()
    return _result(best_chrom,best_hits,count,population,generations,seed,generations)


def main():
    parser=argparse.ArgumentParser(description='Evolución PST literal del ejemplo, sobre datos Stockfish .pb')
    parser.add_argument('--in',dest='source',required=True)
    parser.add_argument('--out',required=True)
    parser.add_argument('--población','--poblacion',type=int,default=100,dest='population')
    parser.add_argument('--generaciones',type=int,default=500)
    parser.add_argument('--seed',type=int,default=42)
    parser.add_argument('--max-positions',type=int,default=0,
                        help='0 = todas las filas; N = máximo de filas aleatorias')
    args=parser.parse_args()
    if args.population<2 or args.generaciones<1 or args.max_positions<0:
        parser.error('población >= 2; generaciones >= 1; max-positions >= 0')
    try:
        with open_source(args.source) as db:
            rows=load_labeled(db,seed=args.seed,max_rows=args.max_positions,require_move=True)
        dataset=build_dataset(rows)
        # --out is always the best COMPLETE individual found so far. It is
        # usable even if Ctrl+C interrupts the first generation.
        def save_best(record):
            json_atomic(args.out,record)
            json_atomic(best_path(args.out),record)
        def save_generation(number,record):
            json_atomic(generation_path(args.out,number),record)
        out=evolve(dataset,args.population,args.generaciones,args.seed,
                   on_best=save_best,on_generation=save_generation)
        print(f'✅ PST output={args.out} correct={out["correct"]}/{out["positions"]} '
              f'fitness={out["fitness"]}')
    except KeyboardInterrupt:
        print('\nPST interrupted with Ctrl+C; last best model and completed generations remain on disk.',flush=True)
        raise SystemExit(130)
    except (ValueError,OSError,RuntimeError) as exc:parser.error(str(exc))

if __name__=='__main__':main()
