"""Pure-tensor regression tests; python-chess and EvoTorch are not needed here."""
import unittest
import numpy as np
import torch
from gen_grumpy_pgpe_core import (PARAMS, MATERIAL, factor_index, forward,
                                  to_torch, loss_parts, metrics)


class GrumpyContract(unittest.TestCase):
    def make_data(self):
        xs=np.zeros((3,2,64),dtype=np.int16)
        # two active rank/file features for 2 pieces; independent perspectives
        xs[:,0,:4]=np.array([[0,8,16,24],[1,9,17,25],[2,10,18,26]])
        xs[:,1,:4]=np.array([[48,56,64,72],[49,57,65,73],[50,58,66,74]])
        n=np.full(3,4,dtype=np.int64)
        b=np.zeros(3,dtype=np.int64)
        m=np.array([900,-900,0],dtype=np.float32)
        signs=np.array([1,-1,1],dtype=np.float32)
        y=np.array([1900,-1900,-500],dtype=np.float32)
        return to_torch((xs,n,b,m,signs,y))

    def test_grumpy_parameter_contract(self):
        self.assertEqual(PARAMS,1680)
        self.assertEqual(MATERIAL,(100,300,300,500,900,0))
        self.assertEqual(factor_index(0),(0,8))
        self.assertEqual(factor_index(63),(7,15))
        self.assertEqual(factor_index(64),(16,24))

    def test_fixed_material_and_stm_sign(self):
        data=self.make_data()
        w=torch.zeros(PARAMS)
        self.assertTrue(torch.allclose(forward(w,data),data[3]))
        # GRMP0001 bucket bias contributes 8*(400/1024)=3.125 cp
        w[1672]=1
        expected=data[3]+data[4]*3.125
        self.assertTrue(torch.allclose(forward(w,data),expected))

    def test_rank_and_gradient_preserve_magnitude(self):
        data=self.make_data()
        w=torch.zeros(PARAMS,requires_grad=True)
        with torch.no_grad():
            w[:1536].fill_(0.05)
            w[1536:1544].fill_(2)
            w[1544:1672].fill_(1)
        pred=forward(w,data)
        loss,prob,cp=loss_parts(pred,data[-1],1.0)
        self.assertTrue(float(cp)>0)
        self.assertTrue(float(prob)>0)
        loss.backward()
        self.assertTrue(torch.isfinite(w.grad).all())
        self.assertGreater(float(w.grad.abs().sum()),0)
        self.assertGreater(float(w.grad[1544:1680].abs().sum()),0)
        self.assertTrue(np.isfinite(metrics(pred.detach().numpy(),data[-1].numpy())['rmse_cp']))

    def test_batched_matches_individual_and_gradient(self):
        data=self.make_data()
        g=torch.Generator().manual_seed(99)
        weights=torch.randn((3,PARAMS),generator=g)*0.1
        batched=forward(weights,data)
        sequential=torch.stack([forward(row,data) for row in weights])
        self.assertTrue(torch.allclose(batched,sequential,atol=1e-5,rtol=1e-5))

if __name__=='__main__':unittest.main()
