Parche basado exclusivamente en akkad(5).zip.
Formato: info ply <positional_ply> depth <search_depth> score cp <white_relative_cp> nodes <count> time <ms> nps <nodes/s>.
NOTA: score cp desde blancas NO ES la semántica UCI estándar; GUIs UCI esperan perspectiva del jugador al turno.
AlphaZero y picoAlpha MCTS usan depth 0 (no realizan búsqueda minimax). No se falsea la profundidad.
picoKeras: score cp es una TRANSFORMACIÓN HEURÍSTICA de salida neuronal [-1,1], NO una calibración a centipeones.
Debian picoSargon y picoKeras reutilizan los fuentes x86.
No se encontraron fuentes ARM picoSargon ni picoAlpha ni fuentes Debian picoAlpha en este ZIP.
No se modificaron consumidores UCI Python ni se hizo prueba de build completa de todas las variantes.
