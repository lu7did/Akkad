"""Contract smoke tests: fake chess board and two fake TCP/UCI engines.
No dependency or network connectivity beyond loopback required.
"""
import importlib.util
import io
import json
import socket
import sys
import tempfile
import threading
import time
import types
import unittest
from contextlib import redirect_stdout
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
# This lightweight fixture only verifies transport/partitioning; NOT chess legality.
class Move:
    def __init__(self, u): self.value = u
    def uci(self): return self.value
    @classmethod
    def from_uci(cls, u): return cls(u)
    def __eq__(self, other): return isinstance(other, Move) and self.value == other.value
    def __hash__(self): return hash(self.value)
class Board:
    def __init__(self, *a): self.legal_moves = [Move(u) for u in ('e2e4','d2d4','g1f3','c2c4')]
    def push(self, m): pass
fake = types.ModuleType('chess'); fake.Board = Board; fake.Move = Move
sys.modules['chess'] = fake
spec = importlib.util.spec_from_file_location('hive_prototype', ROOT/'src'/'hive.py')
hive = importlib.util.module_from_spec(spec); sys.modules[spec.name] = hive; spec.loader.exec_module(hive)

class FakeEngine:
    def __init__(self):
        self.s = socket.socket();self.s.bind(('127.0.0.1',0));self.s.listen(2)
        self.port = self.s.getsockname()[1];self.seen=[];self.finished=threading.Event()
        threading.Thread(target=self.serve,daemon=True).start()
    def serve(self):
        try:
            c,_ = self.s.accept()
            with c, c.makefile('r',encoding='utf-8') as src:
                for line in src:
                    line=line.strip();self.seen.append(line)
                    if line=='uci': c.sendall(b'id name test\nuciok\n')
                    elif line=='isready': c.sendall(b'readyok\n')
                    elif line.startswith('go '):
                        moves=line.split('searchmoves ')[1].split()
                        m=moves[0]
                        data=(f'info depth 6 score cp {50 if m=="e2e4" else 20} nodes 32 time 25 pv {m}\nbestmove {m}\n')
                        c.sendall(data.encode())
                        self.finished.set()
        except OSError: pass
    def close(self): self.s.close()

class Tests(unittest.TestCase):
    def test_parse_info(self):
        p=hive.parse_info('info depth 9 score cp -18 upperbound nodes 99 time 27 pv e2e4 e7e5')
        self.assertEqual((p['score'],p['bound'],p['depth'],p['pv']),(-18,'upper',9,'e2e4'))
    def test_two_engines_partition(self):
        a,b=FakeEngine(),FakeEngine()
        cfg={'engines':[{'name':'a','host':'127.0.0.1','port':a.port},{'name':'b','host':'127.0.0.1','port':b.port}], 'reconnect_seconds':1}
        h=hive.Hive(cfg)
        h.endpoints[0].connect();h.endpoints[1].connect()
        output=[];h.emit=output.append
        h.set_position(['startpos']);h.search('depth 6 movetime 500 searchmoves e2e4 d2d4 g1f3 c2c4')
        h.search_thread.join(3)
        self.assertFalse(h.search_thread.is_alive())
        go=[x for x in a.seen+b.seen if x.startswith('go ')]
        self.assertEqual(len(go),2)
        sets=[set(x.split('searchmoves ')[1].split()) for x in go]
        self.assertFalse(sets[0]&sets[1]);self.assertEqual(sets[0]|sets[1],{'e2e4','d2d4','g1f3','c2c4'})
        self.assertEqual(sum(x.startswith('bestmove ') for x in output),1)
        self.assertTrue(any(x.startswith('info depth') for x in output))
        for ep in h.endpoints: ep.drop()
        a.close();b.close()
    def test_invalid_moves(self):
        h=hive.Hive({'engines':[]})
        with self.assertRaises(ValueError): h.search('movetime 300 searchmoves a1a1')

if __name__=='__main__': unittest.main(verbosity=2)
