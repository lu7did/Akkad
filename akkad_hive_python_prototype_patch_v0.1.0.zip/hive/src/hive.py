#!/usr/bin/env python3
"""Hive: UCI concentrator prototype. Requires python-chess (not bundled)."""
from __future__ import annotations
import argparse
import json
import logging
import queue
import re
import select
import socket
import sys
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

try:
    import chess
except ImportError:
    print('Hive: falta python-chess; instalar con: python -m pip install -r hive/requirements.txt', file=sys.stderr)
    raise SystemExit(2)

LOG = logging.getLogger('hive')
MOVE = re.compile(r'^[a-h][1-8][a-h][1-8][qrbn]?$')


@dataclass
class Result:
    engine: str
    bestmove: str
    score: Optional[int]
    mate: Optional[int]
    bound: str
    depth: Optional[int]
    nodes: Optional[int]
    elapsed_ms: int
    moves: list[str] = field(default_factory=list)


def parse_info(line: str):
    """Only standard UCI fields. CP is side-to-move at the root."""
    fields = line.split()
    if not fields or fields[0] != 'info':
        return None
    out = {'score': None, 'mate': None, 'depth': None, 'nodes': None, 'bound': 'exact', 'pv': None}
    def number(tag):
        try:
            k = fields.index(tag)
            return int(fields[k + 1])
        except (ValueError, IndexError):
            return None
    out['depth'] = number('depth')
    out['nodes'] = number('nodes')
    if 'score' in fields:
        j = fields.index('score')
        if j + 2 < len(fields):
            try:
                if fields[j+1] == 'cp': out['score'] = int(fields[j+2])
                elif fields[j+1] == 'mate': out['mate'] = int(fields[j+2])
            except ValueError: pass
    if 'lowerbound' in fields: out['bound'] = 'lower'
    elif 'upperbound' in fields: out['bound'] = 'upper'
    if 'pv' in fields:
        p = fields.index('pv') + 1
        if p < len(fields) and MOVE.fullmatch(fields[p]): out['pv'] = fields[p]
    return out


class UciSocket:
    def __init__(self, host, port, connect_timeout=2.0):
        self.sock = socket.create_connection((host, int(port)), timeout=connect_timeout)
        self.sock.setblocking(False)
        self.buffer = bytearray()

    def send(self, line):
        data = (line + '\n').encode('utf-8')
        # During handshake or search, only the owning worker sends on this socket.
        view = memoryview(data)
        deadline = time.monotonic() + 3
        while view:
            remaining = deadline - time.monotonic()
            if remaining <= 0: raise TimeoutError('UCI send timeout')
            _, ready, _ = select.select([], [self.sock], [], min(.2, remaining))
            if ready:
                n = self.sock.send(view)
                if n == 0: raise ConnectionError('UCI socket closed on write')
                view = view[n:]

    def recv(self, deadline, cancelled=lambda: False):
        while True:
            pos = self.buffer.find(b'\n')
            if pos >= 0:
                line = bytes(self.buffer[:pos]).decode('utf-8', errors='replace').strip()
                del self.buffer[:pos+1]
                return line
            if cancelled(): raise InterruptedError('search cancelled')
            remaining = deadline - time.monotonic()
            if remaining <= 0: raise TimeoutError('UCI receive timeout')
            ready, _, _ = select.select([self.sock], [], [], min(.1, remaining))
            if ready:
                chunk = self.sock.recv(8192)
                if not chunk: raise EOFError('UCI socket closed')
                self.buffer.extend(chunk)
                if len(self.buffer) > 1024 * 1024: raise ValueError('UCI line too long')

    def close(self):
        try: self.sock.close()
        except OSError: pass


class Endpoint:
    def __init__(self, spec):
        self.name = spec['name']
        self.host = spec['host']
        self.port = int(spec['port'])
        self.static = True
        self.client = None
        self.busy = False
        self.lock = threading.Lock()
        self.capacity = 1.0
        self.cost = None
        self.last_seen = 0.0

    def connect(self):
        with self.lock:
            if self.client is not None or self.busy: return
            c = None
            try:
                c = UciSocket(self.host, self.port)
                c.send('uci')
                end = time.monotonic() + 5
                while c.recv(end) != 'uciok': pass
                c.send('isready')
                end = time.monotonic() + 5
                while c.recv(end) != 'readyok': pass
                self.client = c
                self.last_seen = time.monotonic()
                LOG.info('READY %s %s:%s', self.name, self.host, self.port)
            except Exception as exc:
                if c: c.close()
                LOG.warning('endpoint %s not ready: %s', self.name, exc)

    def drop(self):
        with self.lock:
            c, self.client = self.client, None
            if c: c.close()

    def analyze(self, position, assigned, depth, movetime, cancelled):
        if not self.client: return None
        self.busy = True
        client = self.client
        start = time.monotonic()
        try:
            client.send(position)
            # Put searchmoves last (variable length in UCI).
            command = f'go movetime {movetime}'
            if depth is not None: command += f' depth {depth}'
            command += ' searchmoves ' + ' '.join(assigned)
            client.send(command)
            best = None
            infos = {}
            latest = None
            # Leave bounded time for network latency after the engine's movetime.
            deadline = start + movetime/1000 + 1.5
            while True:
                line = client.recv(deadline, cancelled)
                if line.startswith('info '):
                    info = parse_info(line)
                    if info:
                        latest = info
                        if info['pv'] in assigned and (info['score'] is not None or info['mate'] is not None):
                            infos[info['pv']] = info
                elif line.startswith('bestmove '):
                    token = line.split()
                    if len(token) >= 2: best = token[1]
                    break
            if best not in assigned:
                raise ValueError(f'bestmove {best!r} fuera de searchmoves {assigned}')
            info = infos.get(best) or (latest if len(assigned) == 1 else None) or {}
            if info.get('score') is None and info.get('mate') is None:
                LOG.warning('%s bestmove without score, ignored for CP aggregation', self.name)
                return None
            elapsed = int((time.monotonic()-start)*1000)
            return Result(self.name, best, info.get('score'), info.get('mate'),
                          info.get('bound','exact'), info.get('depth'), info.get('nodes'), elapsed, assigned)
        except Exception as exc:
            LOG.warning('worker %s failed: %s', self.name, exc)
            self.drop()
            return None
        finally:
            self.busy = False


class Hive:
    def __init__(self, config):
        self.endpoints = [Endpoint(x) for x in config.get('engines', [])]
        self.retry_s = max(1.0, float(config.get('reconnect_seconds', 5)))
        self.max_budget = max(100, int(config.get('max_movetime_ms', 15000)))
        self.alpha = float(config.get('adaptive_alpha', .1))
        self.board = chess.Board()
        self.position = 'position startpos'
        self.lock = threading.RLock()
        self.output_lock = threading.Lock()
        self.cancel = threading.Event()
        self.search_thread = None
        self.closed = threading.Event()
        self.search_serial = 0
        self.dispatch_active = False
        self.manager = threading.Thread(target=self._connection_loop, daemon=True)

    def emit(self, line):
        with self.output_lock:
            print(line, flush=True)

    def _connection_loop(self):
        while not self.closed.is_set():
            for ep in self.endpoints:
                if self.closed.is_set(): break
                if ep.client is None and not ep.busy: ep.connect()
            self.closed.wait(self.retry_s)

    def set_position(self, tokens):
        if not tokens: raise ValueError('position without args')
        b = chess.Board()
        if tokens[0] == 'startpos':
            j = 1
        elif tokens[0] == 'fen':
            if len(tokens) < 7: raise ValueError('incomplete FEN')
            b = chess.Board(' '.join(tokens[1:7]))
            j = 7
        else: raise ValueError('position requires startpos or fen')
        if j < len(tokens):
            if tokens[j] != 'moves': raise ValueError('unexpected position parameters')
            for u in tokens[j+1:]:
                move = chess.Move.from_uci(u)
                if move not in b.legal_moves: raise ValueError('illegal move '+u)
                b.push(move)
        self.board = b
        # Full history for repetition/draw detection.
        self.position = 'position ' + ' '.join(tokens)

    def select_groups(self, moves, endpoints):
        # Initial design choice: capacity-proportional, with integer allocation.
        # Adaptation only when endpoint finishes BEFORE its movetime budget.
        groups = {e.name: [] for e in endpoints}
        weights = {e.name: max(.01, e.capacity) for e in endpoints}
        for move in moves:
            e = min(endpoints, key=lambda x: (len(groups[x.name]) + 1)/weights[x.name])
            groups[e.name].append(move)
        return [(e, groups[e.name]) for e in endpoints if groups[e.name]]

    def _do_search(self, serial, position, moves, depth, budget):
        begun = time.monotonic()
        ready = [e for e in self.endpoints if e.client is not None and not e.busy]
        if not ready:
            self.emit('info string Hive ERROR no available endpoints')
            self.emit('bestmove 0000')
            return
        groups = self.select_groups(moves, ready)
        replies = queue.Queue()
        threads = []
        def task(endpoint, assigned):
            reply = endpoint.analyze(position, assigned, depth, budget, self.cancel.is_set)
            replies.put((endpoint, assigned, reply))
        for ep, assigned in groups:
            t = threading.Thread(target=task, args=(ep,assigned), daemon=True)
            threads.append(t); t.start()
        candidates = []
        pending = len(groups)
        limit = begun + budget/1000 + 2.0
        while pending and not self.cancel.is_set():
            remaining = limit - time.monotonic()
            if remaining <= 0: break
            try: ep, assigned, result = replies.get(timeout=min(.1, remaining))
            except queue.Empty: continue
            pending -= 1
            if result:
                candidates.append(result)
                # An exhausted movetime is NOT evidence of speed; do not learn from it.
                if result.elapsed_ms < budget * .85:
                    sample = result.elapsed_ms / len(assigned)
                    ep.cost = sample if ep.cost is None else (1-self.alpha)*ep.cost + self.alpha*sample
                    ep.capacity = min(100, max(.01, 1000.0 / ep.cost))
        if pending:
            LOG.warning('search timed out/cancelled: %s unfinished endpoints', pending)
            # Invalidate late sockets to avoid reading replies in a later search.
            for ep, _ in groups:
                if ep.busy: ep.drop()
        # For now CP-only max; mate prioritized. Lower/upper bounds are not exact.
        exact = [x for x in candidates if x.bound == 'exact']
        if exact:
            best = max(exact, key=lambda r: (2 if r.mate and r.mate>0 else 0 if r.mate is None else -2,
                                             -abs(r.mate) if r.mate and r.mate>0 else
                                             (r.score if r.score is not None else -100000)))
        elif candidates:
            best = candidates[0]  # provisional, bounds cannot be globally ordered
        else:
            self.emit('info string Hive ERROR no valid scored result')
            self.emit('bestmove 0000')
            return
        elapsed = int((time.monotonic()-begun)*1000)
        # UCI bestmove and info are root-side-to-move perspective.
        sc = ('mate '+str(best.mate)) if best.mate is not None else ('cp '+str(best.score))
        self.emit('info depth '+str(best.depth or 0)+' score '+sc+' nodes '+str(sum(r.nodes or 0 for r in candidates))+
                  ' time '+str(elapsed)+' pv '+best.bestmove+' string Hive policy=MAX_CP_PROTOTYPE')
        self.emit('bestmove '+best.bestmove)

    def search(self, args):
        tokens = args.split()
        budget = self.max_budget
        depth = None
        restrictions = None
        i = 0
        while i < len(tokens):
            k = tokens[i]
            if k in ('movetime','depth'):
                if i+1 >= len(tokens): raise ValueError('missing '+k)
                n = int(tokens[i+1]); i += 2
                if n < 1: raise ValueError('invalid '+k)
                if k == 'movetime': budget = min(self.max_budget, n)
                else: depth = n
            elif k == 'searchmoves':
                restrictions = tokens[i+1:]; break
            else:
                # Unsupported time controls must not silently become a different search.
                raise ValueError('unsupported go parameter '+k)
        legal = {m.uci() for m in self.board.legal_moves}
        if restrictions is not None:
            if not restrictions or len(restrictions) != len(set(restrictions)) or any(m not in legal for m in restrictions):
                raise ValueError('invalid searchmoves')
            moves = restrictions
        else: moves = sorted(legal)
        if self.search_thread and self.search_thread.is_alive(): raise RuntimeError('search already in progress')
        self.cancel.clear()
        self.search_serial += 1
        serial = self.search_serial
        if not moves:
            self.emit('bestmove 0000'); return
        self.search_thread = threading.Thread(target=self._do_search,
                          args=(serial, self.position, moves, depth, budget), daemon=True)
        self.search_thread.start()

    def run(self):
        self.manager.start()
        for raw in sys.stdin:
            line = raw.strip()
            if not line: continue
            cmd, _, tail = line.partition(' ')
            try:
                if cmd == 'uci':
                    self.emit('id name Hive Python prototype v0.1.0')
                    self.emit('id author Akkad')
                    self.emit('uciok')
                elif cmd == 'isready': self.emit('readyok')
                elif cmd == 'ucinewgame':
                    if self.search_thread and self.search_thread.is_alive(): raise RuntimeError('busy')
                    self.set_position(['startpos'])
                elif cmd == 'position':
                    if self.search_thread and self.search_thread.is_alive(): raise RuntimeError('busy')
                    self.set_position(tail.split())
                elif cmd == 'go': self.search(tail)
                elif cmd == 'stop':
                    self.cancel.set()
                    # Worker sockets are dropped when a search is stopped; no stale replies.
                elif cmd == 'quit': break
                else: self.emit('info string Hive unsupported '+cmd)
            except Exception as exc:
                LOG.warning('command rejected %s: %s', cmd, exc)
                self.emit('info string Hive ERROR '+str(exc).replace('\n',' '))
                if cmd == 'go' and not (self.search_thread and self.search_thread.is_alive()): self.emit('bestmove 0000')
        self.cancel.set()
        self.closed.set()
        if self.search_thread: self.search_thread.join(timeout=2)
        for ep in self.endpoints: ep.drop()


def main():
    ap = argparse.ArgumentParser(description='Hive UCI coordinator prototype')
    ap.add_argument('--config', default=str(Path(__file__).resolve().parents[1] / 'etc' / 'hive.json'))
    args = ap.parse_args()
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s', stream=sys.stderr)
    config = json.loads(Path(args.config).read_text(encoding='utf-8'))
    Hive(config).run()

if __name__ == '__main__': main()
