# Hive Python prototype v0.1.0

Prototipo de **concentrador UCI**; **no es un motor de ajedrez**. Usa `python-chess` para validar/generar movimientos legales. Sus endpoints son servicios **TCP que hablan UCI** (un motor de solo stdin/stdout necesita un listener externo). `stdout` se reserva para UCI y los diagnósticos van a `stderr`.

## Ejecutar

Desde la raíz de Akkad:

```sh
python -m pip install -r hive/requirements.txt
python hive/src/hive.py --config hive/etc/hive.json
```

Editar `hive/etc/hive.json` con endpoints reales antes de iniciar. Los dos valores del archivo son **ejemplos**, no destinos verificados. Para Windows, `hive/tools/ps/run.ps1`; Debian `hive/tools/bash/run.sh`; macOS `hive/tools/macOS/run.sh`.

Protocolo de ejemplo:

```text
uci
isready
position startpos
go depth 6 movetime 3000 searchmoves e2e4 d2d4 g1f3
quit
```

**Alcance confirmado de v0.1.0**: endpoints estáticos TCP y reconexión, handshake UCI, posición con historia, validación de jugadas, reparto proporcional, concurrencia de endpoints, captura de info UCI, score CP STM, selección preliminar `MAX_CP_PROTOTYPE`, retorno de un `bestmove`, timeout, interrupción y exclusión de respuestas fuera del grupo. El reparto usa capacidad inicial 1 y solo ajusta lentamente las mediciones que terminan antes de agotar el presupuesto temporal. `depth` se retransmite si se solicita, no se usa como índice de capacidad.

**No implementado**: descubrimiento UDP, alta dinámica, listener TCP de entrada, identificación y prevención de ciclos entre Hives, uso simultáneo como subordinado, negociación MultiPV, algoritmo de consolidación CP homogéneo/calibrado, gestión completa de relojes `wtime/btime`, reintento de trabajos perdidos, cancelación limpia con `stop` a través de todas las capas. Los scores de motores distintos pueden no ser comparables. Si no hay respuesta válida se devuelve `bestmove 0000` con error informativo, provisional y **no adecuado para partidas de producción**.

UCI de un motor no obliga a emitir `score cp`; este prototipo requiere CP/mate y rechaza resultados sin puntuación. El último frame `info` puede no referirse a `bestmove` en algunos motores; se prioriza `info ... pv <bestmove>` cuando existe.
