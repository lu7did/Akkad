$Root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
& python (Join-Path $Root 'src\hive.py') --config (Join-Path $Root 'etc\hive.json')
exit $LASTEXITCODE
