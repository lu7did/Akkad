# Sargon-NNUE v0.6.209 — generic UCI subprocess resolution and diagnostics

- `engine-path` is chosen for the running platform by `brains.get`.
- **Relative paths in UCI brain profiles are resolved first from `Sargon-NNUE/scripts`,** as used by the existing Windows scripts, then from the current working directory, the project root, and the directory containing the JSON. Absolute paths and executables in `PATH` remain supported.
- `benchmark` also uses this common resolution and retains the features of its v0.6.207 Bratko–Kopec variant.
- The process launcher independently validates the executable and records requested and resolved paths, `cwd`, PID, `uci`, `uciok`, `isready`, `readyok`, `go`, and `bestmove` to diagnostic telemetry (stderr, never UCI stdout).
- No changes to existing `fishy` configuration required when executable exists at `../../../stockfish/stockfish.exe` relative to `Sargon-NNUE/scripts`.
- A `timeout` in ms protects handshake; `tmax` in ms remains the search time budget. If the motor does not reply, the error includes the process and command.

Test using `python -m unittest discover -s tests -p 'test_generic_uci_v06209.py'` from `Sargon-NNUE` with project dependencies installed. For direct use, run `python -m sargon_nnue.sargon_listen --mode STDIN --brain etc/brains/brains.json --id fishy` and send UCI protocol commands. This environment did **not** execute the Windows Stockfish binary; the new tests cover a simulated UCI child process and path resolution.
