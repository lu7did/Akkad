#*================================================================================================================*
#* Proyecto sargon-nnue
#* Chess player using different Neural Networks as the game evaluation engine
#*
#* A new mind for the old buddy
#* Created as a learning experience
#*
#* By Dr. Pedro E. Colla 2026 (UADER Teoria de la Comunicación / UFASTA Gestión de Redes)
#* License: CC AS BY 4.0
#*================================================================================================================*
#* sargon-listen.py
#* Implementa funciones del modulo sargon listen
#* v0.6.153
#=================================================================================================================*
from sargon_nnue.sargon_listen import main
if __name__ == "__main__":
    raise SystemExit(main())
