#*================================================================================================================*
#* Proyecto sargon-nnue
#* Chess player using different Neural Networks as the game evaluation engine
#*
#* A new mind for the old buddy
#* Created as a learning experience
#*
#* By Dr. Pedro E. Colla 2026 (UADER Teoria de la Comunicación / UFASTA Gestión de Redes)
#* License: CC AS BY 4.0
#*================================================================================================================*
#* factory.py
#* Implementa funciones del modulo factory
#* v0.6.153
#=================================================================================================================*
from __future__ import annotations

import sys

from .evaluators import create_evaluator
from .players import create_player
from .players.base import PlayerError
from .players.sargon_plus import BOOST_FEATURES, TURBO_FEATURES
from .audit import AuditLogger


STOCKFISH_DEFAULT_DEPTH = 20
STOCKFISH_DEFAULT_NODES = 5_000_000
SARGON_DEFAULT_DEPTH = 2
SARGON_DEFAULT_QDEPTH = 2
SARGON_DEFAULT_TMAX_MS = 15_000
STOCKFISH_DEFAULT_THREADS = 1
STOCKFISH_DEFAULT_HASH_MB = 256
STOCKFISH_EVAL_DEFAULT_TIMEOUT_MS = 5_000
STOCKFISH_EVAL_DEFAULT_CHECK_DEPTH = 1
STOCKFISH_EVAL_DEFAULT_CACHE = 100_000


def _telemetry(message: str) -> None:
    # stderr is safe even in STDIN UCI mode; stdout belongs to the protocol.
    print(message, file=sys.stderr, flush=True)


def _fmt_effective(name: str, value, default) -> str:
    return f"{name}={value} [default={default}]"


def _print_execution_summary(*, player_kind: str, evaluator_kind: str, depth: int,
                             qdepth: int, tmax_ms: int | None, nodes: int, elo,
                             stockfish_threads: int, stockfish_hash: int,
                             stockfish_timeout_ms: int, stockfish_check_depth: int,
                             stockfish_cache: int, engine_path, stockfish_path,
                             iterative_deepening: bool, boost: int, turbo: int) -> None:
    default_depth = STOCKFISH_DEFAULT_DEPTH if player_kind == "stockfish" else SARGON_DEFAULT_DEPTH
    parts = [
        f"player={player_kind}",
        f"evaluator={evaluator_kind}",
        _fmt_effective("depth", depth, default_depth),
        _fmt_effective("qdepth", qdepth, SARGON_DEFAULT_QDEPTH),
        _fmt_effective("tmax_ms", tmax_ms, SARGON_DEFAULT_TMAX_MS),
    ]
    if player_kind in {"sargon-plus", "sargon+", "plus"}:
        parts.append(f"boost=0x{boost:04X}/{boost} [default=0]")
        parts.append(f"turbo=0x{turbo:02X}/{turbo} [default=0]")
    if player_kind in {"sargon", "sargon-plus", "sargon+", "plus"}:
        parts.append(f"iterative_deepening={'on' if iterative_deepening else 'off'}")
        parts.append("guardrail=normal-telemetry [levels/time]")
    if player_kind == "stockfish":
        parts.extend([
            _fmt_effective("nodes", nodes, STOCKFISH_DEFAULT_NODES),
            f"elo={elo} [default=max]",
            _fmt_effective("threads", stockfish_threads, STOCKFISH_DEFAULT_THREADS),
            _fmt_effective("hash_mb", stockfish_hash, STOCKFISH_DEFAULT_HASH_MB),
            "multipv=1 [forced]",
            f"engine={engine_path}",
        ])
    if evaluator_kind == "stockfish":
        parts.extend([
            _fmt_effective("sf_eval_timeout_ms", stockfish_timeout_ms, STOCKFISH_EVAL_DEFAULT_TIMEOUT_MS),
            _fmt_effective("sf_check_depth", stockfish_check_depth, STOCKFISH_EVAL_DEFAULT_CHECK_DEPTH),
            _fmt_effective("sf_cache", stockfish_cache, STOCKFISH_EVAL_DEFAULT_CACHE),
            f"sf_path={stockfish_path}",
        ])
    _telemetry("⚙️ EXEC " + " | ".join(parts))


def build_engine(args, prefix: str = ""):
    def g(name, default=None):
        return getattr(args, f"{prefix}{name}" if prefix else name, default)

    player_kind = str(g("player", "sargon")).strip().lower()
    requested_evaluator = g("evaluator", None)

    if player_kind == "alphazero":
        if requested_evaluator is not None and str(requested_evaluator).strip().lower() not in {"lc0", "tinygyal", "znpz", "zclassic"}:
            raise PlayerError('player=alphazero sólo admite evaluator=lc0, tinygyal, znpz o zclassic')
        if requested_evaluator is None:
            requested_evaluator = "lc0"

    # Architectural rule:
    # - STOCKFISH and player LC0-UCI are monolithic; require NULL.
    # - RANDOM does not evaluate positions; requires NULL.
    # - Other players require a real evaluator (CLASSIC by default).
    if player_kind in {"stockfish", "random", "lc0", "picosargon", "external", "picoalpha", "alphazero-x86"}:
        if requested_evaluator is None:
            evaluator_kind = "null"
        else:
            evaluator_kind = str(requested_evaluator).strip().lower()
            if evaluator_kind != "null":
                raise PlayerError(
                    f"player={player_kind} sólo admite evaluator=null"
                )
    else:
        if requested_evaluator is None:
            evaluator_kind = "classic"
        else:
            evaluator_kind = str(requested_evaluator).strip().lower()
            if evaluator_kind == "null":
                raise PlayerError("evaluator=null sólo es válido con player=stockfish, player=lc0, player=picosargon, player=external o player=random")

    raw_depth = g("depth", None)
    if raw_depth is None:
        depth = STOCKFISH_DEFAULT_DEPTH if player_kind == "stockfish" else (4 if player_kind == "picosargon" else SARGON_DEFAULT_DEPTH)
    else:
        depth = int(raw_depth)

    raw_nodes = g("nodes", None)
    nodes = STOCKFISH_DEFAULT_NODES if raw_nodes is None else int(raw_nodes)

    raw_elo = g("elo", None)
    elo = "max" if raw_elo is None else raw_elo

    qdepth = int(g("qdepth", SARGON_DEFAULT_QDEPTH))
    tmax_ms = g("tmax", SARGON_DEFAULT_TMAX_MS)
    stockfish_threads = int(g("stockfish_threads", STOCKFISH_DEFAULT_THREADS))
    stockfish_hash = int(g("stockfish_hash", STOCKFISH_DEFAULT_HASH_MB))
    stockfish_timeout_ms = int(g("stockfish_timeout", STOCKFISH_EVAL_DEFAULT_TIMEOUT_MS))
    stockfish_check_depth = int(g("stockfish_check_depth", STOCKFISH_EVAL_DEFAULT_CHECK_DEPTH))
    stockfish_cache = int(g("stockfish_cache", STOCKFISH_EVAL_DEFAULT_CACHE))
    boost = int(g("boost", 0))
    turbo = int(g("turbo", 0))
    if player_kind not in {"sargon-plus", "sargon+", "plus"} and (boost or turbo):
        raise PlayerError("--boost y --turbo sólo son válidos con player=sargon-plus")
    # v0.6.21 SargonCore invariant: D1 is mandatory and higher levels use the
    # remaining total tmax budget.  Therefore SARGON and SARGON+ share the same
    # iterative scheduler regardless of evaluator cost.
    iterative_deepening = player_kind in {"sargon", "sargon-plus", "sargon+", "plus"}

    audit = AuditLogger(
        enabled=bool(g("audit", False)),
        path=g("audit_file", "sargon_audit.jsonl"),
        eval_max=g("audit_eval_max", 5000),
    )

    evaluator = create_evaluator(
        evaluator_kind,
        g("network", None),
        allow_new_npz=g("allow_new_npz", False),
        cerebrum_a=g("cerebrum_a", None),
        cerebrum_b=g("cerebrum_b", None),
        stockfish_path=g("stockfish_path", None),
        stockfish_timeout_ms=stockfish_timeout_ms,
        stockfish_check_depth=stockfish_check_depth,
        stockfish_cache_size=stockfish_cache,
        lc0_weights=g("lc0_weights",None),lc0_backend=g("lc0_backend","auto"),
        lc0_backend_options=g("lc0_backend_options",""),lc0_history=g("lc0_history","allow-incomplete"),
        lc0_cache_size=g("lc0_cache",10000),lc0_cp_scale=g("lc0_cp_scale",400.),
        z_temperature=g("z_temperature",100.0),z_value_scale=g("z_value_scale",800.0),
        z_uniform_mix=g("z_uniform_mix",0.01),z_policy=g("z_policy","uniform"),audit=audit,
    )
    if player_kind == "lc0":
        _telemetry(f"♟️ LC0-UCI engine={g('lc0_uci_path',None) or g('engine_path',None)} "
                   f"backend={g('lc0_backend','auto')} nodes={g('lc0_uci_nodes',800)}")
    if evaluator_kind == 'lc0':
        _telemetry(f"🧠 LC0 v0.6.117 network={evaluator.network_id[:16]} "
                   f"history={evaluator.history_mode} cache=per-game")
    player = create_player(
        player_kind,
        evaluator,
        depth=depth,
        qdepth=qdepth,
        tmax_ms=tmax_ms,
        seed=g("seed", None),
        boost=boost,
        turbo=turbo,
        engine_path=g("engine_path", None),
        network=g("network", None),
        url=g("url", None),
        movetime_ms=g("movetime", 1000),
        timeout_ms=g("timeout", 30000),
        nodes=nodes,
        elo=elo,
        audit=audit,
        telemetry=_telemetry,
        stockfish_threads=stockfish_threads,
        stockfish_hash=stockfish_hash,
        iterative_deepening=iterative_deepening,
        az_simulations=g("az_simulations",128),az_cpuct=g("az_cpuct",1.5),
        lc0_uci_path=g("lc0_uci_path",None),lc0_weights=g("lc0_weights",None),
        lc0_backend=g("lc0_backend","auto"),lc0_backend_options=g("lc0_backend_options",""),
        lc0_uci_threads=g("lc0_uci_threads",1),lc0_uci_nncache=g("lc0_uci_nncache",200000),
        lc0_uci_options=g("lc0_uci_options",""),lc0_uci_depth=g("lc0_uci_depth",0),
        lc0_uci_nodes=g("lc0_uci_nodes",800),lc0_uci_movetime=g("lc0_uci_movetime",0),
        lc0_uci_timeout=g("lc0_uci_timeout",60000),
    )

    _print_execution_summary(
        player_kind=player_kind, evaluator_kind=evaluator_kind, depth=depth,
        qdepth=qdepth, tmax_ms=tmax_ms, nodes=nodes, elo=elo,
        stockfish_threads=stockfish_threads, stockfish_hash=stockfish_hash,
        stockfish_timeout_ms=stockfish_timeout_ms,
        stockfish_check_depth=stockfish_check_depth, stockfish_cache=stockfish_cache,
        engine_path=g("engine_path", None), stockfish_path=g("stockfish_path", None),
        iterative_deepening=iterative_deepening, boost=boost, turbo=turbo,
    )

    if player_kind in {"sargon-plus", "sargon+", "plus"}:
        # BOOST: announce every enabled algorithm once at startup, as requested.
        for level, (mask, feature_name) in BOOST_FEATURES.items():
            if boost & mask:
                _telemetry(
                    f"🚀 BOOST 0x{mask:04X} bit={level-1} {feature_name}=ON "
                    f"mask=0x{boost:04X}"
                )
        unknown_boost = boost & ~sum(mask for mask, _ in BOOST_FEATURES.values())
        if unknown_boost:
            _telemetry(f"🚀 BOOST reserved-mask=0x{unknown_boost:04X} configured (sin algoritmo asignado)")

        # TURBO v0.6.26: adaptive resource actuators + candidate-entry guard are active.
        if turbo == 0:
            _telemetry("⚡ TURBO mask=0x00 baseline=ON adaptive-actuators=OFF")
        else:
            for feature_id, (mask, feature_name) in TURBO_FEATURES.items():
                if turbo & mask:
                    _telemetry(
                        f"⚡ TURBO 0x{mask:02X} bit={feature_id-1} {feature_name}=ON "
                        f"mask=0x{turbo:02X} actuator=ACTIVE"
                    )
            unknown_turbo = turbo & ~sum(mask for mask, _ in TURBO_FEATURES.values())
            if unknown_turbo:
                _telemetry(f"⚡ TURBO reserved-mask=0x{unknown_turbo:02X} configured (sin algoritmo asignado)")

    audit.event(
        "engine_config",
        player=player_kind, evaluator=evaluator_kind, depth=depth, nodes=nodes, elo=elo,
        qdepth=qdepth, tmax_ms=tmax_ms,
        engine_path=g("engine_path", None), stockfish_path=g("stockfish_path", None),
        stockfish_timeout_ms=stockfish_timeout_ms,
        stockfish_check_depth=stockfish_check_depth,
        stockfish_cache=stockfish_cache,
        stockfish_threads=stockfish_threads, stockfish_hash=stockfish_hash,
        iterative_deepening=iterative_deepening, boost=boost, turbo=turbo,
    )
    try:
        player.audit = audit
    except Exception:
        pass
    try:
        evaluator.audit = audit
    except Exception:
        pass
    return evaluator, player
